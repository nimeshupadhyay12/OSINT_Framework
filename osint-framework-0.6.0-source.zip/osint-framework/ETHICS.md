# Research principles

Collect only what answers the documented research question. Use owned assets, public organizational information, consent-based investigations, or another substantiated authorized purpose. Do not use this framework to stalk, harass, expose private contact information, or target people based on sensitive traits.

Preserve uncertainty. A reused handle, common name, shared server, published email, or historical breach record is not identity proof. Verify consequential claims independently. Avoid unnecessary personal attributes and do not automatically pivot to newly discovered people or identifiers.

Respect source limits and stop at authentication, robots restrictions, provider denial, or anti-bot controls. No contributor should add evasion, mass-person enumeration, private account scraping, or breach dumps. Document source permissions, key requirements, rate limits, and data provenance for every adapter.

Audit locally, control access to evidence, and remove data according to the investigation's retention policy. Automated authorization checks are friction and accountability mechanisms, not guarantees about an operator's intentions.
