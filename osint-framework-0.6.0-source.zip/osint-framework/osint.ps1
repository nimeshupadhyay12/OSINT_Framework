# Run the locally installed environment without activating PowerShell scripts.
param([Parameter(ValueFromRemainingArguments = $true)][string[]]$OsintArguments)
$osintPython = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $osintPython -PathType Leaf)) {
    Write-Error 'Create .venv and install this project first; see README.md.'
    exit 2
}
& $osintPython -m osint_framework @OsintArguments
exit $LASTEXITCODE
