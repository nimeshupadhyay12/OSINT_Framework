# Contributing

Open a focused change with a fixture-backed source contract. State the upstream source/version, official API or terms reference, required environment variables, maximum request rate, passive/direct activity, expected input, output schema, attribution obligations, and declared legal_basis. Confirm you have read ETHICS.md.

Add tests for successful observations, negative/unknown distinctions, malformed payloads, scope boundaries, and safe failures. Use synthetic fixtures; never commit credentials, real personal exports, or query logs. Do not add login scraping, anti-bot workarounds, automatic pivots, unrestricted subprocess flags, or unlimited rates.

Run pytest, Ruff, the credential-pattern check, and a package build. New imports must identify a concrete upstream export version. A researched catalog entry is not an implementation. Do not silently discard unsupported formats or overstate confidence.
