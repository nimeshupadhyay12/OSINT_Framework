@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\osint-desktop.exe" (
    echo Run Setup OSINT.cmd first to install the framework and its desktop extra.
    pause
    exit /b 2
)
".venv\Scripts\python.exe" -c "import PySide6" >nul 2>&1
if errorlevel 1 (
    echo The desktop dependency is missing. Run Setup OSINT.cmd first.
    pause
    exit /b 2
)
start "" ".venv\Scripts\osint-desktop.exe"
