@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>&1
if errorlevel 1 goto python
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 goto python_required
py -3 -m venv .venv
if errorlevel 1 goto failed
goto install
:python
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 goto python_required
python -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -m pip install --upgrade "pip>=26.2.1,<27"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install ".[desktop,crawler,exchange,documents,security,team,postgres,evidence]"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
echo Setup complete. Double-click Launch OSINT.cmd to open the app.
pause
exit /b 0
:python_required
echo Python 3.11 or newer is required. Install Python, then run this setup again.
pause
exit /b 2
:failed
echo Setup failed. Check the error above and your internet connection, then try again.
pause
exit /b 1
