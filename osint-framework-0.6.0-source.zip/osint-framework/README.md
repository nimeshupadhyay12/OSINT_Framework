# OSINT Correlation Framework

A working Python toolkit for bounded public-data collection, offline tool imports, and evidence graphs. MIT licensed. Python 3.11+. Runs on Windows, Linux, and macOS.

Version **0.6.0** includes a **desktop investigation workbench** for phone, email, username, domain, IP, URL, and name queries; **32 source modules**; **16 import contracts**; saved cases; document evidence; and STIX/MISP exchange. Guided broad research selects configured sources and reports coverage gaps. Deep domain research adds up to three subdomain lookups in the desktop, with a shared request budget. New integrations cover Wayback CDX, public GitHub repository search, and gau/waybackurls/Uncover exports. Four reproduced evidence/API/export defects from the v0.5 review are addressed. API keys, provider access, and source policies determine coverage. Matching identifiers do not prove a common identity.

Start with the [v0.6 quickstart](docs/quickstart-v06.md), [release details](docs/release-v06.md), and [repository evaluation](docs/repository-evaluation-v06.md). The [v0.5 guide](docs/release-v05.md) documents optional deployment and evidence features; v0.6 supersedes its API quota and WARC behavior. This framework does not cover every website or guarantee reverse-phone owner/email discovery.

## Start the desktop

In the delivered Windows folder, double-click **Launch OSINT.cmd**. The installed environment includes the desktop, Scrapy, STIX, document, encryption, and team API libraries.

1. Choose **Try synthetic case** for an offline demonstration, or create a case with a descriptive title.
2. Paste an identifier in **Investigate**. Check the suggested type; select `phone` and a country such as `IN` for a national number. Enter the investigation purpose.
3. Choose **Guided broad research — all ready sources** for automatic source selection, or **Deep domain research** for bounded subdomain follow-ups. Manual collection, tool import and document modes remain available. Imports require a supported export and matching query; documents require a local file.
4. For webpage collection, enter exact permitted hostnames and a reviewed permission URL. Choose page/request budgets and optional local page preservation. Confirm authorization for this run, then choose **Run investigation**.
5. Review **Case evidence and graph**. Filter observations, inspect timestamps and origins, record an accepted/rejected review with a reason, add notes, or export the case report/STIX file. Selecting an identifier copies it into a new query; follow-up collection requires a new explicit run.
6. Use **Sources and credentials** for setup diagnostics and masked session keys. Saving to and loading from the OS keychain are explicit actions. Environment variables also work.
7. Use **Select compatible sources without API keys** for free collection. **Jobs and schedules** can queue the current form and process due work; a continuous CLI worker is available separately.

Saved runs retain original source outcomes and evidence. **Load saved run for another lookup** restores its inputs and selects failed sources when present. **Stop current run** cancels unfinished collection while retaining completed source results. See the [v0.3 integration and usage guide](docs/integrations-v03.md) for exact formats and examples.

## Paste a phone number

In the delivered local Windows folder, double-click **Launch OSINT.cmd** to open the desktop app. Alternatively run `.\.venv\Scripts\osint-desktop.exe` from this folder. The desktop uses the same collection engine and audit trail as the CLI.

1. Paste a number such as `+1 (202) 555-0123`. For a national number, supply its country code, e.g. `IN` or `US`.
2. Enter your purpose and confirm that the query is within your authorized scope.
3. Choose sources. Local numbering information works offline. Indexed web search needs a Brave Search API key. For direct webpage evidence, select `phone_pages` and provide exact page URLs, allowed hostnames, and a permission reference.
4. Run the lookup. Review metadata, source statuses, matching pages, and any email leads. Open a source or the saved HTML report to check the evidence.

The **Try synthetic case** button uses invented contact data and performs no network lookups. The earlier focused phone window remains available with `osint desktop --phone-only`; its manual search links send the number to a search provider only when explicitly opened.

Email results are extracted only when a complete matching phone number appears near the address in selected public page text or an indexed snippet. They are labeled **tentative associations**, not verified subscriber email addresses. National-format matches assume the queried number's country and are treated as tentative. A missing result means no evidence was returned within the selected scope.

For a fresh Windows installation, extract the source ZIP into a writable folder, install Python 3.11 or newer, and double-click **Setup OSINT.cmd**. Setup downloads the Python dependencies and installs the application into that folder's `.venv`; then double-click **Launch OSINT.cmd**. No administrator access or PowerShell activation is needed. Internet access is required during setup. This release includes Python source and installable packages; it is not a standalone executable with Python bundled.

On another platform, create a virtual environment and run `python -m pip install ".[desktop,crawler,exchange,documents,security,team,postgres,evidence]"` from the extracted project. Use `osint desktop` to launch. The CLI alone does not require the desktop dependency; install with `python -m pip install .` for CLI use only. Image OCR additionally requires the external Tesseract executable and selected language data; it is not bundled. The OpenCTI connector has its own optional `opencti` extra. `osint doctor` reports missing components.

```powershell
# Guided paste-and-run terminal workflow:
.\osint.ps1 phone

# Formatted number and indexed search, after setting BRAVE_SEARCH_API_KEY:
.\osint.ps1 phone "+1 (202) 555-0123" --search-web --purpose "Authorized public-contact review" --authorized

# Known permitted page; no search-provider key required:
.\osint.ps1 phone +12025550123 --page-url https://example.org/contact --allow-host example.org --terms-url https://example.org/terms --purpose "Authorized public-contact review" --authorized
```

The [phone research notes](docs/phone-research.md) record which links were actually observed in your [Start.me reference directory](https://start.me/p/b59RMv/osint). [Scrapy feed integration](docs/scrapy-feed.md) explains the new offline public-page export adapter.

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[desktop,crawler,exchange,documents,security,team]"
osint sources
osint demo
osint init
osint run example.org --type domain --purpose "Authorized asset inventory CASE-001" --authorized
osint run example.org --type domain --free-only --purpose "Authorized free-source review" --authorized
```

On Linux/macOS, activate with `source .venv/bin/activate`. If shell activation is disabled, invoke `.venv/Scripts/osint.exe` or `.venv/bin/osint` directly. `python -m osint_framework` is equivalent.

In the delivered local Windows folder, the virtual environment is already installed. Run `.\.venv\Scripts\osint.exe sources` or use `.\osint.ps1 sources`.

`demo` is fully offline and clearly synthetic. It writes an HTML report, JSON, and graph exports under `demo-report/synthetic-demo`. Research commands require first-launch policy acceptance and a per-query purpose plus `--authorized`. Use `osint init --accept-policy` for deliberate noninteractive acceptance. A statement of authorization cannot verify the operator's actual consent or legal basis.

Each collection writes a separate run directory under `reports/`. Reports contain full evidence and may contain personal data. The SQLite audit stores the purpose, query type and SHA-256 fingerprint, source statuses, and run IDs. Audit and pacing state defaults to `.osint-state/` in the current directory; use a common `--state PATH` across invocations that should share limits.

## Implemented sources

| Name | Input | Collection | Access |
|---|---|---|---|
| `github` | username | Public profile plus explicit self-reported fields | Default, no key |
| `bluesky` | username | Public Bluesky handle/profile | Default, no key; use full handle |
| `dns` | domain | A, AAAA, MX, NS, TXT through Google DNS | Default, no key |
| `crtsh` | domain | Certificate transparency names, restricted to queried domain | Default, no key |
| `rdap` | domain, IP | Registration metadata through RDAP bootstrap | Default, no key |
| `phone_local` | E.164 phone | Offline numbering-plan metadata | Default, no key; no owner/current-location claim |
| `twilio` | phone | Basic validation via Twilio Lookup v2 | Opt-in, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` |
| `hibp` | email | Breach names attributed to Have I Been Pwned | Opt-in, `HIBP_API_KEY` |
| `hunter` | email | Provider email verification result | Opt-in, `HUNTER_API_KEY` |
| `virustotal` | domain, IP | Existing analysis/reputation metadata | Opt-in, `VIRUSTOTAL_API_KEY` |
| `shodan` | IP | Existing Shodan host summary | Opt-in, `SHODAN_API_KEY` |
| `brave` | name, username, domain, email | Up to a bounded set of indexed web results | Opt-in, `BRAVE_SEARCH_API_KEY` |
| `phone_search` | phone | Exact-number search snippets and nearby public email leads | Opt-in, `BRAVE_SEARCH_API_KEY` or desktop session key |
| `phone_pages` | phone | Number and nearby public email observations from approved page URLs | Opt-in, exact host scope and permission reference |
| `webpage` | URL | Public HTML page metadata, links, and published mailto addresses | Explicit host scope and terms reference |
| `scrapy_pages` | URL, domain | Scrapy selectors and a bounded same-origin crawl through the shared transport | Opt-in; `crawler` extra, exact host scope and permission reference |
| `subfinder` | domain | Installed Subfinder, passive `crtsh` source only | Opt-in; executable on PATH |
| `internetdb` | public IPv4 | Existing port, hostname and CVE observations | Opt-in, no key; free noncommercial terms |
| `ripe` | public IP | Routing prefix and origin ASNs | Opt-in, no key; RIPEstat terms |
| `wayback` | domain, URL | Closest archived capture locator and time | Opt-in, no key |
| `wikidata` | name | Labeled knowledge-entity candidates | Opt-in, no key |
| `wikipedia` | name, domain | English encyclopedia article candidates | Opt-in, no key |
| `hackernews` | username | Exact public profile metadata | Opt-in, no key |
| `email_dns` | email | Domain MX, SPF and DMARC; no mailbox verification | Opt-in, no key; sends domain only |
| `urlscan` | domain, public IP | Existing public scan records; no submission | Opt-in, free-account `URLSCAN_API_KEY` |

Keyed providers may charge for requests and may restrict returned fields by plan. Keys come from task-local desktop credentials or process environment variables; `.env` is a template only and is not automatically loaded. No keys are supplied. Optional OS keychain storage rejects unapproved/plaintext backends. Errors and reports omit credential-bearing API query URLs. A provider observation does not prove ownership of an identifier.

```powershell
# A public organization account; sends one selected provider query.
osint run octocat --type username --modules github --purpose "Authorized public profile demonstration" --authorized

# Permission reference is an operator-reviewed policy URL, not automatic legal approval.
osint run https://example.org/ --type url --modules webpage --allow-host example.org --terms-url https://example.org/terms --purpose "Authorized review CASE-002" --authorized

# Free encyclopedia/knowledge search for a name:
osint run "Example Organization" --type name --modules wikidata,wikipedia --purpose "Public organization research CASE-003" --authorized
# General indexed web search requires the configured Brave key:
osint run "Example Organization" --type name --modules brave --purpose "Public organization research CASE-003" --authorized

osint run example.org --type domain --modules subfinder --purpose "Authorized asset inventory CASE-004" --authorized
```

The crawler uses HTTPS port 443, exact-host scope, public DNS addresses pinned to the connection, no redirects, no login/cookie handling, no query-string crawling, and no anti-bot evasion. robots.txt failures deny collection; a 404 is treated as no published robots policy. Source terms must still permit the activity. Default 3 pages, maximum 20, with conservative request pacing. Linked external pages are observations only and are not fetched.

The Subfinder runner does not install or update third-party code. It supplies explicit config files, disables update checks, uses one passive source, imposes 1 HTTP request/second and 1 minute upstream limits, and terminates after 90 seconds. Its network behavior depends on the installed upstream binary honoring those flags; it is not a network sandbox. Review and pin the binary you install. Other tool runners are deliberately not advertised as working integrations.

## GitHub tool interoperability

| Import name | Supported export | Behavior |
|---|---|---|
| `sherlock` | Official CSV with username/name/url_user/exists fields | Explicit positive rows, exact username |
| `maigret` | Simple JSON mapping, positive nested status | Explicit positives, exact username, no similar-name claims |
| `subfinder` | JSONL with host, optional input and source(s) | Exact domain/subdomain boundary |
| `canonical` | Finding JSON, JSON array, JSONL, or `{"findings": [...]}` | Validates schema and query subject |
| `scrapy` | JSON/JSONL items with `url` and `text`, optional `title`, `observed_at` | Public-page-v1 contract; exact queried phone and nearby email leads |
| `spiderfoot` | `scanexportjsonmulti` JSON event array | Selected typed events, matching scan target, excludes marked false positives |
| `amass` | v5 `oam_subs -names -nocolor` text | Domain/subdomain names only; no invented provider/timestamp data |
| `theharvester` | v5 completed-result JSONL, summary then records | Domain-scoped hostname/email/URL plus reported IP observations; preserves partial-source status |
| `opencti` | STIX 2.1 Bundle JSON | Supported cyber-observables, explicit relationships, framework evidence notes, and markings |
| `recon_ng` | Hosts/contacts CSV with headers enabled | Scoped host/IP/email observations |
| `photon` | Named-dataset `exported.json` | Internal URLs and subdomains only |
| `whatsmyname` | Local `wmn-data.json` | Unchecked candidate URLs; no account-existence lookup |
| `misp` | Single Event with Attribute array | Exact-query typed attributes; tags and distribution retained; no identity links inferred from event membership |

```powershell
osint import-results examples/sherlock.csv --tool sherlock --query demo_user --type username --purpose "Synthetic export compatibility CASE-005" --authorized
osint import-results examples/subfinder.jsonl --tool subfinder --query example.org --type domain --purpose "Synthetic export compatibility CASE-006" --authorized
osint export-schema --out finding.schema.json
```

Imports are offline, capped at 10 MB, scoped to one query, and labeled with the file SHA-256 and import receipt time. A source observation time is preserved when supplied; otherwise the receipt time is explicitly identified. Imported confidence stays conservative. Imports reject invalid structures and result-count overflow rather than silently pretending to understand an arbitrary upstream version. The default finding cap is 500 per source/import; `--max-findings` can raise it to 2000.

[Tool research](docs/tool-research.md) records upstream references and boundaries. The [v0.4 contracts](docs/free-and-team-v04.md#community-tool-imports) add Recon-ng, Photon and WhatsMyName subsets to the [v0.3 integrations](docs/integrations-v03.md). No upstream scanner or site database is bundled. File imports remain offline. The separate `opencti-send` command explicitly transfers a report through the official connector helper when its optional dependency, server and credentials are configured.

## Cases and local documents

```powershell
osint init
$caseId = osint cases create "Example organization review"
osint run example.org --type domain --modules dns --purpose "Authorized organization review" --authorized --case $caseId
osint import-results examples/amass-names.txt --tool amass --query example.org --type domain --purpose "Synthetic import review" --authorized --case $caseId
osint document examples/document.txt example.org --type domain --purpose "Synthetic document review" --authorized --case $caseId
osint cases show $caseId
osint cases export $caseId --out reports/case-export
osint cases export $caseId --out reports/case-export --stix
osint cases verify $caseId
osint doctor
```

Cases are stored in `.osint-state/cases.sqlite3`. Immutable report versions have content digests; notes and analyst decisions are separate history. The ledger retains first/last recorded sightings, underlying source names, and content changes when hashes are available. Repeated sightings do not increase confidence. A receipt timestamp is labeled as such when source collection time is unknown.

TXT/Markdown/HTML, text-bearing PDF, DOCX paragraphs/tables, and supported images can be searched locally for an exact query and nearby email mentions. Documents are parsed in a separate process with time, size, and output limits; image OCR uses Tesseract. Findings retain a file hash, page/paragraph/table location, and excerpt. The original is preserved with an inert `.bin` extension. The process is isolated from API credentials but is **not an operating-system sandbox**. Scanned PDF OCR and `.doc` files are not supported.

`--preserve-pages` saves permitted retrieved HTML response bytes as inert `.txt` evidence, with URL, time, and SHA-256 in the report; it does not capture keyed API responses. `cases verify` checks saved report digests and preserved files. Keep the evidence directory when moving reports: artifact references are local absolute paths. Workspaces use plaintext by default. `osint vault init --state NEW_PATH` enables encryption for a new workspace; automatic evidence then uses encrypted files, while explicit report/STIX exports create plaintext. See [encryption details](docs/free-and-team-v04.md#encrypted-workspace).

## Evidence and reports

Every `Finding` includes typed subject and object, source, relationship, `certain` / `likely` / `tentative` claim confidence, timestamp, evidence URL, and legal-basis reference. Imported findings additionally carry file provenance. The graph deduplicates identical evidence and joins only exactly matching typed identifiers. It never equates names, merges people based on username reuse, or turns repeated weak evidence into certainty. If source confidence conflicts for an identical relationship, the displayed edge retains the weaker confidence.

The self-contained HTML report provides source outcomes, searchable evidence, filters, and a local graph view. It loads no external scripts or images. JSON and GraphML support further analysis. Evidence remains available in full even when a graph view caps displayed nodes. Source failures and throttling are distinguished from empty results.

## Reliability and extension

- Async concurrency capped at four modules; individual module deadline 240 seconds.
- Built-in HTTP request budget: 50 per run by default, configurable from 1 to 200; redirects and robots requests count. External Subfinder has its separate fixed limits.
- Per-request source pacing persisted in SQLite; 429 and Retry-After cooldowns retained across runs.
- No unlimited rate option. Per-query pacing and explicit source selection; no bulk person mode or automatic pivoting.
- Read-only GET adapters plus allowlisted URLhaus/ThreatFox lookup POSTs; no submissions, malware downloads, active port scanning, password-reset probing, breach dump ingestion, or reverse-phone owner service.
- Phone search does not automatically crawl discovered pages or launch follow-up queries on extracted emails. Direct page checks require the operator's explicit page/host scope.
- Plugins use the `osint_framework.modules` entry-point group and load only through `--plugin NAME` after their installed distribution matches `OSINT_PLUGIN_LOCK`. They remain trusted Python code. Subfinder requires `OSINT_SUBFINDER_SHA256`. See [v0.5 approval steps](docs/release-v05.md).
- `osint audit-verify` checks hash-chain consistency. This detects ordinary edits, not a malicious writer who recomputes the chain. Optional workspace encryption is described above.
- Persistent jobs and finite schedules share local pacing and case storage. Expired worker leases become stale without automatic request replay.
- The optional team API has admin/analyst/viewer roles, per-case access, expiring revocable tokens, OIDC verification, request limits and source allowlists. CLI serving binds to loopback. Optional Docker/PostgreSQL and TLS proxy templates need deployment-specific validation.

## Development

```powershell
python -m pip install -e ".[dev,desktop,crawler,exchange,documents,security,team,postgres,evidence]"
python -m pytest -q
python -m ruff check src tests scripts
python scripts/check_secrets.py
python -m build --no-isolation
```

Tests use local fixtures and mock transports, not real people or paid APIs. Live API behavior, paid plans, third-party binary versions, and provider terms require deployment-specific verification. See [source references](docs/sources.md), [revised specification](docs/project-spec.md), [LEGAL.md](LEGAL.md), [ETHICS.md](ETHICS.md), and [CONTRIBUTING.md](CONTRIBUTING.md).

See [validation details](docs/validation.md) for completed checks and their limits, and [CHANGELOG.md](CHANGELOG.md) for this release. `requirements-dev.lock` records the tested Windows environment, including validation tooling; the optional OpenCTI SDK has a separate installation path. Run `python scripts/package_release.py --snapshot-only`, `python -m build --no-isolation`, then `python scripts/package_release.py` to create the wheel, source distribution, source ZIP and current-version checksum manifest under `dist/`, excluding live reports, keys, and audit state. `python scripts/verify_install.py --out PATH --desktop --integrations --operations` checks an installed wheel in a fresh output directory, including a temporary authenticated loopback API.
