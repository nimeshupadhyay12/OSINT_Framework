import asyncio
from types import SimpleNamespace

import pytest

from osint_framework.core.http import SourceError, SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.integrations.subfinder import SubfinderModule


async def test_subfinder_fixed_passive_arguments_and_scope(monkeypatch):
    import osint_framework.integrations.subfinder as runner

    calls = []

    class Limiter:
        async def acquire(self, *args):
            calls.append(args)

    class Process:
        returncode = 0

        def __init__(self):
            self.stdout = asyncio.StreamReader()
            self.stdout.feed_data(b'{"host":"www.example.org","input":"example.org","source":"crtsh"}\n')
            self.stdout.feed_eof()
            self.stderr = asyncio.StreamReader()
            self.stderr.feed_eof()

        async def wait(self):
            return self.returncode

    async def launch(*args, **kwargs):
        calls.append((args, kwargs))
        return Process()

    monkeypatch.setattr(runner.shutil, "which", lambda _: "/trusted/subfinder")
    monkeypatch.setattr(runner, "verify_binary", lambda *_: "a" * 64)
    monkeypatch.setattr(runner.asyncio, "create_subprocess_exec", launch)
    monkeypatch.setenv("SHODAN_API_KEY", "should-not-leak")
    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic runner test", authorized=True)
    findings = await SubfinderModule().run(context, SimpleNamespace(limiter=Limiter()))
    args, kwargs = calls[1]
    assert args[args.index("-s") + 1] == "crtsh"
    assert args[args.index("-rl") + 1] == "1"
    assert args[args.index("-max-time") + 1] == "1"
    assert "-active" not in args and "-all" not in args and "-duc" in args
    assert "SHODAN_API_KEY" not in kwargs["env"]
    assert findings[0].object.value == "www.example.org"
    assert findings[0].metadata["collection_mode"] == "bounded_subfinder_passive_runner"


async def test_missing_subfinder_is_skipped(monkeypatch):
    import osint_framework.integrations.subfinder as runner

    monkeypatch.setattr(runner.shutil, "which", lambda _: None)
    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic runner test", authorized=True)
    with pytest.raises(SourceSkipped, match="not installed"):
        await SubfinderModule().run(context, object())


async def test_subfinder_oversized_output_kills_process(monkeypatch):
    import osint_framework.integrations.subfinder as runner

    class Limiter:
        async def acquire(self, *_):
            pass

    class Process:
        returncode = None
        killed = False

        def __init__(self):
            self.stdout = asyncio.StreamReader()
            self.stdout.feed_data(b"x" * 10_000_001)
            self.stdout.feed_eof()
            self.stderr = asyncio.StreamReader()
            self.stderr.feed_eof()

        def kill(self):
            self.killed = True
            self.returncode = -1

        async def wait(self):
            return self.returncode

    process = Process()

    async def launch(*args, **kwargs):
        return process

    monkeypatch.setattr(runner.shutil, "which", lambda _: "/trusted/subfinder")
    monkeypatch.setattr(runner, "verify_binary", lambda *_: "a" * 64)
    monkeypatch.setattr(runner.asyncio, "create_subprocess_exec", launch)
    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic runner test", authorized=True)
    with pytest.raises(SourceError, match="size budget"):
        await SubfinderModule().run(context, SimpleNamespace(limiter=Limiter()))
    assert process.killed
