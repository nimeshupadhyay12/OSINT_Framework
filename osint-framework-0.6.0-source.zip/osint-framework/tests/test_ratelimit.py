"""Persistent pacing tests use a virtual clock and never sleep in real time."""

import pytest

from osint_framework.core import ratelimit
from osint_framework.core.audit import AuditLog
from osint_framework.core.ratelimit import RateLimited, RateLimiter


class Clock:
    def __init__(self):
        self.now = 1000.0
        self.sleeps = []
        self.on_sleep = None

    async def sleep(self, seconds):
        self.sleeps.append(seconds)
        self.now += seconds
        if self.on_sleep:
            callback, self.on_sleep = self.on_sleep, None
            callback()


@pytest.fixture
def clock(monkeypatch):
    clock = Clock()
    monkeypatch.setattr(ratelimit.time, "time", lambda: clock.now)
    monkeypatch.setattr(ratelimit.time, "monotonic", lambda: clock.now)
    monkeypatch.setattr(ratelimit.asyncio, "sleep", clock.sleep)
    return clock


async def test_requests_and_query_rates_persist_across_instances(tmp_path, clock):
    first = RateLimiter(AuditLog(tmp_path))
    second = RateLimiter(AuditLog(tmp_path))
    await first.acquire("queries:url", 10)
    await second.acquire("queries:url", 10)
    await first.acquire("queries:url", 10)
    assert clock.sleeps == [6, 6]
    assert clock.now == 1012


async def test_stricter_robots_rate_applies_to_previous_request(tmp_path, clock):
    limiter = RateLimiter(AuditLog(tmp_path))
    await limiter.acquire("webpage", 6)
    await limiter.acquire("webpage", 2)
    assert clock.sleeps == [30]


async def test_cooldown_survives_restart_and_is_not_shortened(tmp_path, clock):
    limiter = RateLimiter(AuditLog(tmp_path))
    limiter.defer("github", 172800)
    limiter.defer("github", 2)
    with pytest.raises(RateLimited, match="172800"):
        await RateLimiter(AuditLog(tmp_path)).acquire("github", 10)
    assert not clock.sleeps


async def test_new_cooldown_interrupts_an_already_waiting_request(tmp_path, clock):
    first = RateLimiter(AuditLog(tmp_path))
    second = RateLimiter(AuditLog(tmp_path))
    await first.acquire("github", 10)
    clock.on_sleep = lambda: second.defer("github", 3600)
    with pytest.raises(RateLimited, match="3600"):
        await first.acquire("github", 10)
    assert clock.sleeps == [6]


async def test_sources_have_independent_but_persistent_clocks(tmp_path, clock):
    limiter = RateLimiter(AuditLog(tmp_path))
    await limiter.acquire("github", 10)
    await limiter.acquire("rdap", 10)
    assert not clock.sleeps


async def test_expired_cooldown_allows_requests(tmp_path, clock):
    limiter = RateLimiter(AuditLog(tmp_path))
    await limiter.acquire("github", 10)
    limiter.defer("github", 20)
    clock.now += 21
    await RateLimiter(AuditLog(tmp_path)).acquire("github", 10)
    assert not clock.sleeps


@pytest.mark.parametrize("rate", [0, 61, True, 1.5])
async def test_invalid_rates_rejected(tmp_path, clock, rate):
    with pytest.raises(ValueError):
        await RateLimiter(AuditLog(tmp_path)).acquire("github", rate)


@pytest.mark.parametrize("seconds", [float("nan"), float("inf"), -1])
def test_invalid_cooldowns_do_not_corrupt_state(tmp_path, clock, seconds):
    with pytest.raises(ValueError):
        RateLimiter(AuditLog(tmp_path)).defer("github", seconds)
