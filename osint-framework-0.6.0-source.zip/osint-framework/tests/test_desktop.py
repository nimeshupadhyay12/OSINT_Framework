"""Optional, network-free native UI checks. Core CI can run without PySide6."""

import os
import time
from pathlib import Path

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtCore import QTimer  # noqa: E402
from PySide6.QtWidgets import QApplication, QLineEdit  # noqa: E402

from osint_framework import desktop  # noqa: E402
from osint_framework.core.audit import AuditLog  # noqa: E402


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def window(app, tmp_path, monkeypatch):
    monkeypatch.delenv("BRAVE_SEARCH_API_KEY", raising=False)
    result = desktop.PhoneWindow(tmp_path / "state", tmp_path / "reports")
    yield result
    if result._worker is not None:
        assert result._worker.wait(10_000)
        app.processEvents()
    result.close()
    result.deleteLater()
    app.processEvents()


def fill_valid_request(window):
    window.number_input.setText("+1 202-555-0123")
    window.purpose_input.setText("My own number exposure review")
    window.authorized_check.setChecked(True)


def wait_for_worker(app, window):
    deadline = time.monotonic() + 10
    while window._worker is not None and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.005)
    assert window._worker is None


def test_default_is_local_and_requires_per_run_authorization(window):
    assert not window.authorized_check.isChecked()
    assert not window.search_toggle.isChecked()
    assert window.region_input.text() == ""
    assert "no internet" in window.scope_label.text()
    assert "No Brave key" in window.key_status.text()
    assert window.api_key_input.echoMode() == QLineEdit.EchoMode.Password
    window._start_run()
    assert "authorization" in window.error_label.text()
    assert not window.state_dir.exists()


def test_validation_precedes_consent_and_country_is_never_guessed(window):
    fill_valid_request(window)
    window.number_input.setText("2025550123")
    window._start_run()
    assert "country" in window.error_label.text()
    assert not window.state_dir.exists()
    window.region_input.setText("US")
    assert window.build_request().context().query == "+12025550123"
    window.purpose_input.setText("x")
    window._start_run()
    assert window._worker is None
    assert not window.state_dir.exists()


def test_search_needs_key_and_secret_never_enters_request(window):
    fill_valid_request(window)
    window.search_toggle.setChecked(True)
    with pytest.raises(ValueError, match="Brave API key"):
        window.build_request()
    window.api_key_input.setText("session-test-secret-123")
    request = window.build_request()
    assert request.search_web
    assert "session-test-secret-123" not in request.model_dump_json()
    assert "session-test-secret-123" not in request.context().model_dump_json()
    assert "Internet selected" in window.scope_label.text()
    assert "this session" in window.key_status.text()


def test_environment_key_availability_and_scope(window, monkeypatch):
    fill_valid_request(window)
    monkeypatch.setenv("BRAVE_SEARCH_API_KEY", "test-env-secret")
    window.search_toggle.setChecked(True)
    assert window.build_request().search_web
    assert "environment" in window.key_status.text()
    assert "test-env-secret" not in window.key_status.text()


@pytest.mark.parametrize("page,hosts,terms", [
    ("https://example.org/contact", "example.org", ""),
    ("https://example.org/contact", "other.example.org", "https://example.org/terms"),
    ("http://example.org/contact", "example.org", "https://example.org/terms"),
])
def test_approved_pages_require_explicit_valid_scope(window, page, hosts, terms):
    fill_valid_request(window)
    window.page_urls_input.setPlainText(page)
    window.hosts_input.setText(hosts)
    window.terms_input.setText(terms)
    window._start_run()
    assert window._worker is None
    assert not window.state_dir.exists()
    assert window.error_label.text()


def test_valid_approved_page_and_collapsing_never_hides_scope(window):
    fill_valid_request(window)
    window.page_urls_input.setPlainText("https://example.org/contact")
    window.hosts_input.setText("example.org")
    window.terms_input.setText("https://example.org/terms")
    window.pages_toggle.setChecked(True)
    window.pages_toggle.setChecked(False)
    assert "approved page collection" in window.scope_label.text()
    request = window.build_request()
    assert request.seed_urls == ["https://example.org/contact"]


def test_demo_renders_two_synthetic_leads_and_does_not_accept_policy(app, window):
    opened = []
    # Rendering and row selection never open a source automatically.
    window._open_url = opened.append
    window._start_demo()
    wait_for_worker(app, window)
    assert window.lead_table.rowCount() == 2
    assert "SYNTHETIC" in window.result_badge.text()
    assert "SYNTHETIC" in window.association_note.text()
    assert "unverified" in window.excerpt.toPlainText()
    assert not window.state_dir.exists()
    assert opened == []
    assert window.report_button.isEnabled()
    assert window._outcome.paths["html"].is_file()
    window._open_selected_source()
    assert opened == ["https://example.org/contact"]
    window.show()
    app.processEvents()
    screenshot = window.grab()
    assert not screenshot.isNull()
    assert screenshot.width() >= 1000


def test_local_collection_stays_responsive_and_has_honest_empty_state(app, window):
    fill_valid_request(window)
    ticks = []
    timer = QTimer()
    timer.setInterval(1)
    timer.timeout.connect(lambda: ticks.append(True))
    timer.start()
    window._start_run()
    active = window._worker
    assert not window.form.isEnabled()
    window._start_run()
    assert window._worker is active
    wait_for_worker(app, window)
    timer.stop()
    assert ticks
    assert window.form.isEnabled()
    assert "LOCAL ONLY" in window.result_badge.text()
    assert "No email leads found from the selected sources" in window.leads_empty.text()
    assert "does not mean no email exists" in window.leads_empty.text()
    assert window.status_table.item(0, 0).text() == "phone_local"
    assert window.status_table.item(0, 1).text() == "ok"
    assert window.metadata_table.rowCount() >= 8
    assert AuditLog(window.state_dir).consented()
    assert AuditLog(window.state_dir).verify()[0]


def test_worker_errors_do_not_echo_secrets_and_clear_memory(tmp_path, monkeypatch):
    secret = "secret-should-never-appear"

    async def fail(*args, **kwargs):
        raise RuntimeError("Authorization: " + secret)

    monkeypatch.setattr(desktop, "run_phone", fail)
    request = desktop.PhoneRequest(number="+12025550123", purpose="Authorized test request", authorized=True)
    worker = desktop.PhoneWorker(request, tmp_path / "state", tmp_path / "reports", api_key=secret)
    failures = []
    worker.failed.connect(failures.append)
    worker.run()
    assert failures and secret not in failures[0]
    assert worker.api_key is None
    assert secret.encode() not in (tmp_path / "state" / "audit.sqlite3").read_bytes()


def test_no_secret_in_saved_demo_report(window):
    secret = "key-must-not-be-persisted"
    window.api_key_input.setText(secret)
    outcome = desktop.synthetic_outcome(window.out_dir)
    window.render_outcome(outcome)
    for path in outcome.paths.values():
        assert secret.encode() not in Path(path).read_bytes()


def test_untrusted_excerpts_are_plain_text(window):
    outcome = desktop.synthetic_outcome(window.out_dir)
    for result in outcome.report.results:
        for finding in result.findings:
            finding.metadata["excerpt"] = '<img src="https://example.org/tracker"> & <script>alert(1)</script>'
    window.render_outcome(outcome)
    assert "<script>" in window.excerpt.toPlainText()


def test_missing_optional_dependency_has_actionable_install_message(monkeypatch, tmp_path):
    monkeypatch.setattr(desktop, "QT_AVAILABLE", False)
    with pytest.raises(RuntimeError, match=r'pip install "\.\[desktop\]"'):
        desktop.launch(tmp_path / "state", tmp_path / "reports")
