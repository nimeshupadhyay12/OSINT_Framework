import hashlib
import json
import sqlite3
import time
import uuid
import zipfile
from types import SimpleNamespace

import httpx
import pytest

from osint_framework.core.database import Row, postgres_sql
from osint_framework.core.http import HttpClient, SourceSkipped
from osint_framework.core.schema import QueryContext, RunReport
from osint_framework.evidence import bundle, export_warc, new_signing_key, verify_bundle
from osint_framework.integrations.imports import parse_import
from osint_framework.integrations.misp_exchange import export_misp
from osint_framework.modules.threat_sources import (
    CertSpotterModule,
    CommonCrawlModule,
    OTXModule,
    ThreatFoxModule,
    URLhausModule,
)
from osint_framework.team import TeamStore


def context(kind="domain", query="example.org"):
    return QueryContext(input_type=kind, query=query, purpose="Synthetic boundary validation", authorized=True)


class HTTP:
    def __init__(self, *values):
        self.values, self.calls = iter(values), []

    async def get_json(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return next(self.values)

    get_text = get_json
    lookup_json = get_json


class Limiter:
    async def acquire(self, *_):
        pass


@pytest.fixture
def keys(monkeypatch):
    for name in ("ABUSECH_AUTH_KEY", "CERTSPOTTER_API_KEY", "OTX_API_KEY"):
        monkeypatch.setenv(name, "synthetic-fixture-key")


async def test_certificate_and_crawl_scoped_deduplication(keys):
    rows = await CertSpotterModule().run(context(), HTTP([{"id": "1", "dns_names": ["*.example.org", "www.example.org", "elsewhere.org", "www.example.org"]}]))
    assert {f.object.value for f in rows} == {"example.org", "www.example.org"}
    assert all(f.confidence == "tentative" for f in rows)
    http = HTTP([{"id": "CC-MAIN-2026-30"}], json.dumps({"url": "https://www.example.org/a", "timestamp": "20260101000000"}))
    rows = await CommonCrawlModule().run(context(), http)
    assert len(http.calls) == 2 and rows[0].metadata["coverage"] == "first_index_page_only"
    with pytest.raises(ValueError, match="outside"):
        await CommonCrawlModule().run(context(), HTTP([{"id": "CC-MAIN-2026-30"}], '{"url":"https://example.org.evil.com/"}'))
    with pytest.raises(ValueError, match="identifier"):
        await CommonCrawlModule().run(context(), HTTP([{"id": "../../submit"}]))


async def test_threat_claims_and_scope(keys):
    rows = await OTXModule().run(context(), HTTP({"indicator": "example.org", "pulse_info": {"count": 2}}))
    assert rows[0].metadata["pulse_count"] == 2 and rows[0].confidence == "tentative"
    with pytest.raises(ValueError, match="another"):
        await OTXModule().run(context(), HTTP({"indicator": "other.org"}))
    rows = await URLhausModule().run(context(), HTTP({"query_status": "ok", "urls": [{"url": "https://example.org/a", "threat": "fixture"}]}))
    assert rows[0].object.value == "https://example.org/a"
    with pytest.raises(ValueError, match="out-of-scope"):
        await URLhausModule().run(context(), HTTP({"query_status": "ok", "urls": [{"url": "https://other.org/"}]}))
    rows = await ThreatFoxModule().run(context("ip", "1.1.1.1"), HTTP({"query_status": "ok", "data": [{"ioc": "1.1.1.1:443", "ioc_type": "ip:port"}]}))
    assert rows[0].confidence == "tentative"
    with pytest.raises(ValueError, match="another"):
        await ThreatFoxModule().run(context(), HTTP({"query_status": "ok", "data": [{"ioc": "other.org", "ioc_type": "domain"}]}))


@pytest.mark.parametrize("module", [OTXModule, URLhausModule, ThreatFoxModule])
async def test_threat_empty_and_private_ip(module, keys):
    if module != OTXModule:
        assert await module().run(context(), HTTP({"query_status": "no_result"})) == []
    with pytest.raises(SourceSkipped, match="globally"):
        await module().run(context("ip", "127.0.0.1"), HTTP())


async def test_post_boundary_allows_only_read_lookups():
    requests = []
    def handle(request):
        requests.append(request)
        return httpx.Response(200, json={"query_status": "no_result"})
    async with HttpClient(Limiter(), httpx.AsyncClient(transport=httpx.MockTransport(handle))) as client:
        await client.lookup_json("https://urlhaus-api.abuse.ch/v1/host/", source="urlhaus", payload={"host": "example.org"}, rate_limit_per_min=4)
        assert requests[0].method == "POST" and requests[0].content == b"host=example.org"
        for url, source, payload in [
            ("https://urlhaus-api.abuse.ch/v1/url/", "urlhaus", {"url": "https://example.org/", "submit": True}),
            ("https://threatfox-api.abuse.ch/api/v1/", "threatfox", {"query": "submit_ioc", "search_term": "x", "exact_match": True}),
            ("https://example.org/", "urlhaus", {"host": "example.org"})]:
            with pytest.raises(SourceSkipped):
                await client.lookup_json(url, source=source, payload=payload, rate_limit_per_min=4)
        assert len(requests) == 1


def test_token_expiry_legacy_migration_and_rate_limit(tmp_path):
    db = sqlite3.connect(tmp_path / "cases.sqlite3")
    db.execute("CREATE TABLE principals(name TEXT PRIMARY KEY,role TEXT,token_sha256 TEXT UNIQUE,revoked INTEGER DEFAULT 0)")
    db.execute("INSERT INTO principals VALUES('legacy','admin',?,0)", (hashlib.sha256(b"legacy").hexdigest(),))
    db.commit()
    db.close()
    store = TeamStore(tmp_path)
    assert store.principal("legacy") is None
    token = store.rotate_token("legacy", days=1)
    assert store.principal(token)["role"] == "admin"
    assert store.rate_allowed("fixture", 2) and store.rate_allowed("fixture", 2)
    assert not TeamStore(tmp_path).rate_allowed("fixture", 2)
    assert store.rate_allowed("another", 2)
    with store.connect() as db:
        db.execute("UPDATE principals SET expires_at=?", (time.time() - 1,))
    assert store.principal(token) is None and store.active_user("legacy") is None
    with pytest.raises(ValueError):
        store.issue_token("bad", "admin", days=91)


def test_oidc_signature_audience_role_mapping_and_revocation(tmp_path, monkeypatch):
    jwt = pytest.importorskip("jwt")
    pytest.importorskip("cryptography")
    from cryptography.hazmat.primitives.asymmetric import rsa

    from osint_framework.oidc import OIDCVerifier
    monkeypatch.setenv("OSINT_OIDC_ISSUER", "https://idp.example.org/")
    monkeypatch.setenv("OSINT_OIDC_AUDIENCE", "osint-api")
    monkeypatch.setenv("OSINT_OIDC_JWKS_URL", "https://idp.example.org/keys")
    monkeypatch.setenv("OSINT_OIDC_REQUIRED_ACR", "mfa")
    private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    verifier = OIDCVerifier()
    monkeypatch.setattr(verifier.keys, "get_signing_key_from_jwt", lambda token: SimpleNamespace(key=private.public_key()))
    store = TeamStore(tmp_path)
    store.issue_token("researcher", "viewer")
    store.bind_oidc("researcher", verifier.issuer, "fixture-subject")
    claims = {"iss": verifier.issuer, "aud": "osint-api", "sub": "fixture-subject", "iat": int(time.time()), "exp": int(time.time()) + 600, "acr": "mfa", "role": "admin"}
    def encode(**changes):
        return jwt.encode({**claims, **changes}, private, algorithm="RS256")
    assert verifier.principal(encode(), store)["role"] == "viewer"
    for changes in ({"aud": "other"}, {"sub": "unbound"}, {"exp": 1}, {"acr": "password"}, {"iss": "https://evil.org/"}):
        assert verifier.principal(encode(**changes), store) is None
    store.revoke("researcher")
    assert verifier.principal(encode(), store) is None


def test_misp_scope_markings_and_non_actionable_export(tmp_path):
    uid = str(uuid.uuid4())
    file = tmp_path / "event.json"
    file.write_text(json.dumps({"Event": {"distribution": "0", "Tag": [{"name": "tlp:amber"}], "Attribute": [
        {"type": "domain", "value": "example.org", "uuid": uid},
        {"type": "domain", "value": "other.org", "uuid": str(uuid.uuid4())}]}}))
    findings = parse_import("misp", file, context())
    assert len(findings) == 1 and findings[0].metadata["misp_event_tags"][0]["name"] == "tlp:amber"
    report = RunReport(run_id="misp-test", context=context(), results=[{"module": "import:misp", "status": "ok", "findings": findings}], graph={})
    event = export_misp(report)["Event"]
    assert event["distribution"] == "0" and event["published"] is False
    assert event["Attribute"][0]["to_ids"] is False
    assert event["Attribute"][0]["Tag"][0]["name"] == "tlp:amber"
    findings[0].metadata["stix_object_marking_refs"] = ["marking-definition--example"]
    with pytest.raises(ValueError, match="markings"):
        export_misp(report)


def test_signed_bundle_detects_tampering_wrong_key_and_artifact_escape(tmp_path):
    pytest.importorskip("cryptography")
    root = tmp_path / "evidence"
    root.mkdir()
    file = root / "page.txt"
    file.write_bytes(b"synthetic page")
    report = RunReport(run_id="bundle-test", context=context(), results=[], graph={}, artifacts=[{
        "url": "https://example.org/", "path": str(file), "bytes": file.stat().st_size,
        "sha256": hashlib.sha256(file.read_bytes()).hexdigest(), "captured_at": "2026-09-14T00:00:00Z"}])
    key = tmp_path / "signing.key"
    public = new_signing_key(key, "synthetic passphrase")
    archive = tmp_path / "bundle.zip"
    bundle(report, archive, key, "synthetic passphrase", tmp_path / "state", root)
    assert verify_bundle(archive, public)["files"] == 2
    other = new_signing_key(tmp_path / "other.key", "synthetic passphrase")
    with pytest.raises(ValueError, match="signature"):
        verify_bundle(archive, other)
    with zipfile.ZipFile(archive) as source, zipfile.ZipFile(tmp_path / "tampered.zip", "w") as target:
        for name in source.namelist():
            target.writestr(name, b"changed" if name == "report.json" else source.read(name))
    with pytest.raises(ValueError, match="changed"):
        verify_bundle(tmp_path / "tampered.zip", public)
    with pytest.raises(ValueError, match="outside"):
        bundle(report, tmp_path / "bad.zip", key, "synthetic passphrase", tmp_path / "state", tmp_path / "unrelated")
    pytest.importorskip("warcio")
    from warcio.archiveiterator import ArchiveIterator
    warc = tmp_path / "page.warc.gz"
    export_warc(report, warc, tmp_path / "state", root)
    with warc.open("rb") as stream:
        records = list(ArchiveIterator(stream))
        assert len(records) == 1 and records[0].rec_type == "resource"
        assert records[0].rec_headers.get_header("WARC-Target-URI") == "https://example.org/"


def test_postgres_sql_and_row_contract():
    assert postgres_sql("BEGIN IMMEDIATE").startswith("SELECT pg_advisory_xact_lock")
    assert "DOUBLE PRECISION" in postgres_sql("CREATE TABLE a(created REAL)")
    assert "IDENTITY" in postgres_sql("CREATE TABLE events(seq INTEGER PRIMARY KEY)")
    assert "ON CONFLICT(key)" in postgres_sql("INSERT OR REPLACE INTO settings VALUES(?,?)")
    assert "GREATEST(rate_slots.next_at" in postgres_sql("MAX(next_at,excluded.next_at)")
    row = Row(["name", "role"], ["alice", "viewer"])
    assert dict(row) == {"name": "alice", "role": "viewer"} and row[0] == "alice" and tuple(row) == ("alice", "viewer")
