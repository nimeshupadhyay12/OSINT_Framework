import asyncio
import json
import time
from concurrent.futures import ThreadPoolExecutor

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.cases import CaseStore
from osint_framework.core.schema import QueryContext
from osint_framework.core.vault import Vault
from osint_framework.jobs import JobStore, work_once
from osint_framework.team import TeamStore, create_app
from osint_framework.workflow import investigate


async def test_lost_lease_and_prestart_cancellation_do_not_replay(tmp_path):
    import threading
    store = JobStore(tmp_path)
    case = store.create("Worker interruption")
    identifier = store.enqueue(case, context(), ["phone_local"])
    async def expired(*args, **kwargs):
        assert store.claim(now=time.time() + 120) is None
        raise RuntimeError("Synthetic worker failure after expiry")
    assert (await work_once(tmp_path, tmp_path / "out", runner=expired))["status"] == "stale"
    assert store.job(identifier)["run_id"] is None
    store.enqueue(case, context(), ["phone_local"])
    stop = threading.Event()
    stop.set()
    async def never(*args, **kwargs):
        pytest.fail("Cancelled worker must not start collection")
    assert (await work_once(tmp_path, tmp_path / "out", runner=never, stop_event=stop))["status"] == "cancelled"


def test_token_rotation_and_case_access_removal(tmp_path):
    store = TeamStore(tmp_path)
    with pytest.raises(ValueError):
        store.issue_token("local", "analyst")
    old = store.issue_token("analyst", "analyst")
    case = store.create("Access removal")
    store.grant("analyst", case)
    assert store.allowed(store.principal(old), case, True)
    new = store.rotate_token("analyst")
    assert store.principal(old) is None and store.principal(new)
    store.ungrant("analyst", case)
    assert not store.allowed(store.principal(new), case)


def context():
    return QueryContext(query="+12025550123", input_type="phone", purpose="Synthetic local queue review", authorized=True)


async def test_encrypted_workspace_roundtrip_has_no_plaintext_evidence(tmp_path, monkeypatch):
    pytest.importorskip("cryptography")
    state, out = tmp_path / "state", tmp_path / "reports"
    Vault.initialize(state, "synthetic vault passphrase")
    AuditLog(state).accept_policy()
    store = CaseStore(state)
    case = store.create("Private synthetic title")
    result = await investigate(context(), ["phone_local"], state, out, case_id=case)
    store.note(case, "Private synthetic note")
    finding = result.report.results[0].findings[0]
    store.review(case, finding.id, "accepted", "Private synthetic reason")
    for path in list(state.glob("*.sqlite3")) + list(out.rglob("*.enc")):
        raw = path.read_bytes()
        assert b"+12025550123" not in raw and b"Private synthetic" not in raw
        assert context().purpose.encode() not in raw
    assert set(result.paths) == {"encrypted"}
    assert store.get(case)["title"] == "Private synthetic title"
    assert store.history(case)["notes"][0]["text"] == "Private synthetic note"
    assert store.reports(case)[0].run_id == result.report.run_id
    assert AuditLog(state).verify()[0]
    from osint_framework.core.vault import _KEYS
    _KEYS.clear()
    monkeypatch.delenv("OSINT_VAULT_PASSPHRASE", raising=False)
    with pytest.raises(ValueError, match="locked"):
        CaseStore(state)
    with pytest.raises(ValueError, match="Incorrect"):
        Vault.unlock_workspace(state, "incorrect passphrase")
    Vault.unlock_workspace(state, "synthetic vault passphrase")
    assert CaseStore(state).reports(case)[0].context.query == context().query


def test_vault_rejects_existing_directory_and_modified_ciphertext(tmp_path):
    pytest.importorskip("cryptography")
    vault = Vault.initialize(tmp_path, "synthetic vault passphrase")
    with pytest.raises(ValueError, match="empty"):
        Vault.initialize(tmp_path, "synthetic vault passphrase")
    encoded = vault.encode("secret fixture", "fixture")
    with pytest.raises(ValueError, match="authentication"):
        vault.decode(encoded, "different-record")
    path = tmp_path / "artifact.enc"
    vault.write_bytes(path, b"fixture bytes")
    assert vault.read_bytes(path) == b"fixture bytes"
    path.write_bytes(path.read_bytes()[:-1] + b"!")
    with pytest.raises(ValueError, match="authentication"):
        vault.read_bytes(path)


def test_concurrent_queue_claims_never_duplicate_and_expired_lease_is_stale(tmp_path):
    store = JobStore(tmp_path)
    case = store.create("Concurrent jobs")
    ids = [store.enqueue(case, context(), ["phone_local"]) for _ in range(4)]
    with ThreadPoolExecutor(max_workers=4) as pool:
        claims = list(pool.map(lambda _: JobStore(tmp_path).claim(), range(4)))
    assert {job["id"] for job, _ in claims} == set(ids)
    assert store.claim(now=time.time() + 100) is None
    assert all(store.job(identifier)["status"] == "stale" for identifier in ids)


async def test_worker_saves_case_and_finite_schedule_with_cancellation(tmp_path):
    AuditLog(tmp_path).accept_policy()
    store = JobStore(tmp_path)
    case = store.create("Scheduled synthetic fixture")
    identifier = store.enqueue(case, context(), ["phone_local"], repeat=2, interval_seconds=3600)
    result = await work_once(tmp_path, tmp_path / "out")
    assert result["status"] == "succeeded" and len(store.reports(case)) == 1
    child, = [job for job in store.jobs(case) if job["parent_id"] == identifier]
    assert child["remaining"] == 1 and child["due"] > time.time() + 3500
    store.cancel(identifier)
    assert store.job(child["id"])["status"] == "cancelled"
    assert await work_once(tmp_path, tmp_path / "out") is None


async def test_worker_failure_stops_future_schedule(tmp_path):
    store = JobStore(tmp_path)
    case = store.create("Failed job fixture")
    store.enqueue(case, context(), ["phone_local"], repeat=3, interval_seconds=3600)
    async def fail(*_, **__):
        raise ValueError("sensitive failure details")
    result = await work_once(tmp_path, tmp_path / "out", runner=fail)
    assert result["status"] == "failed" and len(store.jobs()) == 1
    assert "sensitive" not in result["error"]


def test_api_roles_case_isolation_source_allowlist_and_token_revocation(tmp_path):
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    AuditLog(tmp_path).accept_policy()
    store = TeamStore(tmp_path)
    tokens = {name: store.issue_token(name, role) for name, role in (("admin", "admin"), ("alice", "analyst"), ("bob", "analyst"), ("reader", "viewer"))}
    def auth(name):
        return {"Authorization": "Bearer " + tokens[name]}
    client = TestClient(create_app(tmp_path, trusted_hosts=["testserver"]))
    assert client.get("/cases").status_code == 401
    case = client.post("/cases", headers=auth("alice"), json={"title": "Alice investigation"}).json()["id"]
    assert client.get("/cases/" + case, headers=auth("bob")).status_code == 403
    assert client.get("/cases", headers=auth("bob")).json() == []
    assert client.post("/cases", headers=auth("reader"), json={"title": "Blocked creation"}).status_code == 403
    store.grant("reader", case)
    assert client.get("/cases/" + case, headers=auth("reader")).status_code == 200
    assert client.post(f"/cases/{case}/notes", headers=auth("reader"), json={"text": "Blocked"}).status_code == 403
    body = {"context": context().model_dump(mode="json"), "sources": ["phone_local"]}
    response = client.post(f"/cases/{case}/jobs", headers=auth("alice"), json=body)
    assert response.status_code == 202, response.text
    identifier = response.json()["id"]
    assert "lease" not in response.json()
    body["sources"] = ["twilio"]
    assert client.post(f"/cases/{case}/jobs", headers=auth("alice"), json=body).status_code == 403
    store.revoke("alice")
    assert client.get("/cases", headers=auth("alice")).status_code == 401
    async def forbidden(*_, **__):
        raise AssertionError("Revoked actor must not cause network activity")
    result = asyncio.run(work_once(tmp_path, tmp_path / "out", runner=forbidden))
    assert result["status"] == "cancelled" and result["id"] == identifier
    assert not any(token.encode() in store.path.read_bytes() for token in tokens.values())


def test_api_rejects_oversized_cross_origin_and_untrusted_host_requests(tmp_path):
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient
    AuditLog(tmp_path).accept_policy()
    client = TestClient(create_app(tmp_path, trusted_hosts=["testserver"]))
    assert client.post("/cases", content=b"x" * 65537).status_code == 413
    assert client.get("/health", headers={"Origin": "https://unrelated.example"}).status_code == 403
    assert client.get("/health", headers={"Host": "unrelated.example"}).status_code == 400


def test_queue_validates_source_and_schedule_budget(tmp_path):
    store = JobStore(tmp_path)
    case = store.create("Scope test case")
    for names, repeat, interval in ((["dns"], 1, 0), (["phone_local"], 101, 3600), (["phone_local"], 2, 1)):
        with pytest.raises(ValueError):
            store.enqueue(case, context(), names, repeat=repeat, interval_seconds=interval)
    assert json.loads(store.vault.encode("{}", "test")) == {}
