"""Network-free tests for scope, robots and bounded page observations."""

import pytest

from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.modules.webpage import WebpageModule, _parse_robots


class FakeHTTP:
    def __init__(self, responses):
        self.responses = responses
        self.calls = []

    async def get_text(self, url, **kwargs):
        self.calls.append((url, kwargs))
        response = self.responses[url]
        if isinstance(response, Exception):
            raise response
        return response


def context(**changes):
    data = {
        "query": "https://example.com/", "input_type": "url",
        "purpose": "Public documentation audit", "authorized": True,
        "allowed_hosts": ["example.com"], "terms_url": "https://example.com/terms",
    }
    data.update(changes)
    return QueryContext(**data)


@pytest.mark.parametrize("changes", [
    {"allowed_hosts": []}, {"allowed_hosts": ["www.example.com"]}, {"terms_url": None},
    {"input_type": "domain", "query": "example.com"},
    {"query": "http://example.com/"}, {"query": "https://example.com:8443/"},
    {"query": "https://example.com/?token=secret"},
    {"query": "https://example.com/%61dmin/"},
    {"query": "https://www.linkedin.com/", "allowed_hosts": ["www.linkedin.com"]},
])
async def test_scope_rejected_before_any_request(changes):
    http = FakeHTTP({})
    with pytest.raises(SourceSkipped):
        await WebpageModule().run(context(**changes), http)
    assert not http.calls


async def test_page_metadata_links_and_public_mailto_observations():
    http = FakeHTTP({
        "https://example.com/robots.txt": "User-agent: *\nDisallow: /blocked",
        "https://example.com/": """
            <title>Public site</title><meta name="description" content="Public documentation">
            <a href="/about#team">About</a><a href="/about">Duplicate</a>
            <a href="https://other.example/">External</a>
            <a href="https://sub.example.com/">Subdomain</a>
            <a href="http://example.com/plain">HTTP</a>
            <a href="/search?q=private">Search</a><a href="/login">Login</a>
            <a href="/blocked">Blocked link</a>
            <a href="mailto:public@example.com?subject=hello&bcc=hidden@example.com">Contact</a>
            <a href="mailto:first@example.com,second@example.com">Multiple</a>
            <p>unlinked@example.com +12025550123</p>
        """,
        "https://example.com/about": "<title>About</title><a href='/'>Home</a>",
    })
    findings = await WebpageModule().run(context(), http)
    assert [url for url, _ in http.calls] == [
        "https://example.com/robots.txt", "https://example.com/", "https://example.com/about",
    ]
    emails = [finding for finding in findings if finding.relation == "publishes_email"]
    assert len(emails) == 1 and emails[0].object.value == "public@example.com"
    assert all(finding.confidence == "certain" for finding in findings)
    assert all(finding.subject.kind == "url" for finding in findings)
    assert findings[0].relation == "page_observed"
    assert findings[0].metadata["title"] == "Public site"
    assert findings[0].metadata["description"] == "Public documentation"
    assert not any("ownership" in finding.relation for finding in findings)
    assert http.calls[0][1]["allowed_content_types"] == ("text/plain",)
    assert http.calls[1][1]["allowed_content_types"] == ("text/html", "application/xhtml+xml")
    assert all(options["pinned"] for _, options in http.calls)


async def test_explicit_robots_404_is_allowed():
    http = FakeHTTP({"https://example.com/robots.txt": None, "https://example.com/": "<title>OK</title>"})
    result = await WebpageModule().run(context(), http)
    assert len(result) == 1 and result[0].relation == "page_observed"
    assert http.calls[0][1]["not_found_ok"] is True


async def test_robots_transport_failure_and_redirect_fail_closed():
    http = FakeHTTP({"https://example.com/robots.txt": SourceSkipped("HTTP redirect refused")})
    with pytest.raises(SourceSkipped, match="redirect"):
        await WebpageModule().run(context(), http)
    assert len(http.calls) == 1


async def test_robots_disallow_prevents_page_request():
    http = FakeHTTP({"https://example.com/robots.txt": "User-agent: OSINTCorrelation\nDisallow: /"})
    with pytest.raises(SourceSkipped, match="disallows"):
        await WebpageModule().run(context(), http)
    assert len(http.calls) == 1


def test_robots_groups_wildcards_specificity_and_percent_encoding():
    robots = _parse_robots("""
        User-agent: *
        Disallow: /
        User-agent: OSINTCorrelation
        Disallow: /private*
        Allow: /private/public$
        User-agent: osintcorrelation
        Disallow: /blocked
        Disallow: /caf%C3%A9
    """)
    assert robots.permits("https://example.com/other")
    assert robots.permits("https://example.com/private/public")
    assert not robots.permits("https://example.com/private/public/child")
    assert not robots.permits("https://example.com/%62locked")
    assert not robots.permits("https://example.com/café")


@pytest.mark.parametrize("directive", [
    "Crawl-delay: 61", "Crawl-delay: nan", "Crawl-delay: -1",
    "Request-rate: 1/120", "Request-rate: 1/0", "Request-rate: no", "Disallow /private",
])
def test_unsupported_or_excessive_robots_constraints_fail_closed(directive):
    with pytest.raises(SourceSkipped):
        _parse_robots("User-agent: *\n" + directive)


async def test_robots_rate_uses_more_conservative_http_pacing():
    http = FakeHTTP({
        "https://example.com/robots.txt": "User-agent: *\nCrawl-delay: 10.1\nRequest-rate: 1/30",
        "https://example.com/": "<title>Paced</title>",
    })
    await WebpageModule().run(context(), http)
    assert http.calls[0][1]["rate_limit_per_min"] == 6
    assert http.calls[1][1]["rate_limit_per_min"] == 2


async def test_page_and_finding_caps_bound_requests_and_results():
    html = "<title>Seed</title>" + "".join(f"<a href='/p{i}'>Next</a>" for i in range(40))
    http = FakeHTTP({
        "https://example.com/robots.txt": "User-agent: *\nAllow: /",
        "https://example.com/": html,
        "https://example.com/p0": html,
    })
    result = await WebpageModule().run(context(max_pages=2), http)
    assert len(http.calls) == 3
    assert sum(finding.relation == "page_observed" for finding in result) == 2
    http.calls.clear()
    result = await WebpageModule().run(context(max_findings=2), http)
    assert len(result) == 2 and len(http.calls) == 2


async def test_page_404_does_not_create_a_positive_observation():
    http = FakeHTTP({"https://example.com/robots.txt": None, "https://example.com/": None})
    assert await WebpageModule().run(context(), http) == []
