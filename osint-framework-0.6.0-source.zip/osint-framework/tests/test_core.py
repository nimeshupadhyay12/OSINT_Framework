import asyncio
from types import SimpleNamespace

import pytest
from pydantic import ValidationError

from osint_framework.core.audit import AuditLog
from osint_framework.core.correlator import correlate
from osint_framework.core.engine import Engine
from osint_framework.core.http import SourceError, SourceSkipped
from osint_framework.core.schema import Entity, Finding, ModuleSpec, QueryContext


def context(**kwargs):
    return QueryContext(query="example.org", input_type="domain", purpose="Authorized fixture case", authorized=True, **kwargs)


def finding(source="fixture", confidence="tentative"):
    return Finding(source=source, subject=Entity(kind="domain", value="example.org"), relation="has_subdomain",
                   object=Entity(kind="domain", value="www.example.org"), confidence=confidence,
                   evidence_url="https://example.org/", legal_basis="Synthetic fixture")


@pytest.mark.parametrize("kind,value", [("domain", "-bad.example"), ("domain", "127.0.0.1"),
                                         ("domain", "https://example.org"), ("email", "bad@@example.org"),
                                         ("phone", "2025550123"), ("url", "javascript:alert(1)"),
                                         ("url", "https://user:password@example.org/"), ("username", "a/b")])
def test_invalid_identifiers(kind, value):
    with pytest.raises(ValueError):
        Entity(kind=kind, value=value)


def test_normalization_preserves_email_local_case_and_url_path():
    assert Entity(kind="email", value="ALIce@EXAMPLE.ORG").value == "ALIce@example.org"
    assert Entity(kind="url", value="https://EXAMPLE.ORG/A#frag").value == "https://example.org/A"
    assert Entity(kind="domain", value="EXAMPLE.ORG.").value == "example.org"


def test_context_rejects_blank_purpose_and_false_authorization():
    with pytest.raises(ValidationError):
        QueryContext(query="a", input_type="name", purpose="        ", authorized=True)
    with pytest.raises(ValidationError):
        QueryContext(query="a", input_type="name", purpose="Fixture case", authorized=False)


def test_graph_deduplicates_without_confidence_amplification():
    weak = finding()
    report = correlate([weak, weak, finding("second_source", "certain")])
    assert len(report["nodes"]) == 2
    assert len(report["edges"]) == 1
    edge = report["edges"][0]
    assert edge["confidence"] == "tentative"
    assert len(edge["evidence_ids"]) == 2
    assert set(edge["sources"]) == {"fixture", "second_source"}


def test_graph_does_not_merge_typed_identifiers_or_case():
    item = finding()
    item.subject = Entity(kind="username", value="example.org")
    item.object = Entity(kind="domain", value="example.org")
    assert len(correlate([item])["nodes"]) == 2


def test_audit_chain_detects_modified_payload(tmp_path):
    audit = AuditLog(tmp_path)
    audit.accept_policy()
    audit.append("test", {"value": "original"})
    assert audit.verify() == (True, 2)
    with audit.connect() as db:
        db.execute("UPDATE events SET payload='{}' WHERE seq=2")
    assert audit.verify() == (False, 1)


async def test_engine_requires_policy_before_network(tmp_path):
    calls = []

    async def run(*_):
        calls.append(True)
        return []

    module = SimpleNamespace(spec=ModuleSpec(name="fixture", input_types=["domain"], description="fixture", terms_url="https://example.org/"), run=run)
    with pytest.raises(ValueError, match="init"):
        await Engine(AuditLog(tmp_path)).run(context(), [module], http=object())
    assert calls == []


async def test_engine_isolates_failures_keys_and_truncation(tmp_path):
    async def ok(*_):
        return [finding(), finding("second")]

    async def failed(*_):
        raise RuntimeError("secret-key-must-never-be-in-report")

    async def denied(*_):
        raise SourceSkipped("Provider denied access")

    async def unavailable(*_):
        raise SourceError("Provider returned HTTP 500")

    def module(name, run, keys=None):
        return SimpleNamespace(spec=ModuleSpec(name=name, input_types=["domain"], description="fixture", terms_url="https://example.org/", key_env=keys or []), run=run)

    audit = AuditLog(tmp_path)
    audit.accept_policy()
    result = await Engine(audit).run(context(max_findings=1), [module("success", ok), module("failed", failed),
                           module("denied", denied), module("unavailable", unavailable), module("keyed", failed, ["ABSENT_OSINT_TEST_KEY"])], http=object())
    by_name = {r.module: r for r in result.results}
    assert by_name["success"].truncated
    assert len(by_name["success"].findings) == 1
    assert by_name["failed"].status == "error"
    assert by_name["unavailable"].status == "error"
    assert by_name["denied"].status == "skipped"
    assert by_name["keyed"].status == "skipped"
    assert "secret-key" not in result.model_dump_json()
    assert audit.verify()[0]


async def test_engine_records_abort_when_cancelled(tmp_path):
    audit = AuditLog(tmp_path)
    audit.accept_policy()

    async def cancelled(*_):
        raise asyncio.CancelledError()

    module = SimpleNamespace(spec=ModuleSpec(name="cancelled", input_types=["domain"], description="fixture", terms_url="https://example.org/"), run=cancelled)
    with pytest.raises(asyncio.CancelledError):
        await Engine(audit).run(context(), [module], http=object())
    with audit.connect() as db:
        assert db.execute("SELECT kind FROM events ORDER BY seq DESC LIMIT 1").fetchone()[0] == "run_aborted"
