import json
from pathlib import Path

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.modules.phone_evidence import (
    PhonePagesModule,
    PhoneSearchModule,
    evidence_findings,
)
from osint_framework.phone import (
    manual_search_links,
    nearby_emails,
    normalize_phone,
    phone_matches,
    public_text,
)
from osint_framework.phone_workflow import PhoneRequest, run_phone


def context(**kwargs):
    return QueryContext(query="+12025550123", input_type="phone", purpose="Synthetic phone evidence test", authorized=True, **kwargs)


@pytest.mark.parametrize("raw,region,expected", [
    ("+1 (202) 555-0123", None, "+12025550123"),
    ("202-555-0123", "US", "+12025550123"),
    ("+44 20 7946 0123", None, "+442079460123"),
])
def test_number_formatting(raw, region, expected):
    assert normalize_phone(raw, region) == expected


@pytest.mark.parametrize("raw,region", [("2025550123", None), ("+123", None),
    ("+12025550123 ext 2", None), ("+1 2025550123,+1 2025550124", None),
    ("2025550123", "INVALID"), ("hello@example.org", None)])
def test_bad_or_ambiguous_number_rejected(raw, region):
    with pytest.raises(ValueError):
        normalize_phone(raw, region)


def test_no_number_suffix_or_identifier_matching():
    assert not phone_matches("Invoice 912025550123456", "+12025550123")
    assert not phone_matches("ABC12025550123DEF", "+12025550123")
    assert not phone_matches("+1 202-555-0124 help@example.org", "+12025550123")


def test_public_email_needs_number_nearby():
    text = "Call +1 202-555-0123 and email support@example.org"
    rows = nearby_emails(text, phone_matches(text, "+12025550123"))
    assert rows[0]["email"] == "support@example.org"
    assert not nearby_emails("help@example.org", [])
    text = "+12025550123 " + "x" * 350 + " support@example.org"
    assert not nearby_emails(text, phone_matches(text, "+12025550123"))


def test_hidden_content_is_not_contact_evidence():
    text, title = public_text('<title>Public title</title><p>Call +12025550123</p><script>secret@example.org</script><span hidden>hidden@example.org</span>')
    assert title == "Public title"
    assert "secret@" not in text and "hidden@" not in text
    assert not nearby_emails(text, phone_matches(text, "+12025550123"))


def test_associations_are_explicitly_unverified():
    rows = evidence_findings(context(), "Call +12025550123: team@example.org", "https://example.org/contact", "Contact", "test", "Synthetic fixture")
    assert rows[0].relation == "public_number_mention"
    assert rows[0].confidence == "certain"
    assert rows[1].relation == "email_near_number"
    assert rows[1].confidence == "tentative"
    assert rows[1].metadata["ownership_verified"] is False


class FakeHTTP:
    def __init__(self, pages=None, payload=None):
        self.pages = pages or {}
        self.payload = payload
        self.calls = []

    async def get_text(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.pages.get(url)

    async def get_json(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.payload


async def test_search_requires_actual_snippet_match():
    http = FakeHTTP(payload={"web": {"results": [
        {"url": "https://example.org/contact", "title": "Contact", "description": "Phone +1 202-555-0123, help@example.org"},
        {"url": "https://example.net/contact", "title": "Wrong", "description": "Phone +1 202-555-0199, wrong@example.net"},
        {"url": "https://example.com/contact", "description": "No number but unrelated@example.com"},
    ]}})
    rows = await PhoneSearchModule("session-only-key").run(context(), http)
    assert len(rows) == 2
    assert rows[1].object.value == "help@example.org"
    assert all(row.confidence == "tentative" for row in rows)
    assert http.calls[0][1]["source"] == "brave"  # Shares provider pacing with existing adapter.
    assert '"+12025550123"' in http.calls[0][1]["params"]["q"]


async def test_search_caps_and_rejects_unsafe_urls():
    http = FakeHTTP(payload={"web": {"results": [
        {"url": "javascript:alert(1)", "description": "+12025550123 bad@example.org"},
        {"url": "https://example.org/contact", "description": "+12025550123 help@example.org"},
    ]}})
    assert len(await PhoneSearchModule("test-key").run(context(max_findings=1), http)) == 2


async def test_pages_are_scoped_before_network():
    http = FakeHTTP()
    ctx = context(seed_urls=["https://example.org/contact"], allowed_hosts=["other.example"], terms_url="https://example.org/terms")
    with pytest.raises(SourceSkipped, match="exact allowed"):
        await PhonePagesModule().run(ctx, http)
    assert not http.calls


async def test_pages_honor_robots_and_extract_visible_public_contacts():
    fixture = (Path(__file__).resolve().parents[1] / "examples/public-contact.html").read_text(encoding="utf-8")
    http = FakeHTTP(pages={"https://example.org/robots.txt": "User-agent: *\nAllow: /\n", "https://example.org/contact": fixture})
    ctx = context(seed_urls=["https://example.org/contact"], allowed_hosts=["example.org"], terms_url="https://example.org/terms")
    rows = await PhonePagesModule().run(ctx, http)
    assert {r.object.value for r in rows if r.object.kind == "email"} == {"help@example.org", "billing@example.org"}
    assert all(call[1]["pinned"] and call[1]["source"] == "webpage" for call in http.calls)
    http = FakeHTTP(pages={"https://example.org/robots.txt": "User-agent: *\nDisallow: /\n"})
    with pytest.raises(SourceSkipped, match="disallows"):
        await PhonePagesModule().run(ctx, http)
    assert len(http.calls) == 1


async def test_workflow_keeps_session_key_out_of_reports_and_requires_policy(tmp_path):
    req = PhoneRequest(number="+1 202-555-0123", purpose="Synthetic case only", authorized=True, search_web=True)
    http = FakeHTTP(payload={"web": {"results": [{"url": "https://example.org/contact", "description": "+12025550123 help@example.org"}]}})
    with pytest.raises(ValueError, match="init"):
        await run_phone(req, tmp_path / "state", tmp_path / "reports", api_key="secret-session-key", http=http)
    AuditLog(tmp_path / "state").accept_policy()
    outcome = await run_phone(req, tmp_path / "state", tmp_path / "reports", api_key="secret-session-key", http=http)
    assert outcome.summary["emails"] == ["help@example.org"]
    assert "secret-session-key" not in outcome.paths["json"].read_text(encoding="utf-8")
    assert "secret-session-key" not in json.dumps(outcome.summary)
    assert AuditLog(tmp_path / "state").verify()[0]


async def test_workflow_local_only_never_queries_http(tmp_path):
    req = PhoneRequest(number="+1 202-555-0123", purpose="Synthetic local test", authorized=True)
    AuditLog(tmp_path / "state").accept_policy()
    http = FakeHTTP()
    outcome = await run_phone(req, tmp_path / "state", tmp_path / "reports", http=http)
    assert not http.calls and not outcome.summary["emails"]
    assert "No internet lookup" in outcome.report.notes[0]
    assert len(manual_search_links(outcome.summary["number"])) == 3
