"""Network-free boundary tests: DNS pinning, redirects, credentials and limits."""

import asyncio
import socket
from datetime import datetime, timedelta, timezone
from email.utils import format_datetime

import httpx
import pytest

from osint_framework.core import http
from osint_framework.core.audit import AuditLog
from osint_framework.core.http import HttpClient, SourceError, SourceSkipped
from osint_framework.core.ratelimit import RateLimited, RateLimiter


class FakeLimiter:
    def __init__(self):
        self.calls = []
        self.deferrals = []

    async def acquire(self, source, rate):
        self.calls.append((source, rate))

    def defer(self, source, delay):
        self.deferrals.append((source, delay))


@pytest.fixture
def public_dns(monkeypatch):
    calls = []

    async def resolve(host):
        calls.append(host)
        return "93.184.216.34"

    monkeypatch.setattr(http, "public_address", resolve)
    return calls


async def test_pinning_uses_ip_host_header_and_string_tls_sni(public_dns):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(200, text="public", headers={"Content-Type": "text/html"})

    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(respond))) as client:
        assert await client.get_text(
            "https://example.com/public", source="webpage", rate_limit_per_min=6,
            pinned=True, allowed_content_types=("text/html",),
        ) == "public"
    assert public_dns == ["example.com"]
    request = requests[0]
    assert request.url.host == "93.184.216.34"
    assert request.headers["Host"] == "example.com"
    assert request.extensions["sni_hostname"] == "example.com"
    assert isinstance(request.extensions["sni_hostname"], str)
    assert request.headers["Connection"] == "close"
    assert request.headers["Accept-Encoding"] == "identity"
    assert "OSINTCorrelation" in request.headers["User-Agent"]


async def test_no_client_default_credentials_params_or_cookies(public_dns):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(200, text="ok", headers={"Set-Cookie": "session=new; Path=/"})

    underlying = httpx.AsyncClient(
        transport=httpx.MockTransport(respond), headers={"Authorization": "Bearer default-secret"},
        cookies={"session": "secret-cookie"}, params={"api_key": "secret-param"},
        auth=("username", "password"), follow_redirects=True,
    )
    async with HttpClient(FakeLimiter(), underlying) as client:
        for path in ("/first", "/second"):
            await client.get_text("https://example.com" + path, source="webpage", rate_limit_per_min=6, pinned=True)
    assert len(requests) == 2
    assert all("Authorization" not in request.headers and "Cookie" not in request.headers for request in requests)
    assert all(not request.url.query for request in requests)


@pytest.mark.parametrize("extra", [{"auth": ("user", "key")}, {"headers": {"Cookie": "session=secret"}}])
async def test_pinned_requests_refuse_explicit_credentials_before_dns(public_dns, extra):
    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(lambda r: None))) as client:
        with pytest.raises(SourceSkipped, match="Credentials"):
            await client.get_text("https://example.com/", source="webpage", rate_limit_per_min=6, pinned=True, **extra)
    assert not public_dns


async def test_native_api_preserves_explicit_authentication():
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(200, json={"ok": True})

    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(respond))) as client:
        assert await client.get_json("https://api.github.com/user", source="github", rate_limit_per_min=10,
                                     headers={"Authorization": "Bearer explicit-key"}) == {"ok": True}
    assert requests[0].headers["Authorization"] == "Bearer explicit-key"


async def test_redirects_never_follow_injected_client_default(public_dns):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(302, headers={"Location": "https://elsewhere.example/"})

    underlying = httpx.AsyncClient(transport=httpx.MockTransport(respond), follow_redirects=True)
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceSkipped, match="Redirect"):
            await client.get_text("https://example.com/", source="webpage", rate_limit_per_min=6, pinned=True)
    assert len(requests) == 1


async def test_rdap_redirect_pins_public_destination_and_drops_defaults(public_dns):
    requests = []

    def respond(request):
        requests.append(request)
        if len(requests) == 1:
            return httpx.Response(302, headers={"Location": "https://registry.example/domain/example.com"})
        return httpx.Response(200, json={"objectClassName": "domain"})

    underlying = httpx.AsyncClient(transport=httpx.MockTransport(respond), cookies={"secret": "cookie"})
    async with HttpClient(FakeLimiter(), underlying) as client:
        result = await client.get_json("https://rdap.org/domain/example.com", source="rdap", rate_limit_per_min=10)
    assert result["objectClassName"] == "domain"
    assert public_dns == ["registry.example"]
    assert requests[1].headers["Host"] == "registry.example"
    assert requests[1].extensions["sni_hostname"] == "registry.example"
    assert "Cookie" not in requests[1].headers


@pytest.mark.parametrize("location", [None, "", "#fragment", "http://registry.example/", "https://registry.example:bad/", "https://user:secret@registry.example/", "https://[bad/", "https://registry.example\\other/"])
async def test_bad_rdap_locations_stop_without_another_request(public_dns, location):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(302, headers={} if location is None else {"Location": location})

    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(respond))) as client:
        # HTTPX may reject malformed Location syntax before returning the response.
        with pytest.raises((SourceSkipped, SourceError)):
            await client.get_json("https://rdap.org/domain/example.com", source="rdap", rate_limit_per_min=10)
    assert len(requests) == 1 and not public_dns


@pytest.mark.parametrize("extra", [{"headers": {"Authorization": "key"}}, {"auth": ("user", "secret")}, {"params": {"key": "secret"}}])
async def test_rdap_redirect_with_credentials_or_params_is_refused(public_dns, extra):
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(302, headers={"Location": "https://registry.example/"})))
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceSkipped, match="Redirect"):
            await client.get_json("https://rdap.org/domain/example.com", source="rdap", rate_limit_per_min=10, **extra)
    assert not public_dns


async def test_rdap_redirect_chain_is_limited(public_dns):
    requests = []

    def respond(request):
        requests.append(request)
        return httpx.Response(302, headers={"Location": f"https://registry.example/{len(requests)}"})

    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(respond))) as client:
        with pytest.raises(SourceSkipped):
            await client.get_json("https://rdap.org/domain/example.com", source="rdap", rate_limit_per_min=10)
    assert len(requests) == 4


@pytest.mark.parametrize("status", [201, 204, 206])
async def test_non_200_robots_responses_fail_closed(public_dns, status):
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(status, text="", headers={"Content-Type": "text/plain"})))
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceSkipped, match="HTTP 200"):
            await client.get_text("https://example.com/robots.txt", source="webpage", rate_limit_per_min=6,
                                  pinned=True, not_found_ok=True, allowed_content_types=("text/plain",))


@pytest.mark.parametrize("mime", ["text/html", "application/json", ""])
async def test_robots_mime_must_match(public_dns, mime):
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(200, content=b"", headers={"Content-Type": mime})))
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceSkipped, match="content type"):
            await client.get_text("https://example.com/robots.txt", source="webpage", rate_limit_per_min=6,
                                  pinned=True, allowed_content_types=("text/plain",))


async def test_only_explicit_404_returns_none(public_dns):
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(404)))
    async with HttpClient(FakeLimiter(), underlying) as client:
        assert await client.get_text("https://example.com/robots.txt", source="webpage", rate_limit_per_min=6,
                                     pinned=True, not_found_ok=True) is None
        with pytest.raises(SourceError, match="404"):
            await client.get_text("https://example.com/robots.txt", source="webpage", rate_limit_per_min=6, pinned=True)


class ChunkStream(httpx.AsyncByteStream):
    async def __aiter__(self):
        yield b"x" * 2_500_001
        yield b"x" * 2_500_001


@pytest.mark.parametrize("response", [
    lambda: httpx.Response(200, headers={"Content-Length": "5000001"}),
    lambda: httpx.Response(200, stream=ChunkStream()),
])
async def test_size_limits_apply_to_declared_and_streamed_body(response):
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: response()))
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceError, match="5 MB"):
            await client.get_text("https://api.github.com/", source="github", rate_limit_per_min=10)


async def test_network_errors_do_not_expose_query_or_header_secrets():
    def fail(request):
        raise httpx.ConnectError("key=supersecret auth=Bearer supersecret", request=request)

    async with HttpClient(FakeLimiter(), httpx.AsyncClient(transport=httpx.MockTransport(fail))) as client:
        with pytest.raises(SourceError) as caught:
            await client.get_json("https://api.github.com/?key=supersecret", source="github", rate_limit_per_min=10,
                                  headers={"Authorization": "Bearer supersecret"})
    assert "supersecret" not in str(caught.value)


async def test_retry_after_persists_across_limiter_instances(tmp_path):
    audit = AuditLog(tmp_path)
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(lambda r: httpx.Response(429, headers={"Retry-After": "3600"})))
    async with HttpClient(RateLimiter(audit), underlying) as client:
        with pytest.raises(RateLimited):
            await client.get_json("https://api.github.com/", source="github", rate_limit_per_min=10)
    with pytest.raises(RateLimited):
        await RateLimiter(AuditLog(tmp_path)).acquire("github", 10)


@pytest.mark.parametrize("header", [None, "bad", "NaN", "inf", "-1"])
def test_bad_retry_after_uses_finite_fallback(header):
    assert http.retry_delay(header) == 60


def test_retry_after_date_and_long_cooldown_are_honored():
    assert http.retry_delay("172800") == 172800
    future = format_datetime(datetime.now(timezone.utc) + timedelta(hours=2))
    assert 7198 <= http.retry_delay(future) <= 7200


@pytest.mark.parametrize("addresses", [["127.0.0.1"], ["93.184.216.34", "10.0.0.1"], ["::1"], []])
async def test_private_or_mixed_dns_answers_are_rejected(monkeypatch, addresses):
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, 443)) for address in addresses
    ])
    with pytest.raises(SourceSkipped):
        await http.public_address("example.com")


async def test_total_request_budget_is_finite(monkeypatch):
    async def never_finishes(request):
        await asyncio.Event().wait()

    monkeypatch.setattr(http, "REQUEST_BUDGET_SECONDS", 0.01)
    underlying = httpx.AsyncClient(transport=httpx.MockTransport(never_finishes))
    async with HttpClient(FakeLimiter(), underlying) as client:
        with pytest.raises(SourceError, match="time budget"):
            await client.get_text("https://api.github.com/", source="github", rate_limit_per_min=10)
