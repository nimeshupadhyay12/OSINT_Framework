"""Offline response fixtures. No test makes a lookup about a real person."""

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.engine import Engine
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.modules.native import (
    BlueskyModule,
    BraveSearchModule,
    CertificateTransparencyModule,
    DNSModule,
    GitHubModule,
    HIBPModule,
    HunterModule,
    PhoneLocalModule,
    RDAPModule,
    ShodanModule,
    TwilioModule,
    VirusTotalModule,
    builtin_modules,
)


class FixtureHTTP:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    async def get_json(self, url, **kwargs):
        self.calls.append((url, kwargs))
        assert 1 <= kwargs["rate_limit_per_min"] <= 60
        assert kwargs["source"]
        assert self.responses, "Unexpected extra HTTP request"
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response


def context(kind="domain", query="example.com", **kwargs):
    return QueryContext(
        input_type=kind, query=query, purpose="Offline fixture test", authorized=True, **kwargs
    )


@pytest.fixture(autouse=True)
def fixture_credentials(monkeypatch):
    for name in (
        "TWILIO_ACCOUNT_SID",
        "TWILIO_AUTH_TOKEN",
        "HIBP_API_KEY",
        "HUNTER_API_KEY",
        "VIRUSTOTAL_API_KEY",
        "SHODAN_API_KEY",
        "BRAVE_SEARCH_API_KEY",
    ):
        monkeypatch.setenv(name, "fixture-secret-never-a-real-key")


async def test_github_public_claims_and_safe_optional_fields():
    http = FixtureHTTP(
        {
            "login": "FixtureUser",
            "id": 123,
            "name": "Example Profile",
            "email": "profile@example.com",
            "blog": "javascript:alert(1)",
            "bio": "<script>untrusted text</script>",
            "private_gists": 42,
        }
    )
    findings = await GitHubModule().run(context("username", "FixtureUser"), http)
    assert len(findings) == 3
    assert findings[0].object.value == "https://github.com/FixtureUser"
    assert "private_gists" not in findings[0].metadata
    assert {f.relation for f in findings} == {
        "observed_profile",
        "self_reports_email",
        "self_reports_name",
    }
    assert findings[1].subject == findings[0].object
    assert "Authorization" not in http.calls[0][1]["headers"]


async def test_github_mismatched_profile_rejected_and_missing_empty():
    with pytest.raises(ValueError, match="different username"):
        await GitHubModule().run(
            context("username", "FixtureUser"), FixtureHTTP({"login": "someoneelse"})
        )
    assert await GitHubModule().run(context("username", "FixtureUser"), FixtureHTTP(None)) == []
    http = FixtureHTTP()
    with pytest.raises(SourceSkipped, match="supported GitHub username"):
        await GitHubModule().run(context("username", "not.a.github.user"), http)
    assert http.calls == []


async def test_bluesky_normalizes_bare_name_and_does_not_follow_links():
    http = FixtureHTTP(
        {
            "handle": "fixture.bsky.social",
            "did": "did:plc:fixture",
            "description": "https://example.org/",
            "followersCount": 2,
        }
    )
    findings = await BlueskyModule().run(context("username", "@fixture"), http)
    assert len(findings) == 1
    assert findings[0].object.value == "https://bsky.app/profile/fixture.bsky.social"
    assert http.calls[0][1]["params"] == {"actor": "fixture.bsky.social"}
    assert len(http.calls) == 1


async def test_bluesky_mismatch_rejected():
    with pytest.raises(ValueError, match="unexpected profile"):
        await BlueskyModule().run(
            context("username", "fixture"),
            FixtureHTTP({"handle": "other.bsky.social", "did": "did:plc:other"}),
        )


async def test_dns_types_alias_owner_and_deduplication():
    cname = {"name": "example.com.", "type": 5, "TTL": 300, "data": "www.example.com."}
    http = FixtureHTTP(
        {
            "Status": 0,
            "AD": True,
            "Answer": [
                cname,
                {"name": "www.example.com.", "type": 1, "TTL": 60, "data": "192.0.2.1"},
            ],
        },
        {
            "Status": 0,
            "Answer": [cname, {"name": "example.com.", "type": 28, "data": "2001:db8::1"}],
        },
        {
            "Status": 0,
            "Answer": [{"name": "example.com.", "type": 15, "data": "10 mail.example.com."}],
        },
        {"Status": 0, "Answer": [{"name": "example.com.", "type": 2, "data": "ns.example.com."}]},
        {"Status": 0, "Answer": [{"name": "example.com.", "type": 16, "data": '"v=spf1 -all"'}]},
    )
    findings = await DNSModule().run(context(), http)
    assert len(findings) == 6
    assert {f.relation for f in findings} == {
        "dns_a",
        "dns_aaaa",
        "dns_mx",
        "dns_ns",
        "dns_txt",
        "dns_cname",
    }
    address = next(f for f in findings if f.relation == "dns_a")
    assert address.subject.value == "www.example.com"  # Do not misattribute a CNAME target's RR.
    assert next(f for f in findings if f.relation == "dns_mx").object.value == "mail.example.com"
    assert [call[1]["params"]["type"] for call in http.calls] == ["A", "AAAA", "MX", "NS", "TXT"]


async def test_dns_failure_is_not_negative_evidence():
    with pytest.raises(ValueError, match="failure status"):
        await DNSModule().run(context(), FixtureHTTP({"Status": 2}))
    assert await DNSModule().run(context(), FixtureHTTP(*[{"Status": 3}] * 5)) == []


async def test_dns_null_mx_and_findings_bound():
    http = FixtureHTTP(
        {"Status": 0},
        {"Status": 0},
        {"Status": 0, "Answer": [{"type": 15, "data": "0 ."}]},
        {"Status": 0},
        {"Status": 0},
    )
    findings = await DNSModule().run(context(max_findings=1), http)
    assert len(findings) == 1
    assert findings[0].object.value == "null-mx"
    assert len(http.calls) == 5


async def test_certificate_names_are_scoped_deduplicated_and_bounded():
    http = FixtureHTTP(
        [
            {
                "id": 123,
                "name_value": "*.example.com\napi.example.com\nevilexample.com\nexample.com.evil.test\napi.example.com",
                "not_after": "2027-01-01",
            },
            {"id": 124, "name_value": "www.example.com\napi.example.com"},
        ]
    )
    findings = await CertificateTransparencyModule().run(context(max_findings=2), http)
    assert [f.object.value for f in findings] == [
        "*.example.com",
        "api.example.com",
        "www.example.com",
    ]
    assert findings[0].object.kind == "record"
    assert findings[0].metadata["wildcard"] is True
    assert all(f.evidence_url == "https://crt.sh/?id=123" for f in findings[:2])
    assert len(http.calls) == 1


async def test_certificate_wildcard_and_apex_are_distinct_observations():
    findings = await CertificateTransparencyModule().run(
        context(), FixtureHTTP([{"id": 1, "name_value": "*.example.com\nexample.com"}])
    )
    assert [(f.object.kind, f.object.value) for f in findings] == [
        ("record", "*.example.com"),
        ("domain", "example.com"),
    ]


@pytest.mark.parametrize(
    ("kind", "query", "payload"),
    [
        (
            "domain",
            "example.com",
            {
                "objectClassName": "domain",
                "ldhName": "EXAMPLE.COM",
                "handle": "123",
                "status": ["active"],
                "nameservers": [{"ldhName": "ns.example.com"}],
            },
        ),
        (
            "ip",
            "192.0.2.1",
            {
                "objectClassName": "ip network",
                "startAddress": "192.0.2.0",
                "endAddress": "192.0.2.255",
                "country": "ZZ",
            },
        ),
    ],
)
async def test_rdap_summary_omits_personal_contact_vcards(kind, query, payload):
    payload["entities"] = [{"vcardArray": ["vcard", [["email", {}, "text", "secret@example.com"]]]}]
    findings = await RDAPModule().run(context(kind, query), FixtureHTTP(payload))
    assert len(findings) == 1
    assert findings[0].relation == "has_registration_record"
    assert "entities" not in findings[0].metadata
    assert "secret@example.com" not in findings[0].model_dump_json()


async def test_rdap_unexpected_shape_is_error():
    with pytest.raises(ValueError, match="unexpected object class"):
        await RDAPModule().run(context(), FixtureHTTP({"objectClassName": "entity"}))


@pytest.mark.parametrize(
    "ctx,payload",
    [
        (context(), {"objectClassName": "domain", "ldhName": "wrong.example"}),
        (
            context("ip", "192.0.2.1"),
            {
                "objectClassName": "ip network",
                "startAddress": "198.51.100.0",
                "endAddress": "198.51.100.255",
            },
        ),
        (
            context("ip", "192.0.2.1"),
            {
                "objectClassName": "ip network",
                "startAddress": "2001:db8::",
                "endAddress": "2001:db8::ffff",
            },
        ),
    ],
)
async def test_rdap_mismatches_are_not_correlated(ctx, payload):
    with pytest.raises(ValueError, match="different"):
        await RDAPModule().run(ctx, FixtureHTTP(payload))


async def test_twilio_and_virustotal_mismatches_are_not_correlated():
    with pytest.raises(ValueError, match="different phone"):
        await TwilioModule().run(
            context("phone", "+12025550123"),
            FixtureHTTP({"valid": True, "phone_number": "+12025550124"}),
        )
    with pytest.raises(ValueError, match="different identifier"):
        await VirusTotalModule().run(
            context(), FixtureHTTP({"data": {"id": "wrong.example", "attributes": {}}})
        )


async def test_phone_local_offline_metadata():
    http = FixtureHTTP()
    findings = await PhoneLocalModule().run(context("phone", "+12025550123"), http)
    assert len(findings) == 1
    assert findings[0].metadata["country_calling_code"] == 1
    assert "live location" in findings[0].metadata["note"]
    assert "subscriber" not in findings[0].metadata
    assert http.calls == []


async def test_twilio_basic_only_no_credential_in_evidence():
    http = FixtureHTTP(
        {
            "valid": True,
            "phone_number": "+12025550123",
            "country_code": "US",
            "caller_name": {"caller_name": "Ignored"},
        }
    )
    findings = await TwilioModule().run(context("phone", "+12025550123"), http)
    assert "caller_name" not in findings[0].metadata
    assert "params" not in http.calls[0][1]
    assert http.calls[0][1]["auth"] == ("fixture-secret-never-a-real-key",) * 2
    assert "fixture-secret" not in findings[0].model_dump_json()


async def test_hibp_names_attribution_and_no_password_data():
    http = FixtureHTTP(
        [
            {"Name": "ExampleBreach", "Password": "discarded"},
            {"Name": "ExampleBreach"},
            {"Name": "OtherBreach"},
        ]
    )
    findings = await HIBPModule().run(context("email", "fixture@example.com"), http)
    assert len(findings) == 2
    assert findings[0].relation == "reported_in_breach"
    assert "Have I Been Pwned" in findings[0].metadata["attribution"]
    assert "discarded" not in findings[0].model_dump_json()
    assert "%40" in http.calls[0][0]
    assert http.calls[0][1]["params"]["truncateResponse"] == "true"
    assert await HIBPModule().run(context("email", "fixture@example.com"), FixtureHTTP(None)) == []


async def test_hunter_optional_key_does_not_enter_report():
    http = FixtureHTTP(
        {
            "data": {
                "status": "valid",
                "score": 95,
                "email": "fixture@example.com",
                "smtp_check": True,
            },
            "meta": {"params": {"api_key": "fixture-secret-never-a-real-key"}},
        }
    )
    findings = await HunterModule().run(context("email", "fixture@example.com"), http)
    assert findings[0].metadata["status"] == "valid"
    assert "fixture-secret" not in findings[0].model_dump_json()
    assert http.calls[0][1]["params"]["api_key"] == "fixture-secret-never-a-real-key"
    assert "api_key" not in findings[0].evidence_url


@pytest.mark.parametrize(
    ("kind", "query", "path"),
    [("domain", "example.com", "domains"), ("ip", "192.0.2.1", "ip_addresses")],
)
async def test_virustotal_read_only_summary(kind, query, path):
    http = FixtureHTTP(
        {
            "data": {
                "attributes": {
                    "reputation": 3,
                    "last_analysis_stats": {"malicious": 1, "harmless": 50},
                    "last_analysis_results": {"vendor": {"result": "excluded"}},
                }
            }
        }
    )
    findings = await VirusTotalModule().run(context(kind, query), http)
    assert f"/{path}/" in http.calls[0][0]
    assert findings[0].metadata["last_analysis_stats"]["malicious"] == 1
    assert "last_analysis_results" not in findings[0].metadata
    assert "fixture-secret" not in findings[0].model_dump_json()


async def test_shodan_existing_summary_no_active_scan_or_banner():
    http = FixtureHTTP(
        {
            "ip_str": "192.0.2.1",
            "ports": [22, 443, -1, 70000, True],
            "hostnames": ["example.com"],
            "data": [{"banner": "ignored"}],
        }
    )
    findings = await ShodanModule().run(context("ip", "192.0.2.1"), http)
    assert findings[0].metadata["ports"] == [22, 443]
    assert "data" not in findings[0].metadata
    assert http.calls[0][1]["params"]["minify"] == "true"
    assert "/shodan/host/" in http.calls[0][0]
    assert "fixture-secret" not in findings[0].model_dump_json()


async def test_brave_search_leads_are_tentative_bounded_and_urls_validated():
    http = FixtureHTTP(
        {
            "web": {
                "results": [
                    {"url": "javascript:alert(1)", "title": "bad"},
                    {"url": "https://user:password@example.com/", "title": "bad"},
                    {
                        "url": "https://example.com/one",
                        "title": "Fixture",
                        "description": "An indexed page",
                    },
                    {"url": "https://example.com/one", "title": "duplicate"},
                    {"url": "https://example.com/two", "title": "second"},
                ]
            }
        }
    )
    findings = await BraveSearchModule().run(context("name", "Example Name", max_findings=2), http)
    assert len(findings) == 2
    assert all(f.confidence == "tentative" for f in findings)
    assert http.calls[0][1]["params"]["count"] == 3
    assert http.calls[0][1]["params"]["spellcheck"] == "false"
    assert len(http.calls) == 1


@pytest.mark.parametrize(
    "module,ctx,payload",
    [
        (GitHubModule(), context("username", "fixture"), []),
        (BlueskyModule(), context("username", "fixture"), []),
        (DNSModule(), context(), []),
        (CertificateTransparencyModule(), context(), {}),
        (HIBPModule(), context("email", "fixture@example.com"), {}),
        (HunterModule(), context("email", "fixture@example.com"), {}),
        (VirusTotalModule(), context(), {"data": {"attributes": []}}),
        (TwilioModule(), context("phone", "+12025550123"), {}),
    ],
)
async def test_malformed_responses_are_not_fabricated_findings(module, ctx, payload):
    with pytest.raises(ValueError):
        await module.run(ctx, FixtureHTTP(payload))


async def test_network_failure_propagates_to_engine_for_reporting():
    with pytest.raises(TimeoutError):
        await GitHubModule().run(context("username", "fixture"), FixtureHTTP(TimeoutError()))


@pytest.mark.parametrize(
    "module,ctx,payload",
    [
        (
            GitHubModule(),
            context("username", "fixture", max_findings=1),
            {"login": "fixture", "name": "Example Fixture"},
        ),
        (
            DNSModule(),
            context(max_findings=1),
            {
                "Status": 0,
                "Answer": [{"type": 1, "data": "192.0.2.1"}, {"type": 1, "data": "192.0.2.2"}],
            },
        ),
        (
            CertificateTransparencyModule(),
            context(max_findings=1),
            [{"id": 1, "name_value": "a.example.com\nb.example.com"}],
        ),
        (
            HIBPModule(),
            context("email", "fixture@example.com", max_findings=1),
            [{"Name": "First"}, {"Name": "Second"}],
        ),
        (
            BraveSearchModule(),
            context("name", "Example Fixture", max_findings=1),
            {
                "web": {
                    "results": [
                        {"url": "https://example.com/one"},
                        {"url": "https://example.com/two"},
                    ]
                }
            },
        ),
    ],
)
async def test_native_engine_marks_truncation_when_more_observations_exist(
    tmp_path, module, ctx, payload
):
    audit = AuditLog(tmp_path)
    audit.accept_policy()
    report = await Engine(audit).run(ctx, [module], http=FixtureHTTP(payload))
    result = report.results[0]
    assert result.status == "ok"
    assert result.truncated is True
    assert len(result.findings) == 1


@pytest.mark.parametrize(
    "module,ctx",
    [
        (GitHubModule(), context("username", "incompatible.username")),
        (BlueskyModule(), context("username", "incompatible_username")),
        (PhoneLocalModule(), context("phone", "+999999999")),
        (BraveSearchModule(), context("name", "a" * 601)),
        (BraveSearchModule(), context("name", "word " * 76)),
    ],
)
async def test_native_engine_reports_unavailable_inputs_as_skipped(tmp_path, module, ctx):
    audit = AuditLog(tmp_path)
    audit.accept_policy()
    http = FixtureHTTP()
    report = await Engine(audit).run(ctx, [module], http=http)
    assert report.results[0].status == "skipped"
    assert report.results[0].findings == []
    assert http.calls == []


def test_native_registry_has_six_defaults_and_only_optional_paid_sources():
    modules = builtin_modules()
    assert len({m.spec.name for m in modules}) == len(modules) == 12
    assert {m.spec.name for m in modules if m.spec.default_enabled} == {
        "github",
        "bluesky",
        "dns",
        "crtsh",
        "rdap",
        "phone_local",
    }
    assert all(m.spec.key_env or m.spec.default_enabled for m in modules)
