import json
import uuid
from pathlib import Path

import pytest

from osint_framework.analysis import analyze_case, evidence_path
from osint_framework.core.cases import CaseStore
from osint_framework.core.schema import Entity, Finding, ModuleResult, QueryContext, RunReport
from osint_framework.integrations.imports import ImportValidationError, parse_import

EXAMPLES = Path(__file__).resolve().parents[1] / "examples"


def context(kind="domain", query="example.org", **fields):
    return QueryContext(input_type=kind, query=query, purpose="Synthetic evidence contract test", authorized=True, **fields)


def test_recon_hosts_scope_and_explicit_ip_provenance():
    found = parse_import("recon_ng", EXAMPLES / "recon-ng-hosts.csv", context())
    assert {f.object.value for f in found} == {"www.example.org", "192.0.2.10"}
    assert all(f.metadata["upstream_module"] == "synthetic/fixture" for f in found)
    assert all(f.metadata["timestamp_kind"] == "imported_at" for f in found)


def test_recon_contacts_scope_and_header_requirement(tmp_path):
    file = tmp_path / "contacts.csv"
    file.write_text("email,module\nhello@example.org,fixture\nother@example.net,fixture\n")
    assert [f.object.value for f in parse_import("recon_ng", file, context("email", "hello@example.org"))] == ["hello@example.org"]
    file.write_text("www.example.org,192.0.2.10\n")
    with pytest.raises(ImportValidationError, match="headers=true"):
        parse_import("recon_ng", file, context())


def test_photon_scopes_named_datasets_and_omits_key_material(tmp_path):
    payload = json.loads((EXAMPLES / "photon-export.json").read_text())
    payload["keys"] = ["sensitive-fixture-material-never-import"]
    file = tmp_path / "exported.json"
    file.write_text(json.dumps(payload))
    found = parse_import("photon", file, context())
    assert {f.object.value for f in found} == {"https://example.org/contact", "www.example.org"}
    assert "sensitive-fixture-material" not in str(found)
    file.write_text('{"unrecognized_version":[]}')
    with pytest.raises(ImportValidationError):
        parse_import("photon", file, context())


def test_registry_planning_never_claims_an_account_exists(tmp_path):
    data = json.loads((EXAMPLES / "whatsmyname-registry.json").read_text())
    original = data["sites"][0]
    data["sites"] += [{**original, "valid": False}, {**original, "headers": {"Cookie": "fixture"}},
                      {**original, "uri_check": "https://example.org/search?q={account}"},
                      {**original, "protection": ["captcha"]}]
    file = tmp_path / "wmn-data.json"
    file.write_text(json.dumps(data))
    found = parse_import("whatsmyname", file, context("username", "demo_user"))
    assert len(found) == 1
    assert found[0].relation == "unqueried_profile_candidate"
    assert found[0].metadata["profile_checked"] is False
    assert found[0].metadata["account_exists"] == "unknown"
    assert found[0].object.value == "https://example.org/users/demo_user"


def test_community_imports_enforce_result_limit():
    with pytest.raises(ImportValidationError, match="max_findings"):
        parse_import("photon", EXAMPLES / "photon-export.json", context(max_findings=1))


def finding(subject, obj, relation="observed_with"):
    return Finding(source="fixture", subject=subject, object=obj, relation=relation,
                   evidence_url="https://example.org/fixture", legal_basis="Synthetic fixture")


def test_comparison_never_treats_failure_or_truncation_as_disappearance(tmp_path):
    store = CaseStore(tmp_path)
    case = store.create("Synthetic comparison")
    claim = finding(context().entity, Entity(kind="domain", value="www.example.org"))
    for status, truncated, claims in [("ok", False, [claim]), ("error", False, []), ("ok", True, [claim]), ("empty", False, [])]:
        store.add(case, RunReport(run_id=str(uuid.uuid4()), graph={}, context=context(), results=[ModuleResult(module="fixture", status=status, truncated=truncated, findings=claims)]))
        if len(store.reports(case)) > 1:
            result = analyze_case(tmp_path, case)["comparisons"][0]
            assert not result["comparable"] and not result["not_returned_evidence_ids"]
    store.add(case, RunReport(run_id=str(uuid.uuid4()), graph={}, context=context(), results=[ModuleResult(module="fixture", status="ok", findings=[claim])]))
    result = analyze_case(tmp_path, case)
    assert result["comparisons"][0]["added_evidence_ids"] == [claim.id]
    assert "does not prove removal" in result["comparisons"][0]["note"]
    store.add(case, RunReport(run_id=str(uuid.uuid4()), graph={}, context=context(max_requests=1),
                             results=[ModuleResult(module="fixture", status="empty")]))
    result = analyze_case(tmp_path, case)["comparisons"][0]
    assert not result["comparable"] and not result["not_returned_evidence_ids"]


def test_evidence_paths_keep_direction_and_exclude_rejected_claims(tmp_path):
    store = CaseStore(tmp_path)
    case = store.create("Synthetic path")
    a, b, c = context().entity, Entity(kind="email", value="hello@example.org"), Entity(kind="phone", value="+12025550123")
    left, right = finding(a, b), finding(c, b)
    store.add(case, RunReport(run_id=str(uuid.uuid4()), graph={}, context=context(), results=[ModuleResult(module="fixture", status="ok", findings=[left, right])]))
    path = evidence_path(tmp_path, case, a.id, c.id)
    assert len(path["steps"]) == 2
    assert path["steps"][1]["claims"][0]["source"] == c.id
    assert path["steps"][1]["claims"][0]["evidence_ids"] == [right.id]
    store.review(case, right.id, "rejected", "Synthetic mismatch review")
    with pytest.raises(ValueError, match="non-rejected"):
        evidence_path(tmp_path, case, a.id, c.id)
    other = store.create("Separate empty case")
    with pytest.raises(ValueError, match="this case"):
        evidence_path(tmp_path, other, a.id, b.id)
