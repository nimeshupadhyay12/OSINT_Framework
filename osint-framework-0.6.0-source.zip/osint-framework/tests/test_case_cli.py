import json
from pathlib import Path

from typer.testing import CliRunner

from osint_framework.cli import app
from osint_framework.core.cases import CaseStore

runner = CliRunner()


def test_case_cli_import_review_and_export(tmp_path):
    state, out = tmp_path / "state", tmp_path / "out"
    create = runner.invoke(app, ["cases", "create", "Synthetic CLI case", "--state", str(state)])
    assert create.exit_code == 0, create.output
    case_id = create.output.strip()
    assert runner.invoke(app, ["init", "--accept-policy", "--state", str(state)]).exit_code == 0
    fixture = Path(__file__).resolve().parents[1] / "examples" / "amass-names.txt"
    result = runner.invoke(app, ["import-results", str(fixture), "--tool", "amass", "--type", "domain", "--query", "example.org",
        "--purpose", "Synthetic CLI import", "--authorized", "--case", case_id, "--state", str(state), "--out", str(out)])
    assert result.exit_code == 0, result.output
    store = CaseStore(state)
    report, = store.reports(case_id)
    fid = report.results[0].findings[0].id
    assert runner.invoke(app, ["cases", "review", case_id, fid, "accepted", "Synthetic review", "--state", str(state)]).exit_code == 0
    note = runner.invoke(app, ["cases", "note", case_id, "Reviewed original fixture", "--state", str(state)])
    assert note.exit_code == 0, note.output
    shown = runner.invoke(app, ["cases", "show", case_id, "--state", str(state)])
    assert json.loads(shown.output)["history"]["notes"][0]["text"] == "Reviewed original fixture"
    exported = runner.invoke(app, ["cases", "export", case_id, "--state", str(state), "--out", str(out)])
    assert exported.exit_code == 0, exported.output
    assert (out / ("case-" + case_id) / "report.html").is_file()
    assert runner.invoke(app, ["cases", "verify", case_id, "--state", str(state)]).exit_code == 0


def test_doctor_json_is_machine_readable_and_does_not_query(tmp_path):
    result = runner.invoke(app, ["doctor", "--json", "--state", str(tmp_path)])
    assert result.exit_code == 0, result.output
    data = json.loads(result.output)
    by_name = {row["name"]: row for row in data}
    assert by_name["amass"]["mode"] == "offline import"
    assert by_name["phone_local"]["setup"] == "ready"
    assert not (tmp_path / "audit.sqlite3").exists()


def test_cli_document_flags_and_missing_case_do_not_collect(tmp_path):
    state, out = tmp_path / "state", tmp_path / "out"
    fixture = tmp_path / "fixture.txt"
    fixture.write_text("example.org hello@example.org")
    assert runner.invoke(app, ["init", "--accept-policy", "--state", str(state)]).exit_code == 0
    args = ["document", str(fixture), "example.org", "--type", "domain", "--purpose", "Synthetic document case",
            "--authorized", "--state", str(state), "--out", str(out)]
    missing = runner.invoke(app, args + ["--case", "missing"])
    assert missing.exit_code == 2 and not out.exists()
    result = runner.invoke(app, args)
    assert result.exit_code == 0, result.output
    report_path, = out.glob("*/report.json")
    assert json.loads(report_path.read_text())["artifacts"][0]["sha256"]


def test_phone_command_accepts_case(tmp_path):
    state = tmp_path / "state"
    case_id = CaseStore(state).create("Phone CLI case")
    assert runner.invoke(app, ["init", "--accept-policy", "--state", str(state)]).exit_code == 0
    result = runner.invoke(app, ["phone", "+12025550123", "--purpose", "Synthetic saved phone case", "--authorized",
        "--state", str(state), "--case", case_id, "--out", str(tmp_path / "out")])
    assert result.exit_code == 0, result.output
    assert len(CaseStore(state).reports(case_id)) == 1
