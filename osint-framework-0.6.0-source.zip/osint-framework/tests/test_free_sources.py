import pytest

from osint_framework.catalog import free_selection, inventory
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.modules.free_sources import (
    EmailDNSModule,
    HackerNewsModule,
    InternetDBModule,
    RIPEModule,
    URLScanModule,
    WaybackModule,
    WikidataModule,
    WikipediaModule,
)


class HTTP:
    def __init__(self, *responses):
        self.responses, self.calls = list(responses), []

    async def get_json(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.responses.pop(0)


def context(kind, query):
    return QueryContext(input_type=kind, query=query, purpose="Synthetic source validation", authorized=True)


async def test_internetdb_validates_ip_and_labels_cves():
    value = context("ip", "1.1.1.1")
    http = HTTP({"ip": "1.1.1.1", "ports": [443], "hostnames": ["example.org"], "vulns": ["CVE-2025-12345"]})
    findings = await InternetDBModule().run(value, http)
    assert len(findings) == 3 and findings[-1].confidence == "tentative"
    with pytest.raises(ValueError, match="another IP"):
        await InternetDBModule().run(value, HTTP({"ip": "8.8.8.8"}))


@pytest.mark.parametrize("module", [InternetDBModule, RIPEModule, URLScanModule])
async def test_private_ip_never_queried(module):
    http = HTTP()
    with pytest.raises(SourceSkipped, match="globally"):
        await module().run(context("ip", "127.0.0.1"), http)
    assert not http.calls


async def test_ripe_requires_a_containing_prefix():
    value = context("ip", "1.1.1.1")
    findings = await RIPEModule().run(value, HTTP({"status": "ok", "data": {"prefix": "1.1.1.0/24", "asns": [13335]}}))
    assert [f.object.value for f in findings] == ["1.1.1.0/24", "AS13335"]
    with pytest.raises(ValueError, match="contain"):
        await RIPEModule().run(value, HTTP({"status": "ok", "data": {"prefix": "8.8.8.0/24", "asns": []}}))


async def test_wayback_retains_capture_time_and_rejects_other_urls():
    def fixture(url):
        return {"archived_snapshots": {"closest": {"available": True, "url": url, "timestamp": "20200102030405", "status": "200"}}}
    value = context("url", "https://example.org/")
    finding, = await WaybackModule().run(value, HTTP(fixture("https://web.archive.org/web/20200102030405/https://example.org/")))
    assert finding.observed_at.year == 2020 and finding.metadata["timestamp_kind"] == "archive_capture"
    with pytest.raises(ValueError, match="scope"):
        await WaybackModule().run(value, HTTP(fixture("https://web.archive.org/web/20200102030405/https://other.org/")))
    assert await WaybackModule().run(value, HTTP({"archived_snapshots": {}})) == []


async def test_knowledge_search_returns_candidates_not_identity_matches():
    value = context("name", "Example Organization")
    wikidata = await WikidataModule().run(value, HTTP({"search": [{"id": "Q123", "label": "Example", "description": "fixture"}]}))
    wikipedia = await WikipediaModule().run(value, HTTP({"query": {"search": [{"pageid": 123, "title": "Example"}]}}))
    assert all(f.confidence == "tentative" for f in wikidata + wikipedia)
    with pytest.raises(ValueError, match="search failed"):
        await WikidataModule().run(value, HTTP({"error": {"code": "ratelimited"}}))


async def test_hackernews_exact_username_no_traversal():
    value = context("username", "fixture_user")
    http = HTTP({"id": "fixture_user", "karma": 1, "submitted": [1, 2, 3]})
    finding, = await HackerNewsModule().run(value, http)
    assert "submitted" not in finding.metadata and len(http.calls) == 1
    assert await HackerNewsModule().run(value, HTTP(None)) == []


async def test_email_dns_only_queries_domain_and_never_verifies_mailbox():
    http = HTTP({"Status": 0, "Answer": [{"name": "example.org.", "type": 15, "data": "0 ."}]},
        {"Status": 0, "Answer": [{"name": "example.org.", "type": 16, "data": '"v=spf1 -all"'}]},
        {"Status": 0, "Answer": [{"name": "_dmarc.example.org.", "type": 16, "data": '"v=DMARC1; p=reject"'}]})
    findings = await EmailDNSModule().run(context("email", "fixture@example.org"), http)
    assert len(findings) == 4
    assert all(f.metadata["mailbox_verified"] is False for f in findings)
    assert all("fixture@" not in str(call) for call in http.calls)


async def test_urlscan_filters_scope_and_preserves_historical_time(monkeypatch):
    monkeypatch.setenv("URLSCAN_API_KEY", "synthetic-test-key")
    row = {"_id": "12345678-1234-4234-8234-123456789abc", "page": {"domain": "example.org", "url": "https://example.org/"},
           "task": {"visibility": "public", "time": "2020-01-01T00:00:00Z"}}
    http = HTTP({"results": [row, {**row, "task": {"visibility": "private"}}]})
    result = await URLScanModule().run(context("domain", "example.org"), http)
    assert len(result) == 1 and "synthetic-test-key" not in result[0].model_dump_json()
    assert "task.visibility:public" in http.calls[0][1]["params"]["q"]


def test_free_selection_excludes_keys_and_unscoped_pages():
    names = free_selection(context("domain", "example.org"))
    assert {"dns", "rdap", "crtsh", "wayback", "wikipedia"} <= set(names)
    assert not {"brave", "virustotal", "urlscan", "scrapy_pages", "subfinder"} & set(names)
    assert next(row for row in inventory() if row["name"] == "urlscan")["access"] == "free_account"
