import hashlib
from pathlib import Path

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import QueryContext
from osint_framework.document_extract import extract
from osint_framework.documents import import_document
from osint_framework.modules.scrapy_pages import ScrapyPagesModule


def context(**options):
    return QueryContext(query="example.org", input_type="domain", purpose="Synthetic extraction tests", authorized=True, **options)


class Pages:
    def __init__(self, robots="User-agent: *\nAllow: /", **pages):
        self.robots, self.pages, self.calls = robots, pages, []

    async def get_text(self, url, **options):
        self.calls.append((url, options))
        assert options["pinned"]
        if url.endswith("/robots.txt"):
            return self.robots
        return self.pages.get(url)


async def test_scrapy_uses_scoped_transport_and_real_selector():
    pytest.importorskip("scrapy")
    pages = Pages(**{"https://example.org/": '<title>Example</title><a href="mailto:hello@example.org">Email</a><a href="/contact">Contact</a><a href="https://outside.org/">Outside</a>',
                     "https://example.org/contact": "<title>Contact</title>Published contact page"})
    value = context(allowed_hosts=["example.org"], terms_url="https://example.org/terms", max_pages=2)
    findings = await ScrapyPagesModule().run(value, pages)
    assert any(f.object.value == "hello@example.org" for f in findings)
    assert all(f.metadata["scrapy_version"] for f in findings)
    assert [call[0] for call in pages.calls] == ["https://example.org/robots.txt", "https://example.org/", "https://example.org/contact"]


async def test_scrapy_robots_and_missing_scope_stop_collection():
    pytest.importorskip("scrapy")
    pages = Pages("User-agent: *\nDisallow: /")
    with pytest.raises(SourceSkipped, match="permitted"):
        await ScrapyPagesModule().run(context(), pages)
    assert pages.calls == []
    with pytest.raises(SourceSkipped, match="robots"):
        await ScrapyPagesModule().run(context(allowed_hosts=["example.org"], terms_url="https://example.org/terms"), pages)
    assert len(pages.calls) == 1


async def test_document_import_uses_subprocess_and_keeps_hash_location(tmp_path):
    path = tmp_path / "fixture.txt"
    path.write_text("Synthetic company example.org has contact hello@example.org.\n", encoding="utf-8")
    state, out = tmp_path / "state", tmp_path / "out"
    AuditLog(state).accept_policy()
    outcome = await import_document(context(), path, state, out)
    findings = outcome.report.results[0].findings
    assert any(f.object.value == "hello@example.org" for f in findings)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert all(f.evidence_url == "urn:sha256:" + digest for f in findings)
    assert all(f.metadata["location"] == "document" for f in findings)
    assert len({f.id for f in findings}) == len(findings)
    artifact = outcome.report.artifacts[0]
    assert Path(artifact["path"]).read_bytes() == path.read_bytes()
    assert outcome.paths["html"].is_file()


async def test_document_unmatched_query_remains_empty(tmp_path):
    path = tmp_path / "fixture.txt"
    path.write_text("Different organization at other.org and other@other.org")
    state = tmp_path / "state"
    AuditLog(state).accept_policy()
    outcome = await import_document(context(), path, state, tmp_path / "out")
    assert outcome.report.results[0].status == "empty"


def test_docx_extraction_retains_paragraph_and_table_locations(tmp_path):
    docx = pytest.importorskip("docx")
    path = tmp_path / "document.docx"
    document = docx.Document()
    document.add_paragraph("example.org")
    document.add_table(rows=1, cols=1).cell(0, 0).text = "hello@example.org"
    document.save(path)
    pages = extract(path)
    assert pages[0]["location"] == "paragraph 1"
    assert pages[1] == {"location": "table 1", "text": "hello@example.org"}


def test_pdf_encryption_and_page_limit(tmp_path):
    pdf = pytest.importorskip("pypdf")
    path = tmp_path / "document.pdf"
    writer = pdf.PdfWriter()
    writer.add_blank_page(width=100, height=100)
    writer.encrypt("synthetic-password")
    writer.write(path)
    with pytest.raises(ValueError, match="Encrypted"):
        extract(path)


def test_ocr_language_validation_and_pixel_limit(tmp_path, monkeypatch):
    image = pytest.importorskip("PIL.Image")
    ocr = pytest.importorskip("pytesseract")
    path = tmp_path / "image.png"
    image.new("RGB", (100, 60)).save(path)
    calls = []
    def text(*_, **kwargs):
        calls.append(kwargs)
        return "example.org"
    monkeypatch.setattr(ocr, "image_to_string", text)
    assert extract(path, "eng+hin")[0]["text"] == "example.org"
    assert calls == [{"lang": "eng+hin", "timeout": 20}]
    with pytest.raises(ValueError, match="language"):
        extract(path, "eng --arbitrary")
