import asyncio
import hashlib
import threading
from datetime import timedelta
from types import SimpleNamespace

import httpx
import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.cases import CaseStore
from osint_framework.core.credentials import credentials, get_secret
from osint_framework.core.engine import Engine
from osint_framework.core.http import HttpClient, SourceSkipped
from osint_framework.core.schema import (
    Entity,
    Finding,
    ModuleResult,
    ModuleSpec,
    QueryContext,
    RunReport,
)
from osint_framework.workflow import detect_type, investigate, make_context


def report(run_id="first"):
    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic case tests", authorized=True)
    finding = Finding(source="fixture", subject=context.entity, relation="has_subdomain", object=Entity(kind="domain", value="www.example.org"),
                      confidence="certain", evidence_url="https://example.org/", legal_basis="Synthetic fixture",
                      metadata={"content_sha256": "a" * 64})
    return RunReport(run_id=run_id, context=context, results=[ModuleResult(module="fixture", status="ok", findings=[finding])], graph={})


def test_case_persistence_reviews_and_immutable_runs(tmp_path):
    store = CaseStore(tmp_path)
    case_id = store.create("Synthetic case")
    value = report()
    store.add(case_id, value)
    store.add(case_id, value)
    assert store.list()[0]["runs"] == 1
    altered = value.model_copy(deep=True)
    altered.notes.append("changed")
    with pytest.raises(ValueError, match="original preserved"):
        store.add(case_id, altered)
    store.note(case_id, "Review the original source")
    fid = value.results[0].findings[0].id
    store.review(case_id, fid, "rejected", "Synthetic test rejection")
    assert CaseStore(tmp_path).evidence(case_id)[0]["review"]["decision"] == "rejected"
    assert store.reports(case_id)[0].results[0].findings[0].confidence == "certain"
    assert store.combined(case_id).results[0].findings[0].metadata["case_review"]["decision"] == "rejected"
    with pytest.raises(ValueError, match="belong"):
        store.review(case_id, "unknown", "accepted", "Not in this case")


def test_case_versions_preserve_weakest_confidence_and_latest_metadata(tmp_path):
    store = CaseStore(tmp_path)
    case_id = store.create("Version history")
    first, later = report(), report("later")
    later.results[0].findings[0].observed_at = first.results[0].findings[0].observed_at + timedelta(days=1)
    later.results[0].findings[0].confidence = "tentative"
    later.results[0].findings[0].metadata = {"content_sha256": "b" * 64, "excerpt": "new text"}
    store.add(case_id, first)
    store.add(case_id, later)
    row, = store.evidence(case_id)
    assert row["changed"] and len(row["runs"]) == 2
    assert row["finding"].confidence == "tentative" and row["finding"].metadata["excerpt"] == "new text"
    assert row["last_seen"] > row["first_seen"]
    assert len(row["origins"]) == 1
    assert store.source_health()["fixture"]["status"] == "ok"


def test_case_digest_detects_modified_payload(tmp_path):
    store = CaseStore(tmp_path)
    case_id = store.create("Digest check")
    store.add(case_id, report())
    with store.connect() as db:
        db.execute("UPDATE reports SET payload='{}'")
    with pytest.raises(ValueError, match="digest"):
        store.reports(case_id)
    with pytest.raises(ValueError, match="digest"):
        store.source_health()


@pytest.mark.parametrize("value,kind", [("+1 (202) 555-0123", "phone"), ("hello@example.org", "email"),
    ("192.0.2.1", "ip"), ("2001:db8::1", "ip"), ("example.org", "domain"), ("https://example.org/", "url"),
    ("Example Organization", "name"), ("demo_user", "username")])
def test_detection_can_be_overridden(value, kind):
    assert detect_type(value) == kind
    assert make_context(value, "auto", "Synthetic detection", True).input_type == kind


async def test_session_credentials_are_isolated_between_tasks(monkeypatch):
    monkeypatch.setenv("BRAVE_SEARCH_API_KEY", "environment")
    async def query(value):
        with credentials({"BRAVE_SEARCH_API_KEY": value}):
            await asyncio.sleep(0)
            return get_secret("BRAVE_SEARCH_API_KEY")
    assert await asyncio.gather(query("one"), query("two")) == ["one", "two"]
    assert get_secret("BRAVE_SEARCH_API_KEY") == "environment"
    with pytest.raises(ValueError):
        with credentials({"UNKNOWN": "value"}):
            pass


async def test_operator_cancellation_keeps_completed_sources(tmp_path):
    audit = AuditLog(tmp_path)
    audit.accept_policy()
    stop = threading.Event()
    completed = asyncio.Event()
    async def fast(*_):
        completed.set()
        return report().results[0].findings
    async def slow(*_):
        await completed.wait()
        stop.set()
        await asyncio.sleep(10)
    def module(name, function):
        return SimpleNamespace(spec=ModuleSpec(name=name, input_types=["domain"], description="fixture", terms_url="https://example.org/"), run=function)
    value = await Engine(audit).run(report().context, [module("fast", fast), module("slow", slow)], http=object(), cancel_event=stop)
    assert [r.status for r in value.results] == ["ok", "cancelled"]
    assert audit.verify()[0]


async def test_precancelled_run_makes_no_module_calls(tmp_path):
    audit = AuditLog(tmp_path)
    audit.accept_policy()
    stop = threading.Event()
    stop.set()
    async def forbidden(*_):
        raise AssertionError("Must not run")
    module = SimpleNamespace(spec=ModuleSpec(name="fixture", input_types=["domain"], description="test", terms_url="https://example.org/"), run=forbidden)
    result = await Engine(audit).run(report().context, [module], http=object(), cancel_event=stop)
    assert result.results[0].status == "cancelled"


async def test_http_request_budget_stops_before_next_request():
    calls = []
    async def acquire(*_):
        pass
    async def handler(request):
        calls.append(request)
        return httpx.Response(200, json={"ok": True})
    client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    async with HttpClient(SimpleNamespace(acquire=acquire), client, max_requests=1) as http:
        await http.get_json("https://dns.google/resolve", source="dns", rate_limit_per_min=1)
        with pytest.raises(SourceSkipped, match="budget"):
            await http.get_json("https://dns.google/resolve", source="dns", rate_limit_per_min=1)
    assert len(calls) == 1


async def test_generic_phone_workflow_saves_case_without_network(tmp_path):
    state, out = tmp_path / "state", tmp_path / "out"
    AuditLog(state).accept_policy()
    store = CaseStore(state)
    case_id = store.create("Local phone case")
    context = make_context("+1 (202) 555-0123", "phone", "Synthetic local lookup", True)
    outcome = await investigate(context, ["phone_local"], state, out, case_id=case_id, secrets={"BRAVE_SEARCH_API_KEY": "test-session-value"})
    assert outcome.report.results[0].status == "ok"
    assert len(store.reports(case_id)) == 1
    assert "test-session-value" not in store.reports(case_id)[0].model_dump_json()


async def test_page_capture_and_case_artifact_verification(tmp_path, monkeypatch):
    import osint_framework.core.engine as engine_module
    import osint_framework.core.http as http_module

    state, out = tmp_path / "state", tmp_path / "out"
    AuditLog(state).accept_policy()
    store = CaseStore(state)
    case_id = store.create("Preserved page fixture")
    body = b'<title>Synthetic evidence</title><a href="mailto:hello@example.org">Contact</a>'
    async def address(_):
        return "93.184.216.34"
    async def acquire(*_):
        pass
    def handler(request):
        if request.url.path == "/robots.txt":
            return httpx.Response(200, text="User-agent: *\nAllow: /", headers={"Content-Type": "text/plain"})
        return httpx.Response(200, content=body, headers={"Content-Type": "text/html"})
    monkeypatch.setattr(http_module, "public_address", address)
    monkeypatch.setattr(engine_module, "HttpClient", lambda limiter, **kwargs: HttpClient(
        SimpleNamespace(acquire=acquire), httpx.AsyncClient(transport=httpx.MockTransport(handler)), **kwargs))
    context = make_context("https://example.org/", "url", "Synthetic page preservation", True,
        allowed_hosts=["example.org"], terms_url="https://example.org/terms", max_pages=1, preserve_pages=True)
    result = await investigate(context, ["webpage"], state, out, case_id=case_id)
    assert result.report.results[0].status == "ok"
    artifact, = result.report.artifacts
    assert artifact["sha256"] == hashlib.sha256(body).hexdigest()
    assert store.verify_artifacts(case_id) == 1
    from pathlib import Path
    path = Path(artifact["path"])
    assert path.suffix == ".txt" and path.read_bytes() == body
    path.write_text("modified evidence")
    with pytest.raises(ValueError, match="digest"):
        store.verify_artifacts(case_id)
    path.unlink()
    with pytest.raises(ValueError, match="missing"):
        store.verify_artifacts(case_id)


def test_keychain_rejects_plaintext_backend(monkeypatch):
    keyring = pytest.importorskip("keyring")
    from osint_framework.core.credentials import save_secret
    monkeypatch.setattr(keyring, "get_keyring", lambda: SimpleNamespace())
    monkeypatch.setattr(keyring, "set_password", lambda *_: pytest.fail("Must not persist to an unapproved backend"))
    with pytest.raises(ValueError, match="OS-backed"):
        save_secret("BRAVE_SEARCH_API_KEY", "synthetic-session-value")
