from pathlib import Path

import pytest

from osint_framework.core.schema import QueryContext
from osint_framework.integrations.imports import ImportValidationError, parse_import


def context(**kwargs):
    return QueryContext(query="+12025550123", input_type="phone", purpose="Synthetic Scrapy import", authorized=True, **kwargs)


def test_official_feed_container_with_explicit_item_contract():
    path = Path(__file__).resolve().parents[1] / "examples/scrapy-public-pages.jsonl"
    results = parse_import("scrapy", path, context())
    assert len(results) == 3
    assert {row.object.value for row in results if row.object.kind == "email"} == {"help@example.org", "billing@example.org"}
    assert all(row.confidence == "tentative" and row.metadata["import_sha256"] for row in results)
    assert all(row.observed_at.isoformat() == "2026-09-12T00:00:00+00:00" for row in results)


@pytest.mark.parametrize("payload", [
    '{"url":"javascript:alert(1)","text":"+12025550123 help@example.org"}',
    '{"url":"https://example.org/","body":"+12025550123 help@example.org"}',
    '{"url":"https://example.org/","text":"+12025550123 help@example.org","phone":"+12025550199"}',
    '{"url":"https://example.org/","text":"+12025550123 help@example.org","observed_at":"2026-01-01"}',
])
def test_malformed_and_out_of_scope_feeds_rejected(tmp_path, payload):
    path = tmp_path / "feed.json"
    path.write_text(payload, encoding="utf-8")
    with pytest.raises(ImportValidationError):
        parse_import("scrapy", path, context())


def test_scrapy_limits_explicitly_fail_instead_of_losing_evidence():
    path = Path(__file__).resolve().parents[1] / "examples/scrapy-public-pages.jsonl"
    with pytest.raises(ImportValidationError, match="max_findings"):
        parse_import("scrapy", path, context(max_findings=1))
