import json
from pathlib import Path

from typer.testing import CliRunner

from osint_framework.cli import app

runner = CliRunner()


def test_sources_and_demo_need_no_consent_or_network(tmp_path):
    result = runner.invoke(app, ["sources"])
    assert result.exit_code == 0, result.output
    assert "webpage" in result.output
    result = runner.invoke(app, ["demo", "--out", str(tmp_path)])
    assert result.exit_code == 0, result.output
    report = json.loads((tmp_path / "synthetic-demo" / "report.json").read_text(encoding="utf-8"))
    assert "SYNTHETIC DEMO" in report["notes"][0]
    assert report["results"][0]["findings"][0]["metadata"]["synthetic"]


def test_cli_authorization_gate_and_offline_import(tmp_path):
    state = tmp_path / "state"
    args = ["run", "example.org", "--type", "domain", "--purpose", "Authorized fixture case", "--state", str(state)]
    result = runner.invoke(app, args)
    assert result.exit_code == 2 and "--authorized" in result.output
    result = runner.invoke(app, args + ["--authorized"])
    assert result.exit_code == 2 and "init" in result.output
    result = runner.invoke(app, ["init", "--state", str(state), "--accept-policy"])
    assert result.exit_code == 0, result.output
    fixture = tmp_path / "subfinder.jsonl"
    fixture.write_text('{"host":"www.example.org","input":"example.org","source":"synthetic"}\n', encoding="utf-8")
    result = runner.invoke(app, ["import-results", str(fixture), "--tool", "subfinder", "--query", "example.org",
                                  "--type", "domain", "--purpose", "Authorized fixture import", "--authorized",
                                  "--state", str(state), "--out", str(tmp_path / "reports")])
    assert result.exit_code == 0, result.output
    reports = list((tmp_path / "reports").glob("*/report.json"))
    assert len(reports) == 1
    assert len(json.loads(reports[0].read_text(encoding="utf-8"))["results"][0]["findings"]) == 1
    assert runner.invoke(app, ["audit-verify", "--state", str(state)]).exit_code == 0


def test_bad_input_is_actionable_without_raw_validation_trace(tmp_path):
    result = runner.invoke(app, ["run", "garbage", "--type", "phone", "--purpose", "Authorized fixture case",
                                "--authorized", "--state", str(tmp_path)])
    assert result.exit_code == 2
    assert "E.164" in result.output
    assert "Traceback" not in result.output


def test_example_csv_is_compatible(tmp_path):
    from osint_framework.core.schema import QueryContext
    from osint_framework.integrations.imports import parse_import

    file = Path(__file__).resolve().parents[1] / "examples" / "sherlock.csv"
    context = QueryContext(query="demo_user", input_type="username", purpose="Synthetic example import", authorized=True)
    assert len(parse_import("sherlock", file, context)) == 1


def test_phone_cli_local_report_and_authorization(tmp_path):
    state, output = tmp_path / "state", tmp_path / "reports"
    args = ["phone", "+1 (202) 555-0123", "--purpose", "Synthetic phone release check",
            "--state", str(state), "--out", str(output)]
    denied = runner.invoke(app, args)
    assert denied.exit_code == 2 and "--authorized" in denied.output
    assert not state.exists() and not output.exists()
    assert runner.invoke(app, ["init", "--state", str(state), "--accept-policy"]).exit_code == 0
    result = runner.invoke(app, args + ["--authorized"])
    assert result.exit_code == 0, result.output
    assert "Normalized phone: +12025550123" in result.output
    assert "none found in the selected sources" in result.output
    report_file, = output.glob("*/report.json")
    report = json.loads(report_file.read_text(encoding="utf-8"))
    assert report["context"]["query"] == "+12025550123"
    assert [item["module"] for item in report["results"]] == ["phone_local"]
    assert "No internet lookup" in report["notes"][0]


def test_desktop_cli_missing_extra_is_actionable(monkeypatch):
    from osint_framework import desktop

    monkeypatch.setattr(desktop, "QT_AVAILABLE", False)
    result = runner.invoke(app, ["desktop"])
    assert result.exit_code == 2
    assert "pip install" in result.output and "desktop" in result.output
    assert "Traceback" not in result.output
