import json
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from osint_framework.cli import app
from osint_framework.core.audit import AuditLog
from osint_framework.core.cases import CaseStore
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import Entity, Finding, ModuleSpec, QueryContext
from osint_framework.integrations.imports import ImportValidationError, parse_import
from osint_framework.modules.discovery import ArchiveURLsModule, GitHubRepositorySearchModule
from osint_framework.research import research, source_plan


def context(**updates):
    return QueryContext(query="example.org", input_type="domain", purpose="Synthetic research workflow", authorized=True, **updates)


class HTTP:
    def __init__(self, value=None, budget=10):
        self.value, self.calls, self.request_count, self.budget = value, [], 0, budget

    async def get_json(self, url, **kwargs):
        if self.request_count >= self.budget:
            raise SourceSkipped("Run HTTP request budget exhausted")
        self.request_count += 1
        self.calls.append((url, kwargs))
        return self.value


async def test_archive_scope_history_and_bad_schema():
    http = HTTP([["timestamp", "original", "mimetype", "statuscode"],
        ["20200101120000", "https://sub.example.org/about", "text/html", "200"],
        ["20200101120000", "https://example.org.evil.test/", "text/html", "200"]])
    findings = await ArchiveURLsModule().run(context(), http)
    assert len(findings) == 1 and findings[0].metadata["current_existence_verified"] is False
    assert http.calls[0][1]["params"]["matchType"] == "domain"
    assert findings[0].evidence_url.startswith("https://web.archive.org/web/20200101120000/")
    with pytest.raises(ValueError):
        await ArchiveURLsModule().run(context(), HTTP([["unexpected"]]))


async def test_repository_search_preserves_uncertainty_and_private_exclusion():
    http = HTTP({"total_count": 31, "incomplete_results": False, "items": [
        {"html_url": "https://github.com/example/project", "private": False, "full_name": "example/project"},
        {"html_url": "https://github.com/example/private", "private": True}]})
    findings = await GitHubRepositorySearchModule().run(context(), http)
    assert len(findings) == 1 and findings[0].confidence == "tentative"
    assert findings[0].metadata["possibly_truncated"] is True
    assert "is:public" in http.calls[0][1]["params"]["q"]
    with pytest.raises(ValueError):
        await GitHubRepositorySearchModule().run(context(), HTTP({"items": [{"private": False, "html_url": "https://evil.test/"}]}))


@pytest.mark.parametrize("tool", ["gau", "waybackurls"])
def test_url_export_import_scope_dedup_and_no_fetch(tool, tmp_path):
    file = tmp_path / "urls.txt"
    file.write_text("https://a.example.org/history\nhttps://a.example.org/history\nhttps://example.org.evil.test/\n", encoding="utf-8")
    findings = parse_import(tool, file, context())
    assert len(findings) == 1 and findings[0].metadata["current_existence_verified"] is False
    file.write_text("https://user:secret@example.org/", encoding="utf-8")
    with pytest.raises(ImportValidationError):
        parse_import(tool, file, context())


def test_uncover_official_result_shape_and_domain_boundary(tmp_path):
    file = tmp_path / "uncover.jsonl"
    row = {"timestamp": 1700000000, "source": "shodan", "ip": "1.1.1.1", "port": 443,
           "host": "www.example.org", "url": "https://www.example.org/"}
    file.write_text(json.dumps(row) + "\n" + json.dumps({**row, "host": "example.org.evil.test"}), encoding="utf-8")
    findings = parse_import("uncover", file, context())
    assert len(findings) == 3 and findings[0].metadata["reported_port"] == 443
    file.write_text(json.dumps({**row, "port": 999999}), encoding="utf-8")
    with pytest.raises(ImportValidationError, match="port"):
        parse_import("uncover", file, context())


def test_plan_selects_ready_sources_and_explains_exclusions(monkeypatch):
    from osint_framework.core.credentials import KEY_NAMES
    for name in KEY_NAMES:
        monkeypatch.delenv(name, raising=False)
    plan = {row["source"]: row for row in source_plan(context())}
    assert plan["archive_urls"]["selected"] and plan["github_repositories"]["selected"]
    assert not plan["brave"]["selected"] and "missing" in plan["brave"]["reason"]
    assert not plan["subfinder"]["selected"]
    configured = {row["source"]: row for row in source_plan(context(), secrets={"BRAVE_SEARCH_API_KEY": "fixture"})}
    assert configured["brave"]["selected"]
    result = CliRunner().invoke(app, ["research-plan", "example.org"])
    assert result.exit_code == 0 and "archive_urls" in result.stdout


async def test_research_pivots_stay_in_domain_and_share_budget(tmp_path, monkeypatch):
    from osint_framework.core.ratelimit import RateLimiter
    async def no_wait(*args):
        pass
    monkeypatch.setattr(RateLimiter, "acquire", no_wait)
    AuditLog(tmp_path / "state").accept_policy()
    queries = []
    async def run(ctx, http):
        await http.get_json("https://dns.google/resolve")
        queries.append(ctx.query)
        return [Finding(source="dns", subject=ctx.entity, object=Entity(kind="domain", value=value),
            relation="discovered", evidence_url="https://example.org/", legal_basis="Synthetic test")
            for value in ("a.example.org", "b.example.org", "outside.test", "example.org.evil.test")]
    module = SimpleNamespace(spec=ModuleSpec(name="dns", input_types=["domain"], description="fixture", terms_url="https://example.org/"), run=run)
    outcome = await research(context(max_requests=2), tmp_path / "state", tmp_path / "reports", max_pivots=5,
        available={"dns": module}, plan=[{"source": "dns", "selected": True, "reason": ""}], http=HTTP(budget=2))
    assert queries == ["example.org", "a.example.org"]
    assert outcome.report.coverage["http_requests"] == 2
    assert outcome.report.coverage["entire_internet_searched"] is False
    assert outcome.paths["html"].is_file()
    assert len(CaseStore(tmp_path / "state").reports(outcome.case_id)) == 3


async def test_person_pivots_rejected_before_any_collection(tmp_path):
    person = QueryContext(query="sampleuser", input_type="username", purpose="Synthetic research workflow", authorized=True)
    with pytest.raises(ValueError, match="domain queries only"):
        await research(person, tmp_path, tmp_path, max_pivots=1)
