import json
from pathlib import Path

import pytest

from osint_framework.core.correlator import correlate
from osint_framework.core.schema import Entity, Finding, ModuleResult, QueryContext, RunReport
from osint_framework.integrations.imports import ImportValidationError, parse_import
from osint_framework.integrations.stix_exchange import export_stix

EXAMPLES = Path(__file__).resolve().parents[1] / "examples"


def context(**options):
    return QueryContext(query="example.org", input_type="domain", purpose="Synthetic integration test", authorized=True, **options)


def report():
    finding = Finding(source="fixture", subject=context().entity, relation="publishes_email",
        object=Entity(kind="email", value="hello@example.org"), evidence_url="https://example.org/contact",
        legal_basis="Synthetic fixture", metadata={"synthetic": True})
    return RunReport(run_id="fixture", context=context(), results=[ModuleResult(module="fixture", status="ok", findings=[finding])], graph=correlate([finding]))


@pytest.mark.parametrize("tool,filename,count", [("spiderfoot", "spiderfoot.json", 2), ("amass", "amass-names.txt", 3),
                                                ("theharvester", "theharvester.jsonl", 2)])
def test_upstream_shaped_exports_preserve_scope_and_provenance(tool, filename, count):
    findings = parse_import(tool, EXAMPLES / filename, context())
    assert len(findings) == count
    assert all(f.confidence == "tentative" and f.subject == context().entity for f in findings)
    assert all(f.metadata["import_sha256"] and f.metadata["adapter_contract"] for f in findings)
    assert all(f.metadata["timestamp_kind"] == "imported_at" for f in findings)
    if tool == "spiderfoot":
        assert findings[0].metadata["upstream_timezone_unknown"]
    if tool == "theharvester":
        assert findings[0].metadata["upstream_evidence_status"] == "partial"


@pytest.mark.parametrize("tool,filename", [("spiderfoot", "spiderfoot.json"), ("theharvester", "theharvester.jsonl")])
def test_target_mismatch_fails_atomically(tmp_path, tool, filename):
    text = (EXAMPLES / filename).read_text(encoding="utf-8").replace('"scan_target":"example.org"', '"scan_target":"other.org"').replace('"target":"example.org"', '"target":"other.org"')
    path = tmp_path / "input.json"
    path.write_text(text, encoding="utf-8")
    with pytest.raises(ImportValidationError, match="target|scope"):
        parse_import(tool, path, context())


def test_amass_rejects_arbitrary_json_and_banner(tmp_path):
    path = tmp_path / "amass.txt"
    path.write_text('{"name":"api.example.org"}', encoding="utf-8")
    with pytest.raises(ImportValidationError, match="names"):
        parse_import("amass", path, context())
    path.write_text("api.example.org\napi.example.org\nevil-example.org\n", encoding="utf-8")
    assert len(parse_import("amass", path, context())) == 1


def test_spiderfoot_false_positives_and_unknown_events_are_not_claims(tmp_path):
    rows = json.loads((EXAMPLES / "spiderfoot.json").read_text())
    rows[0]["false_positive"] = 1
    rows[1]["event_type"] = "UNSUPPORTED_EVENT"
    path = tmp_path / "sf.json"
    path.write_text(json.dumps(rows))
    assert parse_import("spiderfoot", path, context()) == []
    rows[0]["false_positive"] = "maybe"
    path.write_text(json.dumps(rows))
    with pytest.raises(ImportValidationError, match="false_positive"):
        parse_import("spiderfoot", path, context())


def test_theharvester_count_and_completion_timestamp_are_checked(tmp_path):
    text = (EXAMPLES / "theharvester.jsonl").read_text()
    path = tmp_path / "th.jsonl"
    path.write_text(text.replace('"result_count":2', '"result_count":9'))
    with pytest.raises(ImportValidationError, match="count"):
        parse_import("theharvester", path, context())
    path.write_text(text.replace("2026-09-12T10:01:00Z", "2026-09-12T10:01:00"))
    with pytest.raises(ImportValidationError, match="timezone"):
        parse_import("theharvester", path, context())


def test_import_finding_limit_applies_to_new_adapters():
    with pytest.raises(ImportValidationError, match="max_findings"):
        parse_import("amass", EXAMPLES / "amass-names.txt", context(max_findings=1))


def test_stix_export_validates_and_roundtrips_evidence(tmp_path):
    stix2 = pytest.importorskip("stix2")
    original = report()
    payload = export_stix(original)
    assert stix2.parse(payload, allow_custom=True).type == "bundle"
    path = tmp_path / "bundle.json"
    path.write_text(json.dumps(payload))
    findings = parse_import("opencti", path, context())
    claims = [f for f in findings if f.relation == "publishes_email"]
    assert len(claims) == 1
    assert claims[0].object.value == "hello@example.org"
    assert claims[0].metadata["original_source"] == "fixture"
    assert all(f.confidence == "tentative" for f in findings)


def test_stix_relations_must_be_connected_to_exact_query(tmp_path):
    stix2 = pytest.importorskip("stix2")
    root = stix2.DomainName(value="example.org")
    other = stix2.DomainName(value="unrelated.org")
    address = stix2.IPv4Address(value="192.0.2.1")
    relationship = stix2.Relationship(source_ref=other.id, target_ref=address.id, relationship_type="related-to")
    payload = stix2.Bundle(root, other, address, relationship).serialize()
    path = tmp_path / "bundle.json"
    path.write_text(payload)
    findings = parse_import("opencti", path, context())
    assert len(findings) == 1 and findings[0].object == context().entity


def test_stix_markings_propagate_and_missing_definitions_block_export():
    stix2 = pytest.importorskip("stix2")
    value = report()
    f = value.results[0].findings[0]
    f.metadata["stix_object_marking_refs"] = [stix2.TLP_RED.id]
    with pytest.raises(ValueError, match="marking definitions"):
        export_stix(value)
    f.metadata["stix_marking_definitions"] = [json.loads(stix2.TLP_RED.serialize())]
    bundle = export_stix(value)
    for obj in bundle["objects"]:
        if obj["type"] != "marking-definition":
            assert stix2.TLP_RED.id in obj["object_marking_refs"]


def test_stix_duplicate_ids_and_wrong_version_fail(tmp_path):
    path = tmp_path / "bundle.json"
    obj = {"type": "domain-name", "id": "domain-name--fixture", "value": "example.org", "spec_version": "2.0"}
    path.write_text(json.dumps({"type": "bundle", "objects": [obj]}))
    with pytest.raises(ImportValidationError, match="2.1"):
        parse_import("opencti", path, context())
    obj["spec_version"] = "2.1"
    path.write_text(json.dumps({"type": "bundle", "objects": [obj, obj]}))
    with pytest.raises(ImportValidationError, match="Duplicate"):
        parse_import("opencti", path, context())


def test_stix_relationship_inherits_granular_endpoint_restriction(tmp_path):
    stix2 = pytest.importorskip("stix2")
    root = stix2.DomainName(value="example.org")
    endpoint = stix2.EmailAddress(value="hello@example.org",
        granular_markings=[{"marking_ref": stix2.TLP_RED.id, "selectors": ["value"]}])
    relationship = stix2.Relationship(source_ref=root.id, target_ref=endpoint.id, relationship_type="related-to")
    path = tmp_path / "marked-bundle.json"
    path.write_text(stix2.Bundle(root, endpoint, relationship, stix2.TLP_RED).serialize())
    claims = parse_import("opencti", path, context())
    claim, = [f for f in claims if f.relation == "stix_relationship"]
    assert stix2.TLP_RED.id in claim.metadata["stix_object_marking_refs"]
    value = report()
    value.results[0].findings = claims
    exported = export_stix(value)
    assert all(stix2.TLP_RED.id in obj.get("object_marking_refs", [])
               for obj in exported["objects"] if obj["type"] != "marking-definition")
