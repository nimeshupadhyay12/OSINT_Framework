import hashlib
import json
import uuid
from types import SimpleNamespace

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.schema import QueryContext, RunReport
from osint_framework.integrations.locks import require_plugin_approval, verify_binary
from osint_framework.integrations.opencti_connector import send_report


def test_reviewed_binary_rejects_changes_and_missing_digest(tmp_path):
    binary = tmp_path / "tool"
    binary.write_bytes(b"synthetic executable fixture, never executed")
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert verify_binary(binary, digest) == digest
    with pytest.raises(ValueError, match="reviewed"):
        verify_binary(binary, "")
    binary.write_bytes(b"changed")
    with pytest.raises(ValueError, match="changed"):
        verify_binary(binary, digest)


def test_plugin_approval_precedes_loading_and_detects_changed_files(tmp_path, monkeypatch):
    import osint_framework.integrations.locks as locks
    monkeypatch.delenv("OSINT_PLUGIN_LOCK", raising=False)
    entry = SimpleNamespace(name="fixture", dist=SimpleNamespace(metadata={"Name": "fixture-dist"}))
    with pytest.raises(ValueError, match="OSINT_PLUGIN_LOCK"):
        require_plugin_approval(entry)
    receipt = {"distribution": "fixture-dist", "version": "1.0", "sha256": "a" * 64, "files": 2}
    file = tmp_path / "plugins.json"
    file.write_text(json.dumps({"plugins": {"fixture": receipt}}))
    monkeypatch.setenv("OSINT_PLUGIN_LOCK", str(file))
    monkeypatch.setattr(locks, "distribution_receipt", lambda _: receipt)
    require_plugin_approval(entry)
    monkeypatch.setattr(locks, "distribution_receipt", lambda _: {**receipt, "sha256": "b" * 64})
    with pytest.raises(ValueError, match="does not match"):
        require_plugin_approval(entry)


def test_opencti_helper_work_lifecycle_and_no_retry(tmp_path, monkeypatch):
    pytest.importorskip("stix2")
    monkeypatch.setenv("OPENCTI_URL", "https://opencti.example.org/")
    monkeypatch.setenv("OPENCTI_TOKEN", "synthetic-fixture-token")
    monkeypatch.setenv("OPENCTI_CONNECTOR_ID", str(uuid.uuid4()))
    AuditLog(tmp_path).accept_policy()
    report = RunReport(run_id="synthetic-opencti", context=QueryContext(input_type="domain", query="example.org", purpose="Synthetic integration test", authorized=True), results=[], graph={})
    calls = []
    helper = SimpleNamespace(connect_id="connector", api=SimpleNamespace(work=SimpleNamespace(
        initiate_work=lambda *args: "work1", to_processed=lambda *args: calls.append("processed"))),
        send_stix2_bundle=lambda raw, **kwargs: calls.append((json.loads(raw), kwargs)),
        stop=lambda: calls.append("stopped"))
    def factory(config):
        assert config["opencti"]["ssl_verify"] is True
        return helper
    with pytest.raises(ValueError, match="Explicit"):
        send_report(report, tmp_path, helper_factory=factory)
    result = send_report(report, tmp_path, authorized=True, purpose="Synthetic transfer", helper_factory=factory)
    assert result["submitted"] and calls[-2:] == ["processed", "stopped"]
    assert calls[0][0]["type"] == "bundle" and calls[0][1] == {"update": False, "work_id": "work1"}
    def fail(*args, **kwargs):
        raise RuntimeError("sensitive provider message")
    helper.send_stix2_bundle = fail
    with pytest.raises(ValueError, match="uncertain") as error:
        send_report(report, tmp_path, authorized=True, purpose="Synthetic transfer", helper_factory=factory)
    assert "sensitive" not in str(error.value) and calls[-1] == "stopped"
    assert AuditLog(tmp_path).verify()[0]


def test_case_deletion_is_exact_and_preserves_other_cases_and_files(tmp_path):
    from osint_framework.maintenance import delete_case_records, retention_plan
    from osint_framework.team import TeamStore
    store = TeamStore(tmp_path)
    case = store.create("Delete synthetic case")
    other = store.create("Keep synthetic case")
    exported = tmp_path / "export.html"
    exported.write_text("synthetic retained export")
    context = QueryContext(input_type="phone", query="+12025550123", purpose="Synthetic retention validation", authorized=True)
    job = store.enqueue(case, context, ["phone_local"])
    with pytest.raises(ValueError, match="exact"):
        delete_case_records(tmp_path, case, other)
    with pytest.raises(ValueError, match="Cancel"):
        delete_case_records(tmp_path, case, case)
    store.cancel(job)
    assert retention_plan(tmp_path, 90)["candidates"] == []
    assert delete_case_records(tmp_path, case, case)["deleted_case_id"] == case
    assert store.get(other) and exported.is_file()
    with pytest.raises(ValueError, match="does not exist"):
        store.get(case)
