import hashlib
import io
import uuid

import httpx
import pytest

stix2 = pytest.importorskip("stix2")
pytest.importorskip("warcio")
from warcio.archiveiterator import ArchiveIterator  # noqa: E402

from osint_framework.core.audit import AuditLog  # noqa: E402
from osint_framework.core.cases import CaseStore  # noqa: E402
from osint_framework.core.schema import ModuleResult, QueryContext, RunReport  # noqa: E402
from osint_framework.core.vault import Vault  # noqa: E402
from osint_framework.documents import import_document  # noqa: E402
from osint_framework.evidence import export_warc  # noqa: E402
from osint_framework.integrations.imports import ImportValidationError, parse_import  # noqa: E402
from osint_framework.integrations.stix_exchange import export_stix  # noqa: E402
from osint_framework.team import TeamStore, create_app  # noqa: E402


def context():
    return QueryContext(query="example.org", input_type="domain", purpose="Synthetic regression investigation", authorized=True)


def imported(tmp_path, objects):
    file = tmp_path / "input.json"
    file.write_text(stix2.Bundle(*objects).serialize(), encoding="utf-8")
    findings = parse_import("opencti", file, context())
    return RunReport(run_id=str(uuid.uuid4()), context=context(),
        results=[ModuleResult(module="import:opencti", status="ok", findings=findings)], graph={})


@pytest.mark.parametrize("reverse", [False, True])
def test_distinct_stix_relationships_and_markings_survive_case_export(tmp_path, reverse):
    domain, ip = stix2.DomainName(value="example.org"), stix2.IPv4Address(value="1.1.1.1")
    red = stix2.TLP_RED
    relationships = [stix2.Relationship(source_ref=domain.id, target_ref=ip.id, relationship_type="resolves-to", object_marking_refs=[red.id]),
                     stix2.Relationship(source_ref=domain.id, target_ref=ip.id, relationship_type="related-to")]
    report = imported(tmp_path, [domain, ip, red, *relationships[::(-1 if reverse else 1)]])
    store = CaseStore(tmp_path / "state")
    case = store.create("Regression case")
    store.add(case, report)
    combined = store.combined(case)
    claims = [f for f in combined.results[0].findings if f.relation == "stix_relationship"]
    assert len(claims) == 2 and len({f.id for f in claims}) == 2
    assert {f.metadata["stix_relationship_type"] for f in claims} == {"resolves-to", "related-to"}
    assert {edge["relation"] for edge in combined.graph["edges"]} >= {"stix:resolves-to", "stix:related-to"}
    exported = export_stix(combined)
    assert all(red.id in obj.get("object_marking_refs", []) for obj in exported["objects"] if obj["type"] != "marking-definition")


@pytest.mark.parametrize("reverse", [False, True])
def test_new_version_cannot_silently_declassify_same_claim(tmp_path, reverse):
    domain = stix2.DomainName(value="example.org")
    restricted = stix2.DomainName(value="example.org", object_marking_refs=[stix2.TLP_RED.id])
    reports = [imported(tmp_path, [restricted, stix2.TLP_RED]), imported(tmp_path, [domain])]
    store = CaseStore(tmp_path / "state")
    case = store.create("Repeated claim")
    for report in reports[::(-1 if reverse else 1)]:
        store.add(case, report)
    combined = store.combined(case)
    assert len(combined.results[0].findings) == 1
    assert stix2.TLP_RED.id in combined.results[0].findings[0].metadata["stix_object_marking_refs"]
    assert any(stix2.TLP_RED.id in obj.get("object_marking_refs", []) for obj in export_stix(combined)["objects"])


def test_shared_markings_are_serialized_once_and_old_reports_normalize(tmp_path):
    root = stix2.DomainName(value="example.org")
    mark = stix2.MarkingDefinition(definition_type="statement", definition={"statement": "Synthetic. " * 10000})
    objects = [root, mark]
    for i in range(20):
        child = stix2.DomainName(value=f"child{i}.example.org")
        objects.extend([child, stix2.Relationship(source_ref=root.id, target_ref=child.id, relationship_type="related-to", object_marking_refs=[mark.id])])
    report = imported(tmp_path, objects)
    assert len(report.stix_marking_definitions) == 1
    assert len(report.bounded_json().encode()) < 200_000
    assert all("stix_marking_definitions" not in f.metadata for f in report.results[0].findings)
    legacy = report.model_dump(mode="json")
    definitions = legacy.pop("stix_marking_definitions")
    for finding in legacy["results"][0]["findings"]:
        finding["metadata"]["stix_marking_definitions"] = definitions
    loaded = RunReport.model_validate(legacy)
    assert loaded.stix_marking_definitions == report.stix_marking_definitions
    assert len(loaded.bounded_json().encode()) < 200_000


def test_expansion_and_serialized_output_fail_with_clear_limits(tmp_path):
    root = stix2.DomainName(value="example.org")
    mark = stix2.MarkingDefinition(definition_type="statement", definition={"statement": "x" * 1_000_000})
    objects = [root, mark]
    for i in range(10):
        child = stix2.DomainName(value=f"child{i}.example.org")
        objects.extend([child, stix2.Relationship(source_ref=root.id, target_ref=child.id, relationship_type="related-to")])
    with pytest.raises(ImportValidationError, match="expanded evidence budget"):
        imported(tmp_path, objects)
    report = RunReport(run_id="oversize", context=context(), results=[], graph={})
    report.notes = ["x" * 1_000_000] * 17
    with pytest.raises(ValueError, match="serialized output budget"):
        report.bounded_json()


async def test_anonymous_quota_does_not_block_valid_user_or_trust_forwarded_ip(tmp_path):
    AuditLog(tmp_path).accept_policy()
    store = TeamStore(tmp_path)
    token = store.issue_token("analyst", "analyst")
    app = create_app(tmp_path, allowed_sources=["phone_local"])
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://localhost") as client:
        for i in range(600):
            response = await client.get("/health", headers={"X-Forwarded-For": f"198.51.100.{i % 255}"})
        assert response.status_code == 429
        assert (await client.get("/cases", headers={"Authorization": "Bearer " + token})).status_code == 200
        store.revoke("analyst")
        assert (await client.get("/cases", headers={"Authorization": "Bearer " + token})).status_code in {401, 429}


async def test_case_report_pagination_and_bounds(tmp_path):
    AuditLog(tmp_path).accept_policy()
    store = TeamStore(tmp_path)
    token = store.issue_token("admin", "admin")
    case = store.create("Paged case")
    for i in range(3):
        store.add(case, RunReport(run_id=str(i), context=context(), results=[], graph={}))
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=create_app(tmp_path)), base_url="http://localhost",
                                 headers={"Authorization": "Bearer " + token}) as client:
        page = await client.get(f"/cases/{case}?limit=1&offset=1")
        assert page.status_code == 200 and [r["run_id"] for r in page.json()["reports"]] == ["1"]
        assert (await client.get(f"/cases/{case}?limit=9999")).status_code == 422


@pytest.mark.parametrize("legacy", [False, True])
@pytest.mark.parametrize("encrypted", [False, True])
async def test_document_to_warc_real_workflow_and_no_overwrite(tmp_path, legacy, encrypted):
    if encrypted:
        Vault.initialize(tmp_path / "state", "Synthetic export passphrase")
    AuditLog(tmp_path / "state").accept_policy()
    file = tmp_path / "document.txt"
    file.write_text("Synthetic document about example.org", encoding="utf-8")
    outcome = await import_document(context(), file, tmp_path / "state", tmp_path / "reports")
    if legacy:
        outcome.report.artifacts[0].pop("url")
        outcome.report.artifacts[0].pop("captured_at")
    target = tmp_path / "evidence.warc.gz"
    export_warc(outcome.report, target, tmp_path / "state", tmp_path / "reports")
    raw = target.read_bytes()
    records = list(ArchiveIterator(io.BytesIO(raw)))
    assert records[0].rec_headers.get_header("WARC-Target-URI") == "urn:sha256:" + hashlib.sha256(file.read_bytes()).hexdigest()
    with pytest.raises(FileExistsError):
        export_warc(outcome.report, target, tmp_path / "state", tmp_path / "reports")
    assert target.read_bytes() == raw


def test_warc_mid_write_failure_leaves_no_final_archive(tmp_path, monkeypatch):
    from osint_framework import evidence
    file = tmp_path / "body"
    file.write_bytes(b"fixture")
    report = RunReport(run_id="broken-write", context=context(), results=[], graph={}, artifacts=[
        {"url": "https://example.org/", "captured_at": "2026-09-14T00:00:00+00:00",
         "path": str(file), "bytes": 7, "sha256": hashlib.sha256(b"fixture").hexdigest()}])
    real = evidence.artifact_bytes
    calls = 0
    def fail_during_write(*args):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise OSError("Synthetic read interruption")
        return real(*args)
    monkeypatch.setattr(evidence, "artifact_bytes", fail_during_write)
    target = tmp_path / "broken.warc.gz"
    with pytest.raises(OSError):
        export_warc(report, target, tmp_path / "state", tmp_path)
    assert not target.exists() and not list(tmp_path.glob(".warc-*.tmp"))


def test_failed_warc_does_not_publish_partial_file(tmp_path):
    file = tmp_path / "body"
    file.write_bytes(b"fixture")
    report = RunReport(run_id="broken", context=context(), results=[], graph={}, artifacts=[
        {"path": str(file), "bytes": 7, "sha256": hashlib.sha256(b"fixture").hexdigest()}])
    target = tmp_path / "broken.warc.gz"
    with pytest.raises(ValueError, match="Artifact lacks"):
        export_warc(report, target, tmp_path / "state", tmp_path)
    assert not target.exists() and not list(tmp_path.glob(".warc-*.tmp"))
