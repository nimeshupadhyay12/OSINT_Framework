import base64
import hashlib
import json
import re
from datetime import datetime, timezone
from xml.etree import ElementTree as ET

import pytest
from bs4 import BeautifulSoup

from osint_framework.core.schema import Finding, ModuleResult, QueryContext, RunReport
from osint_framework.integrations.imports import (
    ImportValidationError,
    parse_import,
)
from osint_framework.report import MAX_GRAPH_NODES, _link, write_report


def context(kind="username", query="alice", **kwargs):
    return QueryContext(input_type=kind, query=query, purpose=kwargs.pop("purpose", "Authorized test fixture"),
                        authorized=True, **kwargs)


def imported(tmp_path, text, tool="sherlock", scope=None):
    path = tmp_path / "supplied-report.txt"
    path.write_text(text, encoding="utf-8")
    return parse_import(tool, path, scope or context())


def csv_report(rows):
    return "username,name,url_main,url_user,exists,http_status,response_time_s\n" + rows


def test_sherlock_positive_only_and_file_provenance(tmp_path):
    text = csv_report("alice,Example,https://example.com,https://example.com/alice,Claimed,200,0.1\n"
                      "alice,Absent,https://other.example,https://other.example/alice,Available,404,0.1\n")
    findings = imported(tmp_path, text)
    assert len(findings) == 1
    item = findings[0]
    assert item.confidence == "tentative"
    assert item.metadata["timestamp_kind"] == "imported_at"
    assert item.metadata["original_observed_at"] is None
    assert item.metadata["import_sha256"] == hashlib.sha256(
        (tmp_path / "supplied-report.txt").read_bytes()
    ).hexdigest()


@pytest.mark.parametrize("rows", [
    "alice,X,https://example.com,https://example.com/alice,True,200,0.1\n",
    "bob,X,https://example.com,https://example.com/bob,Claimed,200,0.1\n",
    "alice,X,https://example.com,javascript:alert(1),Claimed,200,0.1\n",
    "alice,X,https://example.com,https://example.com/alice,Claimed\n",
])
def test_sherlock_rejects_ambiguous_malformed_or_unscoped_rows(tmp_path, rows):
    with pytest.raises(ImportValidationError):
        imported(tmp_path, csv_report(rows))


def test_sherlock_requires_explicit_positive_status_column(tmp_path):
    with pytest.raises(ImportValidationError, match="requires"):
        imported(tmp_path, "username,name,url_user\nalice,X,https://example.com/alice\n")


def maigret_row(username="alice", status="Claimed", **kwargs):
    return {"url_user": f"https://example.com/{username}",
            "status": {"username": username, "status": status,
                       "url": f"https://example.com/{username}"}, **kwargs}


def test_maigret_nested_positive_status_and_no_similar_accounts(tmp_path):
    data = {"Example": maigret_row(), "Unknown": maigret_row(status="Unknown"),
            "Similar": maigret_row(is_similar=True)}
    result = imported(tmp_path, json.dumps(data), "maigret")
    assert len(result) == 1
    assert result[0].metadata["site"] == "Example"


@pytest.mark.parametrize("data", [
    {"X": {"url_user": "https://example.com/alice"}},
    {"X": maigret_row(username="bob")},
    {"X": maigret_row(status="true")},
    {"X": maigret_row(is_similar="false")},
])
def test_maigret_rejects_missing_or_invalid_status_and_scope(tmp_path, data):
    with pytest.raises(ImportValidationError):
        imported(tmp_path, json.dumps(data), "maigret")


def test_subfinder_domain_suffix_boundary(tmp_path):
    text = '\n'.join(json.dumps(row) for row in [
        {"host": "api.example.com", "input": "example.com", "source": "crtsh"},
        {"host": "api.notexample.com"}, {"host": "example.com.evil.test"},
        {"host": "example.com"},
    ])
    result = imported(tmp_path, text, "subfinder", context("domain", "example.com"))
    assert [item.object.value for item in result] == ["api.example.com"]
    assert result[0].metadata["evidence_url_is_locator"] is True


def canonical_row():
    return {"source": "trusted-looking", "subject": {"kind": "username", "value": "alice"},
            "relation": "reported_profile", "object": {"kind": "profile", "value": "https://example.com/alice"},
            "confidence": "certain", "evidence_url": "https://example.com/alice",
            "legal_basis": "User-supplied public record", "observed_at": "2025-01-02T03:04:05+00:00"}


def test_canonical_retains_original_observation_and_downgrades_confidence(tmp_path):
    row = canonical_row()
    result = imported(tmp_path, json.dumps([row]), "canonical")[0]
    assert result.confidence == "tentative"
    assert result.metadata["original_confidence"] == "certain"
    assert result.metadata["original_observed_at"] == row["observed_at"]
    assert result.observed_at == datetime(2025, 1, 2, 3, 4, 5, tzinfo=timezone.utc)


def test_canonical_rejects_unrelated_subject(tmp_path):
    row = canonical_row()
    row["subject"]["value"] = "bob"
    with pytest.raises(ImportValidationError, match="scope"):
        imported(tmp_path, json.dumps(row), "canonical")


@pytest.mark.parametrize("text", ['{"x":1,"x":2}', '{"x":NaN}', '[1]', '{bad}', ''])
def test_malformed_json_fails_clearly(tmp_path, text):
    with pytest.raises(ImportValidationError):
        imported(tmp_path, text, "canonical")


def test_import_limit_is_not_silent_truncation(tmp_path):
    with pytest.raises(ImportValidationError, match="max_findings"):
        imported(tmp_path, json.dumps([canonical_row(), canonical_row()]), "canonical",
                 context(max_findings=1))


def test_import_file_size_is_bounded(tmp_path, monkeypatch):
    monkeypatch.setattr("osint_framework.integrations.imports.MAX_IMPORT_BYTES", 10)
    with pytest.raises(ImportValidationError, match="size limit"):
        imported(tmp_path, "x" * 11)


def test_missing_timestamp_is_explicit_import_receipt(tmp_path):
    row = canonical_row()
    del row["observed_at"]
    result = imported(tmp_path, json.dumps(row), "canonical")[0]
    assert result.metadata["timestamp_kind"] == "imported_at"
    assert result.metadata["original_observed_at"] is None


def test_reimport_never_promotes_receipt_time_to_observation(tmp_path):
    row = canonical_row()
    row["metadata"] = {"timestamp_kind": "imported_at", "original_observed_at": None}
    result = imported(tmp_path, json.dumps(row), "canonical")[0]
    assert result.metadata["timestamp_kind"] == "imported_at"
    assert result.metadata["original_observed_at"] is None


def test_canonical_sources_remain_distinguishable(tmp_path):
    other = {**canonical_row(), "source": "another-provider"}
    result = imported(tmp_path, json.dumps([canonical_row(), other]), "canonical")
    assert result[0].source != result[1].source
    assert result[0].id != result[1].id


def test_report_escapes_html_and_exports_evidence(tmp_path):
    payload = '</script><img src="https://evil.test/track" onerror="alert(1)">'
    item = Finding(**{**canonical_row(), "source": payload,
                      "metadata": {"untrusted": payload, "timestamp_kind": "imported_at"}})
    nodes = [{"id": entity.id, "kind": entity.kind, "value": entity.value}
             for entity in (item.subject, item.object)]
    graph = {"nodes": nodes, "edges": [{"source": item.subject.id, "target": item.object.id,
              "relation": item.relation, "confidence": item.confidence,
              "sources": [payload], "evidence_ids": [item.id]}]}
    report = RunReport(run_id=payload, context=context(purpose=payload), graph=graph,
                       results=[ModuleResult(module=payload, status="ok", findings=[item], message=payload)],
                       notes=[payload])
    outputs = write_report(report, tmp_path)
    assert set(outputs) == {"json", "html", "graphml"}
    rendered = outputs["html"].read_text(encoding="utf-8")
    assert payload not in rendered
    soup = BeautifulSoup(rendered, "html.parser")
    assert soup.find("img") is None
    assert len(soup.find_all("script")) == 1
    assert "Imported" in soup.get_text()
    assert "Have I Been Pwned" in soup.get_text()
    assert json.loads(outputs["json"].read_text(encoding="utf-8"))["run_id"] == payload
    ns = {"g": "http://graphml.graphdrawing.org/xmlns"}
    assert len(ET.parse(outputs["graphml"]).findall(".//g:edge", ns)) == 1
    csp = soup.find("meta", attrs={"http-equiv": "Content-Security-Policy"})["content"]
    assert "connect-src 'none'" in csp and "default-src 'none'" in csp
    for tag in ("script", "style"):
        raw = re.search(fr"<{tag}>(.*?)</{tag}>", rendered, re.S).group(1)
        digest = base64.b64encode(hashlib.sha256(raw.encode()).digest()).decode()
        assert f"sha256-{digest}" in csp


def test_report_never_links_non_http_schemes():
    assert _link("javascript:alert(1)", "Open") == "Open"
    assert _link("file:///etc/passwd", "Open") == "Open"
    assert _link("https://user:password@example.com", "Open") == "Open"
    assert 'rel="noopener noreferrer"' in _link("https://example.com", "Open")


def test_report_empty_run_is_valid(tmp_path):
    report = RunReport(run_id="test", context=context(), graph={"nodes": [], "edges": []}, results=[])
    result = write_report(report, tmp_path)
    assert all(path.is_file() for path in result.values())


def test_large_graph_preview_is_capped_without_losing_exports_or_ledger(tmp_path):
    from osint_framework.core.correlator import correlate

    findings = [Finding(**{**canonical_row(), "object": {"kind": "profile",
                          "value": f"https://example.com/alice/{number}"}})
                for number in range(MAX_GRAPH_NODES + 4)]
    complete = correlate(findings)
    report = RunReport(run_id="large", context=context(), graph=complete,
                       results=[ModuleResult(module="fixture", status="ok", findings=findings)])
    outputs = write_report(report, tmp_path)
    soup = BeautifulSoup(outputs["html"].read_text(encoding="utf-8"), "html.parser")
    displayed = json.loads(soup.find("template", id="graph-data").get_text())
    assert len(displayed["nodes"]) == MAX_GRAPH_NODES
    assert context().entity.id in {node["id"] for node in displayed["nodes"]}
    assert len(displayed["edges"]) == MAX_GRAPH_NODES - 1
    assert all(edge["evidence_ids"] for edge in displayed["edges"])
    assert "Showing 1000 of 1005 entities" in soup.get_text()
    assert "Graph preview limit reached" in soup.get_text()
    assert "Filters affect the displayed graph subset" in soup.get_text()
    assert len(soup.select("tr[data-evidence]")) == len(findings)
    exported = json.loads(outputs["json"].read_text(encoding="utf-8"))
    assert len(exported["graph"]["nodes"]) == MAX_GRAPH_NODES + 5
    ns = {"g": "http://graphml.graphdrawing.org/xmlns"}
    assert len(ET.parse(outputs["graphml"]).findall(".//g:node", ns)) == MAX_GRAPH_NODES + 5
    assert report.graph == complete
