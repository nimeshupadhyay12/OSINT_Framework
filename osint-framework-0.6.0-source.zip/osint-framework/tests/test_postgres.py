"""Opt-in integration against a disposable dedicated PostgreSQL schema."""

import os
import uuid
from concurrent.futures import ThreadPoolExecutor

import pytest

from osint_framework.core.audit import AuditLog
from osint_framework.core.schema import QueryContext
from osint_framework.jobs import JobStore
from osint_framework.team import TeamStore


@pytest.mark.skipif(not os.environ.get("OSINT_TEST_POSTGRES_URL"), reason="No PostgreSQL integration server configured")
def test_postgres_shared_queue_audit_roles_and_precision(tmp_path, monkeypatch):
    psycopg = pytest.importorskip("psycopg")
    url = os.environ["OSINT_TEST_POSTGRES_URL"]
    schema = "osint_test_" + uuid.uuid4().hex
    monkeypatch.setenv("OSINT_DATABASE_URL", url)
    monkeypatch.setenv("OSINT_DATABASE_SCHEMA", schema)
    try:
        audit = AuditLog(tmp_path)
        audit.accept_policy()
        assert AuditLog(tmp_path / "worker").consented()
        store = TeamStore(tmp_path)
        case = store.create("PostgreSQL synthetic case")
        token = store.issue_token("analyst", "analyst")
        store.grant("analyst", case)
        assert store.allowed(store.principal(token), case, True)
        context = QueryContext(input_type="phone", query="+12025550123", purpose="Synthetic database integration", authorized=True)
        identifiers = {store.enqueue(case, context, ["phone_local"]) for _ in range(6)}
        with ThreadPoolExecutor(max_workers=3) as pool:
            claimed = list(pool.map(lambda _: JobStore(tmp_path).claim(), range(6)))
        assert {job["id"] for job, lease in claimed} == identifiers
        for job, lease in claimed:
            assert store.heartbeat(job["id"], lease)
            store.finish(job["id"], lease, "succeeded")
        with ThreadPoolExecutor(max_workers=3) as pool:
            list(pool.map(lambda i: AuditLog(tmp_path).append("fixture", {"i": i}), range(10)))
        assert audit.verify() == (True, 11)
        assert store.rate_allowed("fixture", 1) and not store.rate_allowed("fixture", 1)
        with store.connect() as db:
            db.execute("INSERT INTO rate_slots VALUES(?,?) ON CONFLICT(source) DO UPDATE SET next_at=MAX(next_at,excluded.next_at)", ("fixture", 1777777777.125))
            assert db.execute("SELECT next_at FROM rate_slots WHERE source=?", ("fixture",)).fetchone()[0] == 1777777777.125
    finally:
        # Identifier is generated locally above, never user-provided.
        with psycopg.connect(url, autocommit=True) as db:
            db.execute('DROP SCHEMA IF EXISTS "' + schema + '" CASCADE')
