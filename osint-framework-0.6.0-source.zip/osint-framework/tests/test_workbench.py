import os
import time

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
pytest.importorskip("PySide6")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from osint_framework.core.audit import AuditLog  # noqa: E402
from osint_framework.workbench import WorkbenchWindow, synthetic_case  # noqa: E402


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def window(app, tmp_path):
    value = WorkbenchWindow(tmp_path / "state", tmp_path / "out")
    yield value
    if value._job:
        value._job.cancel_event.set()
        assert value._job.wait(10_000)
        app.processEvents()
    value.close()
    app.processEvents()


def wait_job(app, window):
    deadline = time.monotonic() + 10
    while window._job and time.monotonic() < deadline:
        app.processEvents()
        time.sleep(0.005)
    assert window._job is None


def test_guided_modes_do_not_require_a_file_and_deep_requires_domain(window):
    window.query_input.setText("example.org")
    window.purpose_input.setText("Synthetic guided workflow")
    window.authorized_check.setChecked(True)
    window.mode_combo.setCurrentIndex(window.mode_combo.findData("research"))
    context, _ = window.build_request()
    assert context.input_type == "domain" and not window.file_input.isEnabled()
    selected = {window.source_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(window.source_list.count())
                if window.source_list.item(i).checkState() == Qt.CheckState.Checked}
    assert {"archive_urls", "github_repositories"} <= selected
    assert not window.select_free_button.isEnabled() and not window.select_ready_button.isEnabled()
    window.mode_combo.setCurrentIndex(window.mode_combo.findData("deep_research"))
    context, _ = window.build_request()
    assert context.input_type == "domain"
    window.query_input.setText("+12025550123")
    with pytest.raises(ValueError, match="requires a domain"):
        window.build_request()


def test_universal_type_selection_and_authorization(window):
    assert [window.tabs.tabText(i) for i in range(window.tabs.count())] == [
        "Investigate", "Case evidence and graph", "Sources and credentials", "Jobs and schedules"]
    for kind, expected in (("phone", "phone_local"), ("domain", "dns"), ("email", "hibp"), ("url", "scrapy_pages"), ("ip", "rdap"), ("username", "github"), ("name", "brave")):
        window.type_combo.setCurrentText(kind)
        names = [window.source_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(window.source_list.count())]
        assert expected in names
    window._submit()
    assert "authorization" in window.message.text()
    assert not (window.state_dir / "audit.sqlite3").exists()


def test_blank_purpose_has_actionable_message_and_starts_no_job(window):
    window.authorized_check.setChecked(True)
    window.query_input.setText("example.org")
    window.purpose_input.setText("")
    window._submit()
    assert "at least 8 characters" in window.message.text()
    assert "QueryContext" not in window.message.text()
    assert window.tabs.currentIndex() == 0 and window._job is None


def test_synthetic_case_graph_reviews_and_pivot_without_network(window):
    outcome = synthetic_case(window.state_dir, window.out_dir)
    window._completed(outcome)
    assert len(window.store.reports(outcome.case_id)) == 2
    assert window.evidence_table.rowCount() >= 5
    assert window.graph.scene().items()
    window.evidence_table.setCurrentCell(0, 0)
    assert "Confidence:" in window.details.toPlainText()
    window.review_combo.setCurrentText("rejected")
    window.review_reason.setText("Synthetic review example")
    window._review()
    assert any(r["review"]["decision"] == "rejected" for r in window.store.evidence(outcome.case_id))
    window._graph_selected("domain", "example.org")
    window._pivot()
    assert window.query_input.text() == "example.org"
    assert not window.authorized_check.isChecked() and window._job is None
    assert not (window.state_dir / "audit.sqlite3").exists()


def test_local_phone_run_saves_case_and_no_secret(app, window):
    window.query_input.setText("+1 (202) 555-0123")
    window.type_combo.setCurrentText("phone")
    window.purpose_input.setText("Synthetic phone workflow")
    window.authorized_check.setChecked(True)
    window.secrets["BRAVE_SEARCH_API_KEY"] = "never-persist-this-value"
    window._submit()
    assert window._job is not None
    wait_job(app, window)
    assert window._outcome.report.results[0].status == "ok"
    assert AuditLog(window.state_dir).verify()[0]
    assert "never-persist-this-value" not in window._outcome.report.model_dump_json()
    assert window.query_form.isEnabled()


def test_source_credentials_stay_session_only_and_refresh_setup(window):
    window.key_combo.setCurrentText("BRAVE_SEARCH_API_KEY")
    window.key_value.setText("example-session-key")
    window._set_key()
    assert window.secrets["BRAVE_SEARCH_API_KEY"] == "example-session-key"
    assert window.key_value.text() == ""
    assert "example-session-key" not in window.message.text()
    window._clear_keys()
    assert not window.secrets


def test_import_ui_records_fixture_without_provider_calls(app, window):
    from pathlib import Path
    window.query_input.setText("example.org")
    window.type_combo.setCurrentText("domain")
    window.purpose_input.setText("Synthetic import workflow")
    window.authorized_check.setChecked(True)
    window.mode_combo.setCurrentIndex(1)
    window.import_combo.setCurrentText("amass")
    window.file_input.setText(str(Path(__file__).resolve().parents[1] / "examples" / "amass-names.txt"))
    window._submit()
    wait_job(app, window)
    assert window._outcome.report.results[0].module == "import:amass"
    assert len(window._outcome.report.results[0].findings) == 3


def test_case_notes_persist_and_are_html_escaped(window):
    outcome = synthetic_case(window.state_dir, window.out_dir)
    window._completed(outcome)
    window.note_input.setText('<img src="https://example.org/tracker"> synthetic note')
    window._note()
    report = window.store.combined(outcome.case_id)
    from osint_framework.report import write_report
    html = write_report(report, window.out_dir / "combined")["html"].read_text(encoding="utf-8")
    assert "&lt;img" in html and '<img src="https://example.org/tracker">' not in html


def test_free_selection_and_desktop_queue_roundtrip(app, window):
    window.case_title.setText("Synthetic queued case")
    window._create_case()
    window.query_input.setText("+12025550123")
    window.type_combo.setCurrentText("phone")
    window.purpose_input.setText("Synthetic queue workflow")
    window._select_free()
    window.authorized_check.setChecked(True)
    assert window.build_request()[1] == ["phone_local"]
    window.repeat_count.setValue(2)
    window._enqueue()
    assert len(window.queue_rows) == 1 and window.queue_rows[0]["status"] == "queued"
    assert not window.authorized_check.isChecked()
    window._process_job()
    wait_job(app, window)
    assert {row["status"] for row in window.queue_rows} == {"succeeded", "queued"}
    window._analyze()
    assert '"unique_evidence"' in window.details.toPlainText()


def test_desktop_unlock_prompt_accepts_passphrase(app, tmp_path, monkeypatch):
    pytest.importorskip("cryptography")
    from osint_framework import desktop
    from osint_framework.core.vault import _KEYS, Vault
    Vault.initialize(tmp_path, "synthetic desktop password")
    _KEYS.clear()
    monkeypatch.delenv("OSINT_VAULT_PASSPHRASE", raising=False)
    monkeypatch.setattr(desktop.QInputDialog, "getText", lambda *args: ("synthetic desktop password", True))
    monkeypatch.setattr(desktop.QApplication, "exec", lambda self: 0)
    class FakeWindow:
        def __init__(self, state, out):
            assert Vault(state).enabled
        def show(self):
            pass
    monkeypatch.setattr(desktop, "PhoneWindow", FakeWindow)
    assert desktop.launch(tmp_path, tmp_path / "out", phone_only=True) == 0
