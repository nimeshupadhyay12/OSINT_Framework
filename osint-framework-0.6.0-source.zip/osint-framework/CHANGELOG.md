# Changelog

## 0.6.0 — 2026-09-14

- Fixed STIX claim identity collisions, retained restrictions across case aggregation and exposed original relationship types in graphs. Shared marking definitions serialize once per report; legacy reports normalize on read.
- Separated anonymous and authenticated API quotas; added a five-second body deadline and bounded report pagination.
- Added 8 MB expanded import and 16 MB serialized report budgets.
- Fixed document WARC export, including encrypted and legacy evidence. Archives publish atomically without overwriting an existing file or leaving a partial final archive.
- Added Wayback CDX historical URL and public GitHub repository search adapters: 32 source modules.
- Added gau, waybackurls and Uncover offline contracts: 16 import contracts.
- Added guided broad research, no-key planning, bounded domain pivots and explicit coverage diagnostics in reports; desktop modes and research/research-plan commands.
- Added regression and workflow tests. Deployment-specific integrations still require live acceptance testing; no universal coverage or independent certification is claimed.

## 0.5.0 — 2026-09-14

- Added Common Crawl, Cert Spotter, OTX, URLhaus and ThreatFox: 30 source modules, with bounded read-only lookup POSTs for the latter two and source claims kept tentative.
- Added MISP exact-query attribute import and organisation-only draft export: 13 import contracts. Cross-format sharing controls fail closed when no mapping exists.
- Added an explicit optional OpenCTI connector command with work tracking and no automatic replay after uncertain transfers.
- Added encrypted Ed25519 signing keys, portable signed evidence bundles, detached signatures and WARC resource exports.
- Fixed blank-purpose desktop validation to reveal the required field and explain the missing input.
- Added token expiry (old tokens require rotation), OIDC JWT validation with locally provisioned roles, shared API limits and case evidence search.
- Added optional PostgreSQL shared state/queue coordination, Docker/TLS templates and a PostgreSQL integration CI job; local deployment testing remains outstanding.
- Added reviewed distribution hashes for plugins, Subfinder executable hash checks and isolated tool home/config directories.
- Added retention plans and explicit case-record deletion that preserves exports/audit/backups and refuses active jobs.
- Added dependency/SBOM checks and a manually triggered build-attestation workflow. No independent audit or hosted attestation is claimed.

## 0.4.0 — 2026-09-13

- Added InternetDB, RIPE, Wayback, Wikidata, Wikipedia, Hacker News, email-domain DNS and urlscan adapters: 25 source modules total, with seven new no-key sources and one free-account integration.
- Added compatible no-key selection to the desktop and `run --free-only` to the CLI.
- Added Recon-ng hosts/contacts CSV, Photon named-dataset JSON, and WhatsMyName unchecked-URL planning: 12 explicit import contracts total.
- Added persistent local jobs, finite scheduled rechecks, worker leases, cooperative cancellation and stale-job recovery without automatic request replay.
- Added optional team API with admin/analyst/viewer roles, case access, source allowlists and hashed revocable/rotatable tokens; CLI server binds to loopback.
- Added optional encryption for new workspaces, desktop unlock, encrypted automatic reports/artifacts, and explicit plaintext export.
- Added deterministic case comparisons and evidence paths with original direction and evidence IDs; rejected claims are excluded from paths.
- Added operational setup documentation, synthetic compatibility fixtures, live free-source acceptance checks and installed-release checks for encryption/queue/API workflows.

## 0.3.0 — 2026-09-12

- Added a universal desktop workbench for all seven identifier types, a saved-case SQLite store, evidence review history, notes, content-change tracking, graph selection, and explicit follow-up queries.
- Added versioned SpiderFoot, Amass names, and theHarvester JSONL imports; scoped live Scrapy extraction; and STIX 2.1 file import/export for OpenCTI.
- Added local document extraction with file hashes and page/paragraph/table provenance. Image OCR is available when Tesseract and its language data are installed.
- Added optional inert page snapshots, evidence-file verification, shared HTTP request budgets, and cancellation that preserves completed source results.
- Added per-investigation session credentials, explicit OS keychain storage, source setup diagnostics, and last saved source outcomes.
- Extended CLI case/document/diagnostic commands, Windows setup, CI, and installed-wheel smoke verification to cover the new capabilities.

## 0.2.0 — 2026-09-12

- Added the native Phone Workbench, session-only Brave key input, source statuses, email leads, evidence excerpts, and report shortcuts.
- Added guided `osint phone` input, international number normalization, and explicit local-only results.
- Added exact-number evidence from Brave snippets and approved public pages. Nearby emails remain tentative associations with source provenance.
- Added the Scrapy public-page-v1 JSON/JSONL import contract and synthetic fixture.
- Reviewed the supplied Start.me collection and documented relevant upstream tools and integration boundaries.
- Added Windows setup and launch scripts, explicit source-package inclusions, and an installed-package smoke check.

## 0.1.0 — 2026-09-12

- Initial local Python framework with typed findings, source adapters, a permitted-page scraper, bounded Subfinder runner, offline tool imports, evidence graphs, reports, audit logging, and request pacing.
