# Source access and responsibilities

Use the framework only within an authorized research scope. A public URL, open-source tool license, or robots permission does not grant every right to collect, retain, combine, or republish data. Operators must review the provider's current terms and applicable requirements for their purpose and jurisdiction.

Source `legal_basis` values are provenance and policy references supplied by adapters or operators. They are not legal determinations. A purpose field and authorization flag record an operator assertion; they cannot independently verify consent or prevent a modified copy from being misused.

The framework excludes private-profile access, credential attacks, CAPTCHA bypass, anti-bot evasion, unofficial reverse-phone owner lookups, raw breach dumps, and live-location tracking. Provider keys and subscriptions must belong to an authorized operator. Rate limiting and policy gates remain enabled.

Reports may contain personal data. Keep access limited, establish retention and deletion practices appropriate to the engagement, and review evidence before making consequential decisions. Audit query fingerprints are hashes, not anonymization. Reports and the local audit database are not encrypted by this application.

Framework source is MIT licensed. Third-party tools and datasets keep their own licenses; no upstream code or dataset is relicensed by this project. Review redistribution obligations before bundling them. Have I Been Pwned data requires clear attribution under its published terms; reports retain the provider name and evidence link. See [HIBP API and attribution terms](https://haveibeenpwned.com/API/V3#License) and [upstream research](docs/tool-research.md).

The optional desktop interface uses separately installed PySide6/Qt. Its distribution terms remain separate from the framework's MIT license; review the [Qt for Python licensing documentation](https://doc.qt.io/qtforpython-6/licenses.html) before redistributing a bundled desktop executable. The source archive does not bundle Qt binaries.
