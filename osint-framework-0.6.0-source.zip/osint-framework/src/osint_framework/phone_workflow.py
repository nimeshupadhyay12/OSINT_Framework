"""Shared phone investigation workflow with local reporting and explicit source scope."""

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .core.audit import AuditLog
from .core.engine import Engine
from .core.schema import QueryContext, RunReport
from .modules.native import PhoneLocalModule
from .modules.phone_evidence import PhonePagesModule, PhoneSearchModule
from .phone import manual_search_links, normalize_phone, phone_variants


class PhoneRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    number: str
    region: str | None = None
    purpose: str
    authorized: Literal[True]
    search_web: bool = False
    seed_urls: list[str] = Field(default_factory=list, max_length=20)
    allowed_hosts: list[str] = Field(default_factory=list, max_length=20)
    terms_url: str | None = None
    max_pages: int = Field(default=3, ge=1, le=20)
    max_findings: int = Field(default=500, ge=1, le=2000)

    def context(self) -> QueryContext:
        return QueryContext(query=normalize_phone(self.number, self.region), input_type="phone",
                            purpose=self.purpose, authorized=self.authorized, seed_urls=self.seed_urls,
                            allowed_hosts=self.allowed_hosts, terms_url=self.terms_url,
                            max_pages=self.max_pages, max_findings=self.max_findings)


@dataclass
class PhoneOutcome:
    report: RunReport
    paths: dict[str, Path]
    summary: dict


def summarize_phone(report: RunReport) -> dict:
    findings = [finding for result in report.results for finding in result.findings]
    return {
        "number": report.context.query,
        "formats": phone_variants(report.context.query),
        "emails": sorted({f.object.value for f in findings if f.relation == "email_near_number"}),
        "pages": sorted({f.object.value for f in findings if f.relation == "public_number_mention"}),
        "metadata": next((f.metadata for f in findings if f.source == "phone_local"), {}),
        "manual_search_links": manual_search_links(report.context.query),
        "statuses": [{"source": r.module, "status": r.status, "message": r.message} for r in report.results],
        "association_note": "Emails are public co-occurrence leads. Ownership is not verified.",
    }


async def run_phone(request: PhoneRequest, state_dir: Path, out_dir: Path, *, api_key=None, http=None) -> PhoneOutcome:
    context = request.context()
    modules = [PhoneLocalModule()]
    if request.search_web:
        modules.append(PhoneSearchModule(api_key))
    if request.seed_urls:
        modules.append(PhonePagesModule())
    report = await Engine(AuditLog(state_dir)).run(context, modules, http=http)
    report.notes.insert(0, "Phone/email associations mean nearby public source text, not verified subscriber ownership.")
    if not request.search_web and not request.seed_urls:
        report.notes.insert(0, "Only local numbering metadata was checked. No internet lookup was performed.")
    from .workflow import save_outcome
    paths = save_outcome(report, state_dir, out_dir).paths
    return PhoneOutcome(report=report, paths=paths, summary=summarize_phone(report))
