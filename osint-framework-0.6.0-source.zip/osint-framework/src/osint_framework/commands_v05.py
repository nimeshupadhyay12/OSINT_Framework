"""Explicit evidence transfer and release verification commands."""

import base64
import json
import os
from pathlib import Path

import typer

from .commands_v04 import checked
from .evidence import (
    bundle,
    export_warc,
    load_report,
    new_signing_key,
    read_limited,
    sign_bytes,
    verify_bundle,
    verify_signature,
)


def password():
    return os.environ.get("OSINT_SIGNING_PASSPHRASE") or typer.prompt("Signing key passphrase", hide_input=True)


def register_commands(app):
    evidence = typer.Typer(help="Explicit plaintext exports and independently verifiable signatures")
    app.add_typer(evidence, name="evidence")

    @app.command("retention-plan")
    @checked
    def retention_plan(days: int = 90, state: Path = Path(".osint-state")):
        from .maintenance import retention_plan as plan
        typer.echo(json.dumps(plan(state, days), indent=2))

    @app.command("delete-case-records")
    @checked
    def delete_case_records(case_id: str, confirm_case_id: str = typer.Option(...), state: Path = Path(".osint-state")):
        from .maintenance import delete_case_records as delete
        typer.echo(json.dumps(delete(state, case_id, confirm_case_id), indent=2))

    @app.command("approve-plugin")
    @checked
    def approve_plugin(name: str, out: Path, reviewed: bool = False):
        from .integrations.locks import distribution_receipt
        from .registry import available_plugins
        if not reviewed:
            raise ValueError("Review the installed package and its dependencies, then supply --reviewed")
        entry = available_plugins().get(name)
        if not entry or not entry.dist:
            raise ValueError("Named plugin is not installed")
        receipt = distribution_receipt(entry.dist.metadata["Name"])
        with out.open("x", encoding="utf-8") as stream:
            json.dump({"format": "osint-plugin-lock-v1", "plugins": {name: receipt}}, stream, indent=2)
        typer.echo("Set OSINT_PLUGIN_LOCK to " + str(out.resolve()) + "; approval covers this distribution, not its dependencies")

    @evidence.command("keygen")
    @checked
    def keygen(key: Path):
        typer.echo(str(new_signing_key(key, password()).resolve()))

    @evidence.command("bundle")
    @checked
    def make_bundle(file: Path, out: Path, key: Path = typer.Option(...),
                    evidence_root: Path = typer.Option(...), state: Path = Path(".osint-state")):
        bundle(load_report(file, state), out, key, password(), state, evidence_root)
        typer.echo("Signed plaintext bundle written: " + str(out.resolve()))

    @evidence.command("verify")
    @checked
    def verify(file: Path, public_key: Path = typer.Option(...)):
        typer.echo(json.dumps(verify_bundle(file, public_key), indent=2))

    @evidence.command("warc")
    @checked
    def warc(file: Path, out: Path, evidence_root: Path = typer.Option(...), state: Path = Path(".osint-state")):
        export_warc(load_report(file, state), out, state, evidence_root)
        typer.echo("Plaintext WARC resource records written; original response headers were not captured")

    @evidence.command("sign-file")
    @checked
    def sign_file(file: Path, signature: Path, key: Path = typer.Option(...)):
        raw = read_limited(file, 200_000_000)
        signed = sign_bytes(raw, key, password())
        with signature.open("xb") as stream:
            stream.write(base64.b64encode(signed))
        typer.echo("Detached Ed25519 signature written")

    @evidence.command("verify-file")
    @checked
    def verify_file(file: Path, signature: Path, public_key: Path = typer.Option(...)):
        verify_signature(read_limited(file, 200_000_000), base64.b64decode(read_limited(signature, 1024), validate=True), public_key)
        typer.echo("Signature verified against the supplied public key")

    @app.command("export-misp")
    @checked
    def misp(file: Path, out: Path, state: Path = Path(".osint-state")):
        from .integrations.misp_exchange import export_misp
        result = export_misp(load_report(file, state))
        with out.open("x", encoding="utf-8") as stream:
            json.dump(result, stream, indent=2)
        typer.echo("MISP draft event written: unpublished, organisation-only, to_ids=false")

    @app.command("opencti-send")
    @checked
    def opencti_send(file: Path, state: Path = Path(".osint-state"), authorized: bool = False, purpose: str = ""):
        from .integrations.opencti_connector import send_report
        result = send_report(load_report(file, state), state, authorized=authorized, purpose=purpose)
        typer.echo(json.dumps(result, indent=2))

    @app.command("search-case")
    @checked
    def search(case_id: str, text: str, state: Path = Path(".osint-state"), source: str = "", review: str = "", limit: int = 100):
        from .analysis import search_evidence
        typer.echo(json.dumps(search_evidence(state, case_id, text, source=source, review=review, limit=limit), indent=2))
