"""Phone input and public-evidence matching shared by the CLI and desktop UI."""

import re
from urllib.parse import urlencode

import phonenumbers
from bs4 import BeautifulSoup

from .core.schema import Entity

EMAIL_PATTERN = re.compile(r"(?<![\w.+-])[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}(?![\w-]|\.[A-Za-z0-9])")


def normalize_phone(value: str, region: str | None = None) -> str:
    """Allow formatting, but require an explicit country for national input."""
    value = value.strip()
    if not value or len(value) > 80 or not re.fullmatch(r"\+?[0-9\s().-]+", value):
        raise ValueError("Paste one phone number using digits, spaces, +, parentheses, or hyphens")
    region = region.strip().upper() if region else None
    if region and region not in phonenumbers.SUPPORTED_REGIONS:
        raise ValueError("Country must be a two-letter code such as IN, US, or GB")
    if not value.startswith("+") and not region:
        raise ValueError("Include + and the country code, or choose a country for a national number")
    try:
        parsed = phonenumbers.parse(value, region)
    except phonenumbers.NumberParseException as exc:
        raise ValueError("The phone number could not be parsed; check its country code") from exc
    if parsed.extension or not phonenumbers.is_possible_number(parsed):
        raise ValueError("The number's length is not possible for its country, or it has an extension")
    return phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164)


def phone_variants(e164: str) -> list[str]:
    parsed = phonenumbers.parse(e164, None)
    values = [e164,
              phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
              phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL)]
    return list(dict.fromkeys(values))


def phone_matches(text: str, e164: str) -> list[dict]:
    """Match complete number candidates, never a suffix inside a longer identifier."""
    parsed = phonenumbers.parse(e164, None)
    region = phonenumbers.region_code_for_number(parsed)
    matches = []
    for match in phonenumbers.PhoneNumberMatcher(text[:100_000], region,
                                                leniency=phonenumbers.Leniency.POSSIBLE):
        canonical = phonenumbers.format_number(match.number, phonenumbers.PhoneNumberFormat.E164)
        if canonical != e164 or match.number.extension:
            continue
        if (match.start and text[match.start - 1].isalnum()) or (match.end < len(text) and text[match.end].isalnum()):
            continue
        matches.append({"start": match.start, "end": match.end, "text": match.raw_string,
                        "national_format": not match.raw_string.strip().startswith("+")})
        if len(matches) >= 50:
            break
    return matches


def public_text(document: str) -> tuple[str, str]:
    soup = BeautifulSoup(document, "html.parser")
    title = soup.title.get_text(" ", strip=True)[:300] if soup.title else ""
    for tag in soup.select("script, style, noscript, template, head, input, textarea, [hidden], [aria-hidden='true']"):
        tag.decompose()
    for tag in soup.find_all(style=re.compile(r"display\s*:\s*none|visibility\s*:\s*hidden", re.I)):
        tag.decompose()
    # Only published text, not hidden attributes or embedded structured records.
    return soup.get_text(" ", strip=True)[:100_000], title


def nearby_emails(text: str, matches: list[dict], distance: int = 300) -> list[dict]:
    """A nearby address is a co-occurrence lead, never an ownership assertion."""
    results, seen = [], set()
    for match in EMAIL_PATTERN.finditer(text[:100_000]):
        if len(results) >= 50:
            break
        if not any(max(0, match.start() - phone["end"], phone["start"] - match.end()) <= distance for phone in matches):
            continue
        try:
            address = Entity(kind="email", value=match.group().rstrip(".")).value
        except ValueError:
            continue
        if address in seen:
            continue
        seen.add(address)
        nearest = min(matches, key=lambda phone: abs(phone["start"] - match.start()))
        left = max(0, min(nearest["start"], match.start()) - 45)
        right = min(len(text), max(nearest["end"], match.end()) + 45)
        results.append({"email": address, "excerpt": text[left:right][:600],
                        "national_format": nearest["national_format"]})
    return results


def manual_search_links(e164: str) -> list[dict[str, str]]:
    """Generate URLs offline. Opening a link sends the number to that search provider."""
    exact = '"' + e164 + '"'
    return [
        {"label": "Google · exact number", "url": "https://www.google.com/search?" + urlencode({"q": exact})},
        {"label": "Bing · exact number", "url": "https://www.bing.com/search?" + urlencode({"q": exact})},
        {"label": "Brave · exact number", "url": "https://search.brave.com/search?" + urlencode({"q": exact})},
    ]
