"""Self-contained, offline evidence reports with a CSP and escaped untrusted data."""

import base64
import hashlib
import html
import json
from collections import Counter
from itertools import islice
from pathlib import Path
from string import Template
from xml.etree import ElementTree as ET

from osint_framework.core.schema import Finding, RunReport, normalize

MAX_GRAPH_NODES = 1000
MAX_GRAPH_EDGES = 5000


def _e(value) -> str:
    return html.escape(str(value), quote=True)


def _link(url: str, label: str) -> str:
    try:
        safe = normalize("url", url)
    except (ValueError, TypeError, AttributeError):
        return _e(label)
    return f'<a href="{_e(safe)}" target="_blank" rel="noopener noreferrer">{_e(label)}</a>'


def _evidence_row(finding: Finding) -> str:
    time_label = "Imported" if finding.metadata.get("timestamp_kind") == "imported_at" else "Observed"
    metadata = json.dumps(finding.metadata, ensure_ascii=True, indent=2, sort_keys=True)
    return (
        f'<tr data-source="{_e(finding.source)}" data-confidence="{_e(finding.confidence)}" '
        f'data-evidence="{_e(finding.id)}"><td><span class="source">{_e(finding.source)}</span>'
        f'<small>{_e(finding.id[:12])}</small></td>'
        f'<td><span class="entity">{_e(finding.subject.value)}</span>'
        f'<small>{_e(finding.subject.kind)}</small></td>'
        f'<td><span class="relation">{_e(finding.relation.replace("_", " "))}</span></td>'
        f'<td><span class="entity">{_e(finding.object.value)}</span>'
        f'<small>{_e(finding.object.kind)}</small></td>'
        f'<td><span class="badge {_e(finding.confidence)}">{_e(finding.confidence)}</span></td>'
        f'<td>{_link(finding.evidence_url, "Open source ↗")}<small>{time_label}<br>'
        f'{_e(finding.observed_at.isoformat(timespec="seconds"))}</small>'
        f'<details><summary>Provenance</summary><p>{_e(finding.legal_basis)}</p>'
        f'<pre>{_e(metadata)}</pre></details></td></tr>'
    )


_CSS = """
:root{color-scheme:dark;--bg:#08121f;--panel:#101e2f;--line:#24374b;--text:#e9f1f8;--muted:#97afc4;--teal:#5de4c7;--amber:#f0c178}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Inter,Segoe UI,Arial,sans-serif;font-size:14px;line-height:1.55}
a{color:var(--teal);text-decoration:none}a:hover{text-decoration:underline}button,input,select{font:inherit}button,select{cursor:pointer}
.wrap{max-width:1500px;margin:auto;padding:32px 38px}.topbar{display:flex;justify-content:space-between;align-items:center;gap:20px;border-bottom:1px solid var(--line);padding-bottom:20px}
.brand{font-size:16px;font-weight:750;letter-spacing:2px}.brand b{color:var(--teal);margin-right:12px}.eyebrow{color:var(--teal);text-transform:uppercase;letter-spacing:2px;font-size:11px;font-weight:700}
.private{border:1px solid var(--line);border-radius:30px;padding:6px 12px;color:var(--muted);font-size:11px;letter-spacing:1px}.hero{display:grid;grid-template-columns:1fr auto;gap:30px;padding:35px 0 26px}
h1{font-size:clamp(26px,4vw,46px);line-height:1.12;margin:10px 0 16px;letter-spacing:-1px;overflow-wrap:anywhere}h2{font-size:18px;margin:0;letter-spacing:-.3px}p{margin:8px 0}.muted,small{color:var(--muted)}small{display:block;font-size:11px;margin-top:4px;overflow-wrap:anywhere}.purpose{max-width:850px;color:#bfd0de}.run{font-family:Consolas,monospace;font-size:11px;text-align:right;color:var(--muted);padding-top:28px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:0 0 24px}.stat{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:20px}.stat strong{display:block;font-size:30px;line-height:1.2;letter-spacing:-1px}.stat span{font-size:11px;text-transform:uppercase;color:var(--muted);letter-spacing:1px}.stat:first-child strong{color:var(--teal)}
.notice{border:1px solid #4d4736;border-left:3px solid var(--amber);background:#201f1c;border-radius:8px;padding:14px 18px;margin-bottom:24px;color:#e3d8be;font-size:12px}.notice strong{color:#f1cc8e}.panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;margin-bottom:24px;overflow:hidden}.panelhead{padding:20px 22px;border-bottom:1px solid var(--line);display:flex;justify-content:space-between;align-items:center;gap:16px}.panelhead p{font-size:12px;color:var(--muted);margin:3px 0 0}.grapharea{position:relative;background:radial-gradient(ellipse at center,#132b3d,var(--bg));height:440px;overflow:hidden}canvas{display:block;width:100%;height:100%;touch-action:none;cursor:grab}canvas:active{cursor:grabbing}.graphdetail{position:absolute;bottom:14px;left:18px;right:18px;pointer-events:none;font-size:12px;color:var(--muted);background:#08121fe6;padding:8px 12px;border:1px solid var(--line);border-radius:6px;overflow-wrap:anywhere}
.controls{display:flex;align-items:center;gap:8px;flex-wrap:wrap}button,select,input{background:#0a1726;border:1px solid #344d64;border-radius:7px;color:var(--text);padding:9px 12px}button:hover{border-color:var(--teal);color:var(--teal)}button:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:2px solid var(--teal);outline-offset:3px}button{font-size:12px}label{font-size:12px;color:var(--muted)}input[type=checkbox]{accent-color:var(--teal)}.filters{display:flex;gap:10px;flex-wrap:wrap;padding:16px 22px;border-bottom:1px solid var(--line)}.filters input{flex:1;min-width:200px}.count{align-self:center;margin-left:auto;color:var(--muted);font-size:12px}.tablewrap{overflow:auto}table{width:100%;border-collapse:collapse;text-align:left}th{text-transform:uppercase;color:var(--muted);font-weight:600;font-size:10px;letter-spacing:1px;padding:13px 18px;background:#0c1928;white-space:nowrap}td{padding:18px;vertical-align:top;border-top:1px solid #233447;font-size:12px}tr[hidden]{display:none}tr:hover td{background:#14283b}.entity{font-weight:550;overflow-wrap:anywhere}.source{color:#c6dfed;font-family:Consolas,monospace}.relation{color:var(--muted);white-space:nowrap}.badge{display:inline-block;padding:3px 8px;border:1px solid #4c5261;border-radius:5px;font-size:10px;text-transform:uppercase;letter-spacing:.4px;white-space:nowrap}.certain,.ok{color:#7fe3c7;background:#123832;border-color:#256254}.likely{color:#99caff;background:#132e49;border-color:#315b7f}.tentative,.skipped{color:#efc990;background:#3a3022;border-color:#67533a}.error,.rate_limited{color:#ffa9a9;background:#3c232c;border-color:#744152}.empty{color:var(--muted)}details{margin-top:9px}summary{color:var(--muted);cursor:pointer;font-size:11px}details p{max-width:380px}pre{white-space:pre-wrap;overflow-wrap:anywhere;max-width:420px;color:#a4b9ca;font-size:10px}.sources{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;padding:20px}.sourcecard{border:1px solid var(--line);border-radius:8px;padding:14px}.sourcecard .line{display:flex;justify-content:space-between;gap:10px}.sourcecard p{font-size:12px;color:var(--muted);overflow-wrap:anywhere}.emptymsg{padding:30px;text-align:center;color:var(--muted)}footer{color:var(--muted);font-size:11px;display:flex;justify-content:space-between;gap:20px;padding:8px 0 24px}.footnotes{margin:0;padding-left:18px}.footnotes li{margin:4px 0}.legend{font-size:11px;color:var(--muted);padding:10px 22px;border-top:1px solid var(--line)}.legend span{margin-right:18px}.legend b{color:var(--teal);margin-right:4px}
@media(max-width:750px){.wrap{padding:18px}.hero{grid-template-columns:1fr;gap:0}.run{text-align:left;padding:0}.stats{grid-template-columns:repeat(2,1fr)}.panelhead{align-items:flex-start;flex-direction:column}.private{display:none}.grapharea{height:360px}footer{flex-direction:column}.stat{padding:14px}td{min-width:140px}}
@media print{body{background:white;color:#142331}.wrap{max-width:none;padding:0}.panel,.stat{break-inside:avoid;background:white;color:#142331}.controls,.filters,canvas,.graphdetail{display:none}.grapharea{display:none}a{color:#126250}.tablewrap{overflow:visible}th,td{padding:8px}.notice{background:#fff7e9}.muted,small,.sourcecard p{color:#456}.panel{border-color:#ccd}footer{display:block}.stats{margin-bottom:12px}}
"""

_JS = r"""
(() => {
'use strict';
const data = JSON.parse(document.getElementById('graph-data').content.textContent);
const canvas = document.getElementById('graph'), ctx = canvas.getContext('2d');
const rows = [...document.querySelectorAll('tr[data-evidence]')];
const search = document.getElementById('search'), source = document.getElementById('source-filter');
const confidence = document.getElementById('confidence-filter'), status = document.getElementById('status-filter');
const detail = document.getElementById('graph-detail'), labels = document.getElementById('labels');
const nodes = [...data.nodes].sort((a,b) => (a.kind+'\0'+a.value).localeCompare(b.kind+'\0'+b.value));
const byId = new Map(), colors={username:'#5de4c7',domain:'#70b5ef',profile:'#c7a4fc',email:'#f0c178',ip:'#8fc6fa',name:'#e6adc8',breach:'#e49691'};
let scale=1, px=0, py=0, width=1, height=1, drag=null, active=new Set(), visibleEdges=[];
nodes.forEach((n,i) => { const ring=Math.floor(Math.sqrt(i)), start=ring*ring, count=2*ring+1;
  const angle=(i-start)/count*Math.PI*2-Math.PI/2, radius=ring*88;
  byId.set(n.id,{...n,x:Math.cos(angle)*radius,y:Math.sin(angle)*radius}); });
function fit(){const extent=Math.max(150,Math.ceil(Math.sqrt(nodes.length))*88+100);
  scale=Math.min(width/(extent*2),height/(extent*2),1.6);px=width/2;py=height/2;draw();}
function resize(){const box=canvas.getBoundingClientRect();width=box.width;height=box.height;
  const dpr=window.devicePixelRatio||1;canvas.width=width*dpr;canvas.height=height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);fit();}
function draw(){ctx.clearRect(0,0,width,height);ctx.save();ctx.translate(px,py);ctx.scale(scale,scale);
  for(const e of visibleEdges){const a=byId.get(e.source),b=byId.get(e.target);if(!a||!b)continue;
    ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=e.confidence==='certain'?'#356968':'#294557';ctx.lineWidth=1/scale;ctx.stroke();}
  for(const n of byId.values()){if(!active.has(n.id))continue;ctx.beginPath();ctx.arc(n.x,n.y,Math.max(4,5/Math.sqrt(scale)),0,Math.PI*2);ctx.fillStyle=colors[n.kind]||'#a7bdcd';ctx.fill();
    if(labels.checked||nodes.length<=70){ctx.font=(11/Math.max(scale,.7))+'px Segoe UI, sans-serif';ctx.fillStyle='#c8dbe8';ctx.fillText(n.value.length>34?n.value.slice(0,31)+'…':n.value,n.x+11,n.y+4);}}
  ctx.restore();}
function filter(){const term=search.value.toLocaleLowerCase().trim();const visible=new Set();let visibleRows=0;
  for(const row of rows){const show=(!source.value||row.dataset.source===source.value)&&(!confidence.value||row.dataset.confidence===confidence.value)&&(!term||row.textContent.toLocaleLowerCase().includes(term));row.hidden=!show;if(show){visible.add(row.dataset.evidence);visibleRows++;}}
  document.getElementById('row-count').textContent=visibleRows+' of '+rows.length+' findings';
  document.getElementById('no-results').hidden=visible.size!==0;
  visibleEdges=data.edges.filter(e=>(e.evidence_ids||[]).some(id=>visible.has(id)));
  active=new Set(visibleEdges.flatMap(e=>[e.source,e.target]));
  if(!rows.length)nodes.forEach(n=>active.add(n.id));draw();}
[search,source,confidence].forEach(el=>el.addEventListener(el===search?'input':'change',filter));
status.addEventListener('change',()=>document.querySelectorAll('.sourcecard').forEach(card=>card.hidden=!!status.value&&card.dataset.status!==status.value));
document.getElementById('clear').addEventListener('click',()=>{search.value='';source.value='';confidence.value='';filter();});
document.getElementById('fit').addEventListener('click',fit);
function zoom(f,x=width/2,y=height/2){const next=Math.max(.03,Math.min(5,scale*f));px=x-(x-px)*next/scale;py=y-(y-py)*next/scale;scale=next;draw();}
document.getElementById('zoom-in').addEventListener('click',()=>zoom(1.25));
document.getElementById('zoom-out').addEventListener('click',()=>zoom(.8));labels.addEventListener('change',draw);
canvas.addEventListener('wheel',e=>{e.preventDefault();const r=canvas.getBoundingClientRect();zoom(e.deltaY<0?1.13:.88,e.clientX-r.left,e.clientY-r.top);},{passive:false});
canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY};canvas.setPointerCapture(e.pointerId);});
canvas.addEventListener('pointermove',e=>{if(!drag)return;px+=e.clientX-drag.x;py+=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;draw();});
canvas.addEventListener('pointerup',e=>{if(drag&&Math.hypot(e.clientX-drag.startX,e.clientY-drag.startY)<5){const r=canvas.getBoundingClientRect();const x=(e.clientX-r.left-px)/scale,y=(e.clientY-r.top-py)/scale;let nearest=null,distance=20/scale;
  for(const n of byId.values()){const d=Math.hypot(n.x-x,n.y-y);if(active.has(n.id)&&d<distance){nearest=n;distance=d;}}
  detail.textContent=nearest?nearest.kind+': '+nearest.value:'Drag to pan · Scroll to zoom · Click a node to inspect';}drag=null;});
canvas.addEventListener('pointercancel',()=>{drag=null;});
window.addEventListener('resize',resize);resize();filter();
})();
"""

_HTML = Template("""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="$csp"><meta name="referrer" content="no-referrer">
<title>OSINT evidence report · $query</title><style>$css</style></head>
<body><main class="wrap"><header class="topbar"><div class="brand"><b>◎</b> OSINT / CORRELATION</div><span class="private">LOCAL EVIDENCE REPORT</span></header>
<section class="hero"><div><div class="eyebrow">Investigation workspace · $input_type</div><h1>$query</h1><p class="purpose">$purpose</p></div><div class="run">RUN $run_id<br>$created_at<br>SCHEMA $schema_version</div></section>
<section class="stats" aria-label="Report summary"><div class="stat"><strong>$findings_count</strong><span>Evidence records</span></div><div class="stat"><strong>$entity_count</strong><span>Distinct entities</span></div><div class="stat"><strong>$source_count</strong><span>Modules in this run</span></div><div class="stat"><strong>$tentative_count</strong><span>Tentative leads</span></div></section>
<aside class="notice"><strong>Confidence belongs to a relationship.</strong> Shared names or usernames do not establish a person's identity. Empty, skipped, or failed sources do not prove absence. Imported records retain tentative confidence; an “Imported” timestamp is the receipt time when the original observation time is unknown.</aside>
<section class="panel" aria-labelledby="graph-title"><div class="panelhead"><div><h2 id="graph-title">Relationship map</h2><p>Showing $display_entity_count of $entity_count entities and $display_edge_count of $edge_count relationships. Filters below also update this view.</p>$graph_notice</div><div class="controls"><label><input type="checkbox" id="labels"> All labels</label><button id="zoom-out" aria-label="Zoom out">−</button><button id="zoom-in" aria-label="Zoom in">+</button><button id="fit">Fit view</button></div></div><div class="grapharea"><canvas id="graph" aria-label="Interactive relationship graph; equivalent relationships are listed in the evidence table." role="img"></canvas><div class="graphdetail" id="graph-detail" aria-live="polite">Drag to pan · Scroll to zoom · Click a node to inspect</div></div><div class="legend"><span><b>●</b> Username</span><span>● Domain / IP</span><span>● Profile</span><span>Edges describe claims, not proof of identity</span></div></section>
<section class="panel" aria-labelledby="evidence-title"><div class="panelhead"><div><h2 id="evidence-title">Evidence ledger</h2><p>Every relationship links to its source and collection context.</p></div></div><div class="filters"><input id="search" type="search" aria-label="Search evidence" placeholder="Search entities, sources, evidence…"><select id="source-filter" aria-label="Filter evidence by source"><option value="">All evidence sources</option>$source_options</select><select id="confidence-filter" aria-label="Filter by confidence"><option value="">All confidence levels</option><option>certain</option><option>likely</option><option>tentative</option></select><button id="clear">Clear</button><span class="count" id="row-count">$findings_count findings</span></div><div class="tablewrap"><table><thead><tr><th>Source / evidence ID</th><th>Subject</th><th>Relationship</th><th>Object</th><th>Confidence</th><th>Evidence / provenance</th></tr></thead><tbody>$rows</tbody></table></div><p class="emptymsg" id="no-results" hidden>No findings match these filters.</p></section>
<section class="panel" aria-labelledby="sources-title"><div class="panelhead"><div><h2 id="sources-title">Source coverage</h2><p>A complete record of successful, empty, skipped, and failed modules.</p></div><select id="status-filter" aria-label="Filter module statuses"><option value="">All module statuses</option><option>ok</option><option>empty</option><option>skipped</option><option>error</option><option>rate_limited</option><option>cancelled</option></select></div><div class="sources">$statuses</div></section>
$artifacts
<footer><ul class="footnotes">$notes</ul><div>Generated locally. No scripts, fonts, or graph data are fetched remotely.<br>Breach data, when present, is attributed to <a href="https://haveibeenpwned.com/" target="_blank" rel="noopener noreferrer">Have I Been Pwned</a>.</div></footer>
<noscript><p class="notice">JavaScript is disabled. The complete evidence ledger and source statuses remain available; graph and filters require JavaScript.</p></noscript>
</main><template id="graph-data">$graph_data</template><script>$js</script></body></html>
""")


def _hash(text: str) -> str:
    return base64.b64encode(hashlib.sha256(text.encode("utf-8")).digest()).decode("ascii")


def _display_graph(report: RunReport) -> dict:
    """Bound only the interactive preview; preserve the complete report model.

    Keep the queried entity and then the most connected entities, with stable
    identifiers breaking ties. An edge cap also bounds dense previews.
    """
    graph = report.graph
    edges = graph.get("edges", [])
    query_id = report.context.entity.id
    degree = Counter(endpoint for edge in edges for endpoint in (edge["source"], edge["target"]))
    selected = sorted(graph.get("nodes", []), key=lambda node: (
        node["id"] != query_id, -degree[node["id"]], node["id"]
    ))[:MAX_GRAPH_NODES]
    ids = {node["id"] for node in selected}
    selected_edges = (edge for edge in edges if edge["source"] in ids and edge["target"] in ids)
    return {"nodes": selected, "edges": list(islice(selected_edges, MAX_GRAPH_EDGES))}


def _render_html(report: RunReport) -> str:
    findings = [item for result in report.results for item in result.findings]
    counts = Counter(item.confidence for item in findings)
    displayed = _display_graph(report)
    limited = (len(displayed["nodes"]) < len(report.graph.get("nodes", []))
               or len(displayed["edges"]) < len(report.graph.get("edges", [])))
    graph_notice = (
        '<p><strong>Graph preview limit reached.</strong> The evidence ledger, JSON, and GraphML '
        'retain all results. Filters affect the displayed graph subset.</p>' if limited else ""
    )
    statuses = []
    for result in report.results:
        message = result.message or ("Findings collected." if result.findings else "No findings returned.")
        statuses.append(
            f'<article class="sourcecard" data-status="{_e(result.status)}"><div class="line">'
            f'<strong>{_e(result.module)}</strong><span class="badge {_e(result.status)}">'
            f'{_e(result.status)}</span></div><p>{_e(message)}</p>'
            f'<small>{len(result.findings)} findings · {result.elapsed_ms} ms'
            f'{" · limit reached; results truncated" if result.truncated else ""}</small></article>'
        )
    csp = ("default-src 'none'; script-src 'sha256-" + _hash(_JS)
           + "'; style-src 'sha256-" + _hash(_CSS)
           + "'; img-src 'none'; connect-src 'none'; font-src 'none'; object-src 'none'; "
             "base-uri 'none'; form-action 'none'; frame-src 'none'")
    return _HTML.substitute(
        csp=_e(csp), css=_CSS, js=_JS, query=_e(report.title or report.context.query),
        input_type=_e(report.context.input_type), purpose=_e(report.context.purpose),
        run_id=_e(report.run_id), created_at=_e(report.created_at.isoformat(timespec="seconds")),
        schema_version=_e(report.schema_version), findings_count=len(findings),
        entity_count=len(report.graph.get("nodes", [])), source_count=len(report.results),
        tentative_count=counts["tentative"], edge_count=len(report.graph.get("edges", [])),
        display_entity_count=len(displayed["nodes"]), display_edge_count=len(displayed["edges"]),
        graph_notice=graph_notice,
        source_options="".join(f'<option value="{_e(s)}">{_e(s)}</option>'
                               for s in sorted({item.source for item in findings})),
        rows="".join(_evidence_row(item) for item in findings), statuses="".join(statuses),
        notes="".join(f"<li>{_e(note)}</li>" for note in report.notes),
        artifacts=('<section class="panel"><div class="panelhead"><h2>Preserved evidence files</h2></div>'
                   '<div class="sources">' + "".join('<article class="sourcecard"><strong>'
                   + _e(item.get("original_name", item.get("url", "Evidence"))) + '</strong><p>'
                   + _e(item.get("path", "")) + '</p><small>SHA-256: ' + _e(item.get("sha256", ""))
                   + '</small></article>' for item in report.artifacts) + '</div></section>') if report.artifacts else "",
        graph_data=_e(json.dumps(displayed, ensure_ascii=True, allow_nan=False)),
    )


def _graphml(report: RunReport) -> bytes:
    namespace = "http://graphml.graphdrawing.org/xmlns"
    ET.register_namespace("", namespace)
    root = ET.Element(f"{{{namespace}}}graphml")
    for key, target in (("kind", "node"), ("value", "node"), ("relation", "edge"),
                        ("confidence", "edge"), ("sources", "edge"), ("evidence_ids", "edge")):
        ET.SubElement(root, f"{{{namespace}}}key", {
            "id": key, "for": target, "attr.name": key, "attr.type": "string"})
    graph = ET.SubElement(root, f"{{{namespace}}}graph", {"id": "evidence", "edgedefault": "directed"})
    for node in report.graph.get("nodes", []):
        element = ET.SubElement(graph, f"{{{namespace}}}node", {"id": str(node["id"])})
        for key in ("kind", "value"):
            ET.SubElement(element, f"{{{namespace}}}data", {"key": key}).text = str(node.get(key, ""))
    for number, edge in enumerate(report.graph.get("edges", [])):
        element = ET.SubElement(graph, f"{{{namespace}}}edge", {
            "id": f"e{number}", "source": str(edge["source"]), "target": str(edge["target"])})
        for key in ("relation", "confidence", "sources", "evidence_ids"):
            value = edge.get(key, "")
            ET.SubElement(element, f"{{{namespace}}}data", {"key": key}).text = (
                json.dumps(value, ensure_ascii=True) if isinstance(value, list) else str(value))
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def write_report(report: RunReport, out_dir: Path) -> dict[str, Path]:
    """Write JSON, HTML, and GraphML under fixed filenames (no query-derived paths)."""
    out_dir = Path(out_dir)
    # Construct every representation before touching output files.
    content = {"json": report.bounded_json().encode("utf-8"),
               "html": _render_html(report).encode("utf-8"), "graphml": _graphml(report)}
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for extension, payload in content.items():
        path = out_dir / f"report.{extension}"
        path.write_bytes(payload)
        paths[extension] = path.resolve()
    return paths
