"""Plugins are opt-in because entry-point loading executes installed Python code."""

from importlib.metadata import entry_points

from .core.schema import ModuleSpec
from .modules.discovery import discovery_modules
from .modules.free_sources import free_modules
from .modules.native import builtin_modules
from .modules.phone_evidence import PhonePagesModule, PhoneSearchModule
from .modules.scrapy_pages import ScrapyPagesModule
from .modules.threat_sources import threat_modules
from .modules.webpage import WebpageModule


def available_plugins() -> dict:
    return {entry.name: entry for entry in entry_points(group="osint_framework.modules")}


def registry(plugin_names: list[str] | None = None) -> dict:
    modules = {module.spec.name: module for module in [*builtin_modules(), *free_modules(), *threat_modules(), *discovery_modules(), WebpageModule(), PhoneSearchModule(), PhonePagesModule(), ScrapyPagesModule()]}
    plugins = available_plugins() if plugin_names else {}
    for name in plugin_names or []:
        if name not in plugins:
            raise ValueError(f"Plugin entry point is not installed: {name}")
        if name in modules:
            raise ValueError(f"Plugin cannot replace a built-in module: {name}")
        from .integrations.locks import require_plugin_approval
        require_plugin_approval(plugins[name])
        module = plugins[name].load()()
        spec = ModuleSpec.model_validate(module.spec)
        if spec.name != name or not callable(getattr(module, "run", None)):
            raise ValueError("Plugin name or interface does not match its entry point")
        modules[name] = module
    return modules
