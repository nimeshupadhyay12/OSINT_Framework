"""Shared investigation workflow for every input type, desktop and CLI."""

import hashlib
import ipaddress
import re
from dataclasses import dataclass
from pathlib import Path

from .catalog import modules
from .core.audit import AuditLog
from .core.cases import CaseStore
from .core.credentials import credentials
from .core.engine import Engine
from .core.schema import ModuleResult, QueryContext, RunReport, normalize, utcnow
from .core.vault import Vault
from .integrations.imports import parse_import
from .phone import normalize_phone
from .report import write_report


def detect_type(value):
    value = value.strip()
    if value.startswith(("http://", "https://")):
        return "url"
    if "@" in value and not value.startswith("@"):
        return "email"
    try:
        ipaddress.ip_address(value)
        return "ip"
    except ValueError:
        pass
    if value.startswith("+") and re.fullmatch(r"[+\d ().-]+", value):
        return "phone"
    try:
        normalize("domain", value)
        return "domain"
    except ValueError:
        return "name" if any(c.isspace() for c in value) else "username"


def make_context(query, kind, purpose, authorized, *, region=None, **options):
    kind = detect_type(query) if kind == "auto" else kind
    if kind == "phone":
        query = normalize_phone(query, region)
    return QueryContext(query=query, input_type=kind, purpose=purpose, authorized=authorized, **options)


@dataclass
class Outcome:
    report: RunReport
    paths: dict
    case_id: str | None = None


def save_outcome(report, state, out, case_id=None):
    payload = report.bounded_json()
    vault = Vault(state)
    if vault.enabled:
        path = Path(out) / report.run_id / "report.json.enc"
        vault.write_bytes(path, payload.encode(), "report-file")
        paths = {"encrypted": path}
    else:
        paths = write_report(report, Path(out) / report.run_id)
    if case_id:
        CaseStore(state).add(case_id, report)
    return Outcome(report, paths, case_id)


async def investigate(context, names, state, out, *, case_id=None, secrets=None, cancel_event=None, http=None, available=None):
    if case_id:
        CaseStore(state).get(case_id)
    available = modules() if available is None else available
    if not names:
        raise ValueError("Select at least one applicable source")
    if set(names) - available.keys():
        raise ValueError("Unknown source selection")
    if any(context.input_type not in available[name].spec.input_types for name in names):
        raise ValueError("A selected source does not support this input type")
    artifacts = []
    vault = Vault(state)

    def snapshot(url, body):
        digest = hashlib.sha256(body).hexdigest()
        directory = Path(out) / "evidence"
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / (digest + (".txt.enc" if vault.enabled else ".txt"))
        vault.write_bytes(path, body)
        artifacts.append({"url": url, "sha256": digest, "bytes": len(body), "path": str(path.resolve()),
                          "captured_at": utcnow().isoformat(), "encrypted": vault.enabled,
                          "format": "encrypted response bytes" if vault.enabled else "raw response bytes stored as inert text"})

    with credentials(secrets):
        report = await Engine(AuditLog(Path(state))).run(context, [available[name] for name in dict.fromkeys(names)],
                    http=http, cancel_event=cancel_event, snapshot=snapshot if context.preserve_pages else None)
    report.artifacts = artifacts
    return save_outcome(report, state, out, case_id)


async def import_report(context, tool, file, state, out, *, case_id=None):
    if case_id:
        CaseStore(state).get(case_id)
    engine = Engine(AuditLog(Path(state)))
    run_id = engine.start(context, ["import:" + tool])
    try:
        findings = parse_import(tool, Path(file), context)
        report = engine.finish(run_id, context, [ModuleResult(module="import:" + tool,
                                  status="ok" if findings else "empty", findings=findings,
                                  message="Only the documented export subset is imported; inspect provenance for source status.")])
        return save_outcome(report, state, out, case_id)
    except BaseException:
        engine.audit.append("run_aborted", {"run_id": run_id})
        raise
