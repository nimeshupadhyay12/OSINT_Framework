"""Local queue, encryption and optional team service commands."""

import asyncio
import json
import sqlite3
from functools import wraps
from pathlib import Path

import typer

from .catalog import free_selection
from .core.audit import AuditLog
from .core.schema import RunReport
from .core.vault import Vault
from .jobs import JobStore, work_once
from .report import write_report
from .team import TeamStore, create_app
from .workflow import make_context


def checked(function):
    @wraps(function)
    def invoke(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except (ValueError, OSError, sqlite3.Error) as exc:
            message = str(exc) if isinstance(exc, ValueError) else "Local storage operation failed; check paths, permissions and existing records"
            raise typer.BadParameter(message) from None
    return invoke


def register_commands(app):
    jobs = typer.Typer(help="Persistent jobs and finite scheduled rechecks")
    vault = typer.Typer(help="Create or explicitly export a protected workspace")
    team = typer.Typer(help="Local team API and administrator-managed access tokens")
    app.add_typer(jobs, name="jobs")
    app.add_typer(vault, name="vault")
    app.add_typer(team, name="team")

    @app.command("analyze-case")
    @checked
    def analysis(case_id: str, state: Path = Path(".osint-state"), start: str = "", end: str = ""):
        from .analysis import analyze_case, evidence_path
        result = evidence_path(state, case_id, start, end) if start and end else analyze_case(state, case_id)
        typer.echo(json.dumps(result, indent=2))

    @jobs.command("enqueue")
    @checked
    def enqueue(case_id: str, query: str, kind: str = typer.Option(..., "--type"), purpose: str = typer.Option(...),
                authorized: bool = False, sources: str = "", repeat: int = 1, interval_hours: int = 24,
                state: Path = Path(".osint-state")):
        if not authorized or not AuditLog(state).consented():
            raise typer.BadParameter("Accept the policy and supply --authorized for this queued investigation")
        context = make_context(query, kind, purpose, True)
        selected = sources.split(",") if sources else free_selection(context)
        identifier = JobStore(state).enqueue(case_id, context, selected, repeat=repeat, interval_seconds=interval_hours * 3600)
        typer.echo(identifier)

    @jobs.command("list")
    @checked
    def list_jobs(case_id: str = "", state: Path = Path(".osint-state")):
        typer.echo(json.dumps(JobStore(state).jobs(case_id or None), indent=2))

    @jobs.command("cancel")
    @checked
    def cancel(identifier: str, state: Path = Path(".osint-state")):
        JobStore(state).cancel(identifier)
        typer.echo("Queued descendants cancelled; an active worker will stop unfinished sources")

    @jobs.command("worker")
    @checked
    def worker(state: Path = Path(".osint-state"), out: Path = Path("reports"), once: bool = typer.Option(True, "--once/--continuous")):
        async def loop():
            while True:
                result = await work_once(state, out)
                if result:
                    typer.echo(json.dumps({"job": result["id"], "status": result["status"], "run_id": result["run_id"]}))
                if once:
                    return
                await asyncio.sleep(2)
        try:
            asyncio.run(loop())
        except KeyboardInterrupt:
            typer.echo("Worker stopped")

    @vault.command("init")
    @checked
    def initialize(state: Path = typer.Option(..., help="New empty directory for encrypted state")):
        password = typer.prompt("Workspace passphrase (12+ characters)", hide_input=True, confirmation_prompt=True)
        Vault.initialize(state, password)
        typer.echo("Protected workspace created. Keep the passphrase and vault.json; neither can be recovered by this app.")

    @vault.command("export-report")
    @checked
    def export(file: Path, out: Path, state: Path = typer.Option(...)):
        protected = Vault(state)
        if not protected.enabled:
            raise typer.BadParameter("Choose the encrypted file's original workspace")
        report = RunReport.model_validate_json(protected.read_bytes(file, "report-file"))
        write_report(report, out)
        typer.echo("Explicit plaintext HTML/JSON/GraphML export written to " + str(out.resolve()))

    @team.command("user-add")
    @checked
    def user_add(name: str, role: str = "viewer", state: Path = Path(".osint-state"), days: int = 30):
        token = TeamStore(state).issue_token(name, role, days=days)
        typer.echo("Store this bearer token securely; it is shown only once:")
        typer.echo(token)

    @team.command("user-revoke")
    @checked
    def user_revoke(name: str, state: Path = Path(".osint-state")):
        TeamStore(state).revoke(name)
        typer.echo("Token revoked")

    @team.command("bind-oidc")
    @checked
    def bind_oidc(name: str, issuer: str, subject: str, state: Path = Path(".osint-state")):
        TeamStore(state).bind_oidc(name, issuer, subject)
        typer.echo("Exact issuer and subject mapped to this user's locally assigned role and expiry")

    @team.command("user-rotate")
    @checked
    def user_rotate(name: str, state: Path = Path(".osint-state"), days: int = 30):
        typer.echo("Previous token invalidated. Store the replacement securely; shown only once:")
        typer.echo(TeamStore(state).rotate_token(name, days=days))

    @team.command("ungrant")
    @checked
    def ungrant(name: str, case_id: str, state: Path = Path(".osint-state")):
        TeamStore(state).ungrant(name, case_id)
        typer.echo("Case access removed; administrators retain access to every case")

    @team.command("grant")
    @checked
    def grant(name: str, case_id: str, state: Path = Path(".osint-state")):
        TeamStore(state).grant(name, case_id)
        typer.echo("Case access granted")

    @team.command("serve")
    @checked
    def serve(state: Path = Path(".osint-state"), port: int = typer.Option(8765, min=1024, max=65535), sources: str = ""):
        try:
            import uvicorn
        except ImportError as exc:
            raise typer.BadParameter('Install .[team] to start the API') from exc
        application = create_app(state, allowed_sources=sources.split(",") if sources else None)
        typer.echo("API on loopback only. Run a separate jobs worker; no jobs execute inside the web server.")
        uvicorn.run(application, host="127.0.0.1", port=port, access_log=False, proxy_headers=False)
