"""Optional authenticated team API. Local filesystem owners remain trusted administrators."""

import hashlib
import secrets
import time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from .catalog import inventory, modules
from .core.audit import AuditLog
from .core.database import add_columns
from .core.schema import QueryContext
from .jobs import JobStore


class TeamStore(JobStore):
    def __init__(self, state):
        super().__init__(state)
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS principals(name TEXT PRIMARY KEY, role TEXT NOT NULL, token_sha256 TEXT NOT NULL UNIQUE, revoked INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS case_access(name TEXT NOT NULL REFERENCES principals(name), case_id TEXT NOT NULL REFERENCES cases(id), PRIMARY KEY(name,case_id));
                CREATE TABLE IF NOT EXISTS api_windows(bucket TEXT PRIMARY KEY, started DOUBLE PRECISION NOT NULL, requests INTEGER NOT NULL);
                CREATE TABLE IF NOT EXISTS oidc_bindings(issuer TEXT NOT NULL, subject TEXT NOT NULL, name TEXT NOT NULL REFERENCES principals(name), PRIMARY KEY(issuer,subject));
            """)
            db.execute("BEGIN IMMEDIATE")
            add_columns(db, "principals", {"expires_at": "DOUBLE PRECISION NOT NULL DEFAULT 0"})

    def issue_token(self, name, role, *, days=30):
        if name == "local" or not 3 <= len(name) <= 80 or not name.replace("_", "").replace("-", "").isalnum() or role not in {"admin", "analyst", "viewer"}:
            raise ValueError("Choose a 3–80 character user name and admin/analyst/viewer role")
        token = secrets.token_urlsafe(32)
        expiry = self.expiry(days)
        with self.connect() as db:
            db.execute("INSERT INTO principals(name,role,token_sha256,expires_at) VALUES(?,?,?,?)",
                       (name, role, hashlib.sha256(token.encode()).hexdigest(), expiry))
        return token

    @staticmethod
    def expiry(days):
        if type(days) is not int or not 1 <= days <= 90:
            raise ValueError("Token lifetime must be 1–90 days")
        return time.time() + days * 86400

    def active_user(self, name):
        with self.connect() as db:
            row = db.execute("SELECT name,role FROM principals WHERE name=? AND revoked=0 AND expires_at>?", (name, time.time())).fetchone()
        return dict(row) if row else None

    def bind_oidc(self, name, issuer, subject):
        if not self.active_user(name) or not issuer.startswith("https://") or not 1 <= len(subject) <= 500 or len(issuer) > 2000:
            raise ValueError("Provision an active local user and supply the exact HTTPS issuer and subject")
        with self.connect() as db:
            db.execute("INSERT INTO oidc_bindings VALUES(?,?,?)", (issuer, subject, name))

    def oidc_principal(self, issuer, subject):
        with self.connect() as db:
            row = db.execute("SELECT name FROM oidc_bindings WHERE issuer=? AND subject=?", (issuer, subject)).fetchone()
        return self.active_user(row[0]) if row else None

    def rate_allowed(self, bucket, limit=120):
        now = time.time()
        bucket = hashlib.sha256(bucket.encode()).hexdigest()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM api_windows WHERE started<?", (now - 120,))
            row = db.execute("SELECT started,requests FROM api_windows WHERE bucket=?", (bucket,)).fetchone()
            if row and now - row[0] < 60:
                if row[1] >= limit:
                    return False
                db.execute("UPDATE api_windows SET requests=requests+1 WHERE bucket=?", (bucket,))
            else:
                db.execute("INSERT INTO api_windows VALUES(?,?,1) ON CONFLICT(bucket) DO UPDATE SET started=excluded.started,requests=1", (bucket, now))
        return True

    def principal(self, token):
        if not token or len(token) > 200:
            return None
        with self.connect() as db:
            row = db.execute("SELECT name,role FROM principals WHERE token_sha256=? AND revoked=0 AND expires_at>?", (hashlib.sha256(token.encode()).hexdigest(), time.time())).fetchone()
        return dict(row) if row else None

    def revoke(self, name):
        with self.connect() as db:
            if not db.execute("UPDATE principals SET revoked=1 WHERE name=?", (name,)).rowcount:
                raise ValueError("User does not exist")

    def rotate_token(self, name, *, days=30):
        token = secrets.token_urlsafe(32)
        expiry = self.expiry(days)
        with self.connect() as db:
            if not db.execute("UPDATE principals SET token_sha256=?,revoked=0,expires_at=? WHERE name=?",
                (hashlib.sha256(token.encode()).hexdigest(), expiry, name)).rowcount:
                raise ValueError("User does not exist")
        return token

    def ungrant(self, name, case_id):
        self.get(case_id)
        with self.connect() as db:
            db.execute("DELETE FROM case_access WHERE name=? AND case_id=?", (name, case_id))

    def grant(self, name, case_id):
        self.get(case_id)
        with self.connect() as db:
            if not db.execute("SELECT 1 FROM principals WHERE name=? AND revoked=0", (name,)).fetchone():
                raise ValueError("User does not exist or is revoked")
            db.execute("INSERT OR IGNORE INTO case_access VALUES(?,?)", (name, case_id))

    def allowed(self, principal, case_id, write=False):
        if write and principal["role"] == "viewer":
            return False
        if principal["role"] == "admin":
            return True
        with self.connect() as db:
            return bool(db.execute("SELECT 1 FROM case_access WHERE name=? AND case_id=?", (principal["name"], case_id)).fetchone())


class CaseInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    title: str = Field(min_length=3, max_length=200)


class NoteInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str = Field(min_length=1, max_length=10000)


class ReviewInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    finding_id: str = Field(min_length=1, max_length=100)
    decision: Literal["accepted", "rejected", "unreviewed"]
    reason: str = Field(min_length=3, max_length=2000)


class JobInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    context: QueryContext
    sources: list[str] = Field(min_length=1, max_length=30)
    repeat: int = Field(default=1, ge=1, le=100)
    interval_seconds: int = Field(default=0, ge=0, le=31536000)


def create_app(state, *, allowed_sources=None, trusted_hosts=None):
    try:
        from fastapi import Depends, FastAPI, HTTPException, Query, Request
        from fastapi.responses import JSONResponse
        from fastapi.security import HTTPBearer
        from starlette.middleware.trustedhost import TrustedHostMiddleware
    except ImportError as exc:
        raise ValueError('Install the team extra: python -m pip install ".[team]"') from exc
    store = TeamStore(state)
    audit = AuditLog(store.directory)
    if not audit.consented():
        raise ValueError("Accept the policy with osint init before starting the team API")
    available = modules()
    allowed_sources = set(allowed_sources) if allowed_sources is not None else {
        name for name, module in available.items() if not module.spec.key_env and name != "subfinder"}
    if allowed_sources - available.keys():
        raise ValueError("Unknown source in server allowlist")
    app = FastAPI(title="OSINT Team API", version="0.6.0", docs_url=None, redoc_url=None, openapi_url=None)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=trusted_hosts or ["127.0.0.1", "localhost"])
    bearer = HTTPBearer(auto_error=False)
    from .oidc import OIDCVerifier
    oidc = OIDCVerifier()

    def current(request: Request, credential=Depends(bearer)):
        principal = getattr(request.state, "principal", None)
        if not principal:
            raise HTTPException(401, "A valid bearer token is required", headers={"WWW-Authenticate": "Bearer"})
        return principal

    def access(principal, case_id, write=False):
        if not store.allowed(principal, case_id, write):
            raise HTTPException(403, "Case access denied")

    def event(kind, principal, case_id, **fields):
        audit.append(kind, {"actor": principal["name"], "case_id": case_id, **fields})

    @app.middleware("http")
    async def bounded_request(request: Request, call_next):
        import asyncio
        if request.headers.get("origin"):
            return JSONResponse({"detail": "Browser cross-origin requests are not enabled"}, status_code=403)
        authorization = request.headers.get("authorization", "")
        scheme, _, token = authorization.partition(" ")
        principal = None
        if scheme.lower() == "bearer" and 0 < len(token) <= 16384:
            principal = await asyncio.to_thread(lambda: store.principal(token) or oidc.principal(token, store))
        request.state.principal = principal
        if principal:
            buckets = [("user:" + principal["name"], 120), ("authenticated", 600)]
        else:
            # Peer address only: untrusted forwarding headers cannot mint quotas.
            peer = request.client.host if request.client else "unknown"
            buckets = [("anonymous:" + peer, 60), ("anonymous-server", 600)]
        for bucket, limit in buckets:
            if not await asyncio.to_thread(store.rate_allowed, bucket, limit):
                return JSONResponse({"detail": "API request limit reached"}, status_code=429, headers={"Retry-After": "60"})
        length = request.headers.get("content-length")
        if length is not None and (not length.isdigit() or int(length) > 65536):
            return JSONResponse({"detail": "Request exceeds 64 KB or has invalid length"}, status_code=413)
        if not principal and request.url.path != "/health":
            return JSONResponse({"detail": "A valid bearer token is required"}, status_code=401,
                                headers={"WWW-Authenticate": "Bearer"})
        body = bytearray()
        try:
            async with asyncio.timeout(5):
                async for chunk in request.stream():
                    if len(body) + len(chunk) > 65536:
                        return JSONResponse({"detail": "Request exceeds 64 KB"}, status_code=413)
                    body.extend(chunk)
        except TimeoutError:
            return JSONResponse({"detail": "Request body timed out"}, status_code=408)
        request._body = bytes(body)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.exception_handler(ValueError)
    async def invalid(_request, exc):
        return JSONResponse({"detail": str(exc)}, status_code=400)

    @app.get("/health")
    def health():
        return {"status": "ok", "version": "0.6.0"}

    @app.get("/openapi.json")
    def schema(principal=Depends(current)):
        return app.openapi()

    @app.get("/sources")
    def sources(principal=Depends(current)):
        return [row for row in inventory() if row["name"] in allowed_sources]

    @app.get("/cases")
    def cases(principal=Depends(current)):
        return [row for row in store.list() if store.allowed(principal, row["id"])]

    @app.post("/cases", status_code=201)
    def create_case(body: CaseInput, principal=Depends(current)):
        if principal["role"] == "viewer":
            raise HTTPException(403, "Viewer cannot create cases")
        case_id = store.create(body.title)
        store.grant(principal["name"], case_id)
        event("team_case_created", principal, case_id)
        return store.get(case_id)

    @app.get("/cases/{case_id}")
    def case(case_id: str, principal=Depends(current), limit: int = Query(10, ge=1, le=25), offset: int = Query(0, ge=0)):
        access(principal, case_id)
        return {"case": store.get(case_id), "history": store.history(case_id),
                "reports": [report.model_dump(mode="json") for report in store.reports(case_id, limit=limit, offset=offset)],
                "limit": limit, "offset": offset}

    @app.post("/cases/{case_id}/access/{name}")
    def grant(case_id: str, name: str, principal=Depends(current)):
        if principal["role"] != "admin":
            raise HTTPException(403, "Admin role required")
        store.grant(name, case_id)
        event("team_access_granted", principal, case_id, recipient=name)
        return {"granted": True}

    @app.post("/cases/{case_id}/notes", status_code=201)
    def note(case_id: str, body: NoteInput, principal=Depends(current)):
        access(principal, case_id, True)
        store.note(case_id, body.text)
        event("team_note_added", principal, case_id)
        return {"saved": True}

    @app.post("/cases/{case_id}/reviews", status_code=201)
    def review(case_id: str, body: ReviewInput, principal=Depends(current)):
        access(principal, case_id, True)
        store.review(case_id, body.finding_id, body.decision, body.reason)
        event("team_review_added", principal, case_id, finding_id=body.finding_id, decision=body.decision)
        return {"saved": True}

    @app.get("/cases/{case_id}/jobs")
    def jobs(case_id: str, principal=Depends(current)):
        access(principal, case_id)
        return store.jobs(case_id)

    @app.get("/cases/{case_id}/analysis")
    def analysis(case_id: str, principal=Depends(current)):
        from .analysis import analyze_case
        access(principal, case_id)
        return analyze_case(state, case_id)

    @app.get("/cases/{case_id}/search")
    def search(case_id: str, text: str, source: str = "", review: str = "", limit: int = 100, principal=Depends(current)):
        from .analysis import search_evidence
        access(principal, case_id)
        return search_evidence(state, case_id, text, source=source, review=review, limit=limit)

    @app.get("/cases/{case_id}/path")
    def path(case_id: str, start: str, end: str, principal=Depends(current)):
        from .analysis import evidence_path
        access(principal, case_id)
        return evidence_path(state, case_id, start, end)

    @app.post("/cases/{case_id}/jobs", status_code=202)
    def enqueue(case_id: str, body: JobInput, principal=Depends(current)):
        access(principal, case_id, True)
        if set(body.sources) - allowed_sources:
            raise HTTPException(403, "Source is outside this server's allowlist")
        identifier = store.enqueue(case_id, body.context, body.sources, repeat=body.repeat,
            interval_seconds=body.interval_seconds, actor=principal["name"])
        event("team_job_queued", principal, case_id, job_id=identifier)
        return store.job(identifier)

    @app.get("/jobs/{identifier}")
    def job(identifier: str, principal=Depends(current)):
        result = store.job(identifier)
        access(principal, result["case_id"])
        return result

    @app.post("/jobs/{identifier}/cancel")
    def cancel(identifier: str, principal=Depends(current)):
        result = store.job(identifier)
        access(principal, result["case_id"], True)
        store.cancel(identifier)
        event("team_job_cancelled", principal, result["case_id"], job_id=identifier)
        return {"cancelled": True}

    return app
