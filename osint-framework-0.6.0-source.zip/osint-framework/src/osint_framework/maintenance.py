"""Explicit case retention planning and database deletion for local administrators."""

from datetime import datetime, timedelta, timezone

from .core.audit import AuditLog
from .team import TeamStore


def retention_plan(state, days):
    if type(days) is not int or not 1 <= days <= 36500:
        raise ValueError("Retention days must be between 1 and 36500")
    store = TeamStore(state)
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    with store.connect() as db:
        rows = db.execute("SELECT cases.id,cases.created_at,MAX(reports.saved_at) AS latest FROM cases LEFT JOIN reports ON cases.id=reports.case_id GROUP BY cases.id").fetchall()
    eligible = []
    for row in rows:
        last = row["latest"] or row["created_at"]
        if datetime.fromisoformat(last) < cutoff:
            eligible.append({"case_id": row["id"], "last_saved_at": last})
    return {"older_than_days": days, "candidates": eligible,
            "note": "Read-only plan. A recent note/review is not a new report; review candidates before deleting. Exported files and backups require separate retention."}


def delete_case_records(state, case_id, confirmation):
    if confirmation != case_id:
        raise ValueError("Supply the exact case ID again with --confirm-case-id")
    store = TeamStore(state)
    store.get(case_id)
    audit = AuditLog(state)
    audit.append("case_deletion_requested", {"case_id": case_id})
    with store.connect() as db:
        db.execute("BEGIN IMMEDIATE")
        if db.execute("SELECT 1 FROM jobs WHERE case_id=? AND status IN ('running','queued')", (case_id,)).fetchone():
            raise ValueError("Cancel queued jobs and wait for active workers before deleting this case")
        for table in ("jobs", "case_access", "reviews", "notes", "reports"):
            db.execute(f"DELETE FROM {table} WHERE case_id=?", (case_id,))
        db.execute("DELETE FROM cases WHERE id=?", (case_id,))
    audit.append("case_records_deleted", {"case_id": case_id})
    return {"deleted_case_id": case_id, "note": "Database records deleted. Original files, exported reports, audit records, database free pages and backups remain; this is not secure erasure."}
