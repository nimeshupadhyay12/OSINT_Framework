"""Deterministic evidence comparison and explainable paths; no generated identity claims."""

from collections import defaultdict

import networkx as nx

from .core.cases import CaseStore
from .core.correlator import correlate


def search_evidence(state, case_id, text, *, source="", review="", limit=100):
    if not 1 <= len(text.strip()) <= 200 or not 1 <= limit <= 500 or review not in {"", "accepted", "rejected", "unreviewed"}:
        raise ValueError("Provide 1–200 search characters, limit 1–500 and a valid review filter")
    selected = []
    needle = text.casefold()
    for row in CaseStore(state).evidence(case_id):
        finding = row["finding"]
        if source and finding.source != source or review and row["review"]["decision"] != review:
            continue
        if needle not in " ".join((finding.subject.value, finding.object.value, finding.relation, finding.evidence_url)).casefold():
            continue
        selected.append({"finding_id": finding.id, "finding": finding.model_dump(mode="json"), "review": row["review"]})
        if len(selected) > limit:
            break
    return {"matches": selected[:limit], "truncated": len(selected) > limit, "method": "Literal case-insensitive evidence search; no inferred identity merging."}


def analyze_case(state, case_id):
    store = CaseStore(state)
    reports = store.reports(case_id)
    rows = store.evidence(case_id)
    by_query, relations, origins = defaultdict(list), defaultdict(list), defaultdict(set)
    for report in reports:
        by_query[(report.context.input_type, report.context.query)].append(report)
    for row in rows:
        finding = row["finding"]
        key = (finding.subject.kind, finding.subject.value, finding.relation)
        relations[key].append(finding)
        for origin in row["origins"]:
            origins[origin].add(finding.id)
    comparisons = []
    for (kind, query), versions in by_query.items():
        if len(versions) < 2:
            continue
        before, after = versions[-2:]
        same_bounds = all(getattr(before.context, field) == getattr(after.context, field)
                          for field in ("allowed_hosts", "seed_urls", "max_pages", "max_requests", "max_findings"))
        old = {result.module: result for result in before.results}
        new = {result.module: result for result in after.results}
        for source in sorted(old.keys() & new.keys()):
            left, right = old[source], new[source]
            # Failed/partial source output cannot establish disappearance.
            comparable = same_bounds and left.status in {"ok", "empty"} and right.status in {"ok", "empty"} and not left.truncated and not right.truncated
            a, b = {f.id for f in left.findings}, {f.id for f in right.findings}
            comparisons.append({"type": kind, "query": query, "source": source, "previous_run": before.run_id,
                "latest_run": after.run_id, "comparable": comparable,
                "added_evidence_ids": sorted(b - a) if comparable else [],
                "not_returned_evidence_ids": sorted(a - b) if comparable else [],
                "note": "Not returned in the latest bounded lookup does not prove removal." if comparable else "Source failures, truncation or changed scope/budgets prevent an absence comparison."})
    return {"case": store.get(case_id), "runs": len(reports), "unique_evidence": len(rows),
        "timeline": [{"finding_id": r["finding"].id, "first": r["first_seen"].isoformat(), "last": r["last_seen"].isoformat(),
                      "timestamp_kind": r["finding"].metadata.get("timestamp_kind", "unspecified"),
                      "review": r["review"]["decision"], "content_changed": r["changed"]} for r in rows],
        "source_overlap": [{"origin": origin, "evidence_ids": sorted(ids)} for origin, ids in sorted(origins.items())],
        "multiple_observed_values": [{"subject_type": key[0], "subject": key[1], "relation": key[2],
            "values": sorted({f.object.value for f in values}), "evidence_ids": sorted({f.id for f in values}),
            "interpretation": "Multiple values may be valid; analyst review is required before calling them contradictory."}
            for key, values in relations.items() if len({f.object.id for f in values}) > 1],
        "comparisons": comparisons, "method": "Deterministic comparisons with cited evidence IDs. No probability or ownership inference."}


def evidence_path(state, case_id, start_id, end_id):
    rows = CaseStore(state).evidence(case_id)
    findings = [row["finding"] for row in rows if row["review"]["decision"] != "rejected"]
    data = correlate(findings)
    nodes = {node["id"]: node for node in data["nodes"]}
    graph = nx.Graph()
    graph.add_nodes_from(nodes)
    for edge in data["edges"]:
        graph.add_edge(edge["source"], edge["target"])
    if start_id not in nodes or end_id not in nodes:
        raise ValueError("Both entity IDs must occur in this case's non-rejected evidence")
    if not nx.has_path(graph, start_id, end_id):
        return {"nodes": [], "steps": [], "method": "No evidence path in the selected case"}
    path = nx.shortest_path(graph, start_id, end_id)
    steps = []
    for left, right in zip(path, path[1:]):
        edges = [edge for edge in data["edges"] if {edge["source"], edge["target"]} == {left, right}]
        steps.append({"from": left, "to": right, "claims": edges})
    return {"nodes": [nodes[key] for key in path], "steps": steps,
            "method": "Shortest undirected evidence path; original claim direction is preserved in each step. This is not proof of shared identity."}
