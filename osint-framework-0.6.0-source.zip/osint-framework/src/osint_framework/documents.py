"""Local, scoped document mentions with hash provenance and a bounded extraction process."""

import asyncio
import hashlib
import json
import os
import re
import sys
from pathlib import Path

from .core.audit import AuditLog
from .core.cases import CaseStore
from .core.engine import Engine
from .core.schema import Entity, Finding, ModuleResult, utcnow
from .core.vault import Vault
from .phone import phone_matches
from .workflow import save_outcome

EMAIL = re.compile(r"(?<![\w.+-])[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+(?![\w-]|\.[A-Za-z0-9])")


def document_bytes(path):
    if not path.is_file():
        raise ValueError("Document must be a regular file of at most 10 MB")
    with path.open("rb") as stream:
        body = stream.read(10_000_001)
    if len(body) > 10_000_000:
        raise ValueError("Document must be a regular file of at most 10 MB")
    return body


async def extract_document(path, language="eng", cancel_event=None):
    path = Path(path).resolve()
    if not path.is_file() or path.stat().st_size > 10_000_000:
        raise ValueError("Document must be a regular file of at most 10 MB")
    environment = {key: value for key, value in os.environ.items()
                   if key.upper() in {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "TESSDATA_PREFIX"}}
    flags = {"creationflags": 0x08000000} if os.name == "nt" else {}
    process = await asyncio.create_subprocess_exec(sys.executable, "-m", "osint_framework.document_extract",
                  str(path), language, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                  env=environment, **flags)

    async def bounded(stream, limit):
        output = bytearray()
        while chunk := await stream.read(65536):
            output.extend(chunk)
            if len(output) > limit:
                raise ValueError("Extractor output exceeded its size limit")
        return bytes(output)

    task = asyncio.gather(bounded(process.stdout, 2_000_000), bounded(process.stderr, 65536))
    try:
        async with asyncio.timeout(40):
            while not task.done():
                if cancel_event and cancel_event.is_set():
                    raise ValueError("Document extraction cancelled")
                await asyncio.wait([task], timeout=0.1)
            output, _ = await task
            code = await process.wait()
        data = json.loads(output)
        if code != 0 or not isinstance(data, list):
            raise ValueError("Document extraction failed. Check the format and documents extra; image OCR also needs Tesseract.")
        return data
    finally:
        if process.returncode is None:
            process.kill()
            await process.wait()
        if not task.done():
            task.cancel()
        await asyncio.gather(task, return_exceptions=True)


async def import_document(context, file, state, out, *, case_id=None, language="eng", cancel_event=None):
    file = Path(file)
    if case_id:
        CaseStore(state).get(case_id)
    engine = Engine(AuditLog(Path(state)))
    run_id = engine.start(context, ["document"])
    try:
        raw = document_bytes(file)
        digest = hashlib.sha256(raw).hexdigest()
        pages = await extract_document(file, language, cancel_event)
        if hashlib.sha256(document_bytes(file)).hexdigest() != digest:
            raise ValueError("Document changed during extraction; import stopped")
        findings, seen = [], set()
        for page in pages:
            text = page["text"]
            if context.input_type == "phone":
                positions = [(match["start"], match["end"]) for match in phone_matches(text, context.query)]
            else:
                positions = [(match.start(), match.end()) for match in re.finditer(
                    r"(?<![\w])" + re.escape(context.query) + r"(?![\w])", text, re.IGNORECASE)]
            for start, end in positions[:100]:
                excerpt = text[max(0, start - 300):end + 300]
                objects = [context.entity]
                objects.extend(Entity(kind="email", value=match.group()) for match in EMAIL.finditer(excerpt))
                for obj in dict.fromkeys(objects):
                    finding = Finding(source="document", subject=context.entity, object=obj,
                        relation="document_mentions" if obj == context.entity else "nearby_document_mention",
                        confidence="tentative", evidence_url="urn:sha256:" + digest,
                        legal_basis="Operator-supplied local document; the file's claims are not independently verified.",
                        metadata={"import_file": file.name, "import_sha256": digest,
                                  "timestamp_kind": "imported_at", "imported_at": utcnow().isoformat(),
                                  "location": page["location"], "excerpt": excerpt,
                                  "content_sha256": hashlib.sha256(text.encode()).hexdigest(),
                                  "ownership_verified": False, "ocr_language": language})
                    if finding.id not in seen:
                        seen.add(finding.id)
                        findings.append(finding)
                    if len(findings) > context.max_findings:
                        break
                if len(findings) > context.max_findings:
                    break
            if len(findings) > context.max_findings:
                break
        snapshot_dir = Path(out) / "evidence"
        snapshot_dir.mkdir(parents=True, exist_ok=True)
        vault = Vault(state)
        snapshot = snapshot_dir / (digest + (".bin.enc" if vault.enabled else ".bin"))
        vault.write_bytes(snapshot, raw)
        report = engine.finish(run_id, context, [ModuleResult(module="document", status="ok" if findings else "empty",
            findings=findings[:context.max_findings], truncated=len(findings) > context.max_findings,
            message="Local document mentions; no network request. Nearby text does not establish ownership.")])
        report.artifacts = [{"schema_version": 1, "url": "urn:sha256:" + digest,
            "captured_at": utcnow().isoformat(), "sha256": digest, "path": str(snapshot.resolve()),
            "bytes": len(raw), "original_name": file.name, "encrypted": vault.enabled}]
        return save_outcome(report, state, out, case_id)
    except BaseException:
        engine.audit.append("run_aborted", {"run_id": run_id})
        raise
