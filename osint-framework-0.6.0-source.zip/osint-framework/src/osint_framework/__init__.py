"""OSINT Correlation Framework."""

__version__ = "0.6.0"
