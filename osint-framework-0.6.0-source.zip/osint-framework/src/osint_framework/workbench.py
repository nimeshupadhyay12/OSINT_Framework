"""Native investigation workspace for all identifiers, saved cases, and source setup."""

import asyncio
import json
import math
import threading
import uuid
from pathlib import Path

from PySide6.QtCore import Qt, QThread, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QPen
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGraphicsEllipseItem,
    QGraphicsScene,
    QGraphicsSimpleTextItem,
    QGraphicsView,
    QHBoxLayout,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .catalog import IMPORT_CONTRACTS, free_selection, inventory, modules
from .core.audit import AuditLog
from .core.cases import CaseStore
from .core.correlator import correlate
from .core.credentials import KEY_NAMES, load_secrets, save_secret
from .core.schema import Entity, Finding, ModuleResult, QueryContext, RunReport, normalize
from .desktop import POLICY_TEXT, STYLE, PhoneWindow, label, synthetic_outcome, table
from .documents import import_document
from .integrations.stix_exchange import export_stix
from .jobs import JobStore, work_once
from .report import write_report
from .research import research, source_plan
from .workflow import Outcome, detect_type, import_report, investigate, make_context, save_outcome


def synthetic_case(state, out):
    store = CaseStore(state)
    case_id = store.create("Synthetic example investigation")
    phone = synthetic_outcome(Path(out))
    store.add(case_id, phone.report)
    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic case demonstration", authorized=True)
    findings = [Finding(source="synthetic_fixture", subject=context.entity,
                relation="publishes_email", object=Entity(kind="email", value="hello@example.org"),
                evidence_url="https://example.org/contact", confidence="tentative",
                legal_basis="Synthetic fixture; no collection", metadata={"synthetic": True,
                "excerpt": "Fictional company contact: hello@example.org"}),
                Finding(source="synthetic_fixture", subject=context.entity, relation="has_subdomain",
                object=Entity(kind="domain", value="www.example.org"), evidence_url="https://example.org/",
                legal_basis="Synthetic fixture; no collection", metadata={"synthetic": True})]
    report = RunReport(run_id="synthetic-case-" + uuid.uuid4().hex[:10], context=context,
                       results=[ModuleResult(module="synthetic_fixture", status="ok", findings=findings)],
                       graph=correlate(findings), notes=["SYNTHETIC DEMO: invented observations; no provider queried."])
    return save_outcome(report, state, out, case_id)


class InvestigationWorker(QThread):
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, *, mode, context, source_names, file, tool, state, out, case_id, secrets, language="eng", parent=None):
        super().__init__(parent)
        self.mode, self.context, self.source_names = mode, context, source_names
        self.file, self.tool, self.state, self.out, self.case_id = file, tool, state, out, case_id
        self.secrets, self.language = dict(secrets), language
        self.cancel_event = threading.Event()

    def run(self):
        try:
            if self.mode == "demo":
                outcome = synthetic_case(self.state, self.out)
            elif self.mode == "collection":
                outcome = asyncio.run(investigate(self.context, self.source_names, self.state, self.out,
                    case_id=self.case_id, secrets=self.secrets, cancel_event=self.cancel_event))
            elif self.mode in {"research", "deep_research"}:
                outcome = asyncio.run(research(self.context, self.state, self.out, case_id=self.case_id,
                    secrets=self.secrets, cancel_event=self.cancel_event, max_pivots=3 if self.mode == "deep_research" else 0))
            elif self.mode == "import":
                outcome = asyncio.run(import_report(self.context, self.tool, self.file, self.state, self.out, case_id=self.case_id))
            elif self.mode == "queue":
                job = asyncio.run(work_once(self.state, self.out, stop_event=self.cancel_event))
                if not job or not job.get("run_id"):
                    self.failed.emit("No completed run: queue is empty, not due, or the job failed. Review the Jobs tab.")
                    return
                report = next(r for r in CaseStore(self.state).reports(job["case_id"]) if r.run_id == job["run_id"])
                outcome = Outcome(report, {}, job["case_id"])
            else:
                outcome = asyncio.run(import_document(self.context, self.file, self.state, self.out, case_id=self.case_id,
                                                       language=self.language, cancel_event=self.cancel_event))
            self.completed.emit(outcome)
        except Exception as exc:
            # Imported records and provider errors can contain credentials or raw personal data.
            self.failed.emit(f"The run stopped ({type(exc).__name__}). Check the selected input, source requirements, "
                             "export contract and file limits. Completed earlier runs remain in the case.")
        finally:
            self.secrets.clear()


class EvidenceGraph(QGraphicsView):
    selected = Signal(str, str)

    def __init__(self):
        super().__init__()
        self.setScene(QGraphicsScene(self))
        self.setMinimumHeight(220)
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.scene().selectionChanged.connect(self._selected)

    def display(self, graph):
        self.scene().clear()
        nodes = graph.get("nodes", [])[:200]
        positions = {}
        for index, node in enumerate(nodes):
            angle = 2 * math.pi * index / max(1, len(nodes))
            radius = 180 + (index // 20) * 75
            positions[node["id"]] = (math.cos(angle) * radius, math.sin(angle) * radius)
        for edge in graph.get("edges", [])[:1500]:
            if edge["source"] in positions and edge["target"] in positions:
                start, end = positions[edge["source"]], positions[edge["target"]]
                item = self.scene().addLine(*start, *end, QPen(QColor("#486878"), 1.5))
                item.setToolTip(edge.get("relation", "") + " · " + edge.get("confidence", ""))
                item.setZValue(-1)
        for node in nodes:
            x, y = positions[node["id"]]
            item = QGraphicsEllipseItem(-7, -7, 14, 14)
            item.setPos(x, y)
            item.setBrush(QColor("#79d9bd"))
            item.setPen(QPen(QColor("#79d9bd")))
            item.setFlag(QGraphicsEllipseItem.GraphicsItemFlag.ItemIsSelectable)
            item.setData(0, node["kind"])
            item.setData(1, node["value"])
            item.setToolTip(node["kind"] + ": " + node["value"])
            self.scene().addItem(item)
            text = QGraphicsSimpleTextItem(node["value"][:35], item)
            text.setBrush(QColor("#e5edf4"))
            text.setPos(12, -9)
        self.resetTransform()
        self.fitInView(self.scene().itemsBoundingRect().adjusted(-30, -30, 30, 30), Qt.AspectRatioMode.KeepAspectRatio)

    def _selected(self):
        items = self.scene().selectedItems()
        if items:
            self.selected.emit(items[0].data(0), items[0].data(1))

    def wheelEvent(self, event):  # noqa: N802
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        if 0.03 < self.transform().m11() * factor < 12:
            self.scale(factor, factor)


class WorkbenchWindow(QMainWindow):
    def __init__(self, state_dir, out_dir):
        super().__init__()
        self.state_dir, self.out_dir = Path(state_dir), Path(out_dir)
        self.store = CaseStore(self.state_dir)
        self.secrets, self._job, self._outcome = {}, None, None
        self._shown, self._closing, self._graph_entity = [], False, None
        self.setWindowTitle("OSINT Framework · Investigation workbench")
        self.resize(1280, 950)
        self.setMinimumSize(1050, 750)
        self.setStyleSheet(STYLE)
        root, layout = QWidget(), QVBoxLayout()
        root.setLayout(layout)
        self.setCentralWidget(root)
        layout.setContentsMargins(22, 16, 22, 16)
        layout.addWidget(label("OSINT CORRELATION FRAMEWORK / VERSION 0.6", "eyebrow"))
        layout.addWidget(label("Investigation workbench", "title"))
        layout.addWidget(label("Collect evidence, connect identifiers, and keep an explainable case history.", "muted"))
        self.storage_label = label("Encrypted workspace · automatic evidence is encrypted; report and STIX exports create plaintext files."
            if self.store.vault.enabled else "Local workspace · evidence is stored as plaintext. Use osint vault init for a new encrypted workspace.", "muted")
        layout.addWidget(self.storage_label)
        casebar = QHBoxLayout()
        self.case_combo, self.case_title = QComboBox(), QLineEdit()
        self.case_title.setPlaceholderText("Title for a new case")
        create = QPushButton("Create case")
        create.clicked.connect(self._create_case)
        casebar.addWidget(label("Case", wrap=False))
        casebar.addWidget(self.case_combo, 2)
        casebar.addWidget(self.case_title, 2)
        casebar.addWidget(create)
        layout.addLayout(casebar)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._investigation_tab(), "Investigate")
        self.tabs.addTab(self._case_tab(), "Case evidence and graph")
        self.tabs.addTab(self._sources_tab(), "Sources and credentials")
        self.tabs.addTab(self._jobs_tab(), "Jobs and schedules")
        layout.addWidget(self.tabs, 1)
        self.progress = QProgressBar()
        self.progress.hide()
        layout.addWidget(self.progress)
        self.message = label("Ready. Source readiness checks do not contact providers.", "muted")
        layout.addWidget(self.message)
        self.case_combo.currentIndexChanged.connect(self._refresh_case)
        self._refresh_cases()
        self._refresh_sources()

    def _investigation_tab(self):
        scroll, form = QScrollArea(), QWidget()
        self.investigation_scroll = scroll
        scroll.setWidgetResizable(True)
        scroll.setWidget(form)
        self.query_form = form
        layout = QVBoxLayout(form)
        row = QHBoxLayout()
        self.query_input, self.type_combo, self.region_input = QLineEdit(), QComboBox(), QLineEdit()
        self.query_input.setPlaceholderText("Phone, email, username, domain, IP, URL or name")
        self.type_combo.addItems(["auto", "phone", "email", "username", "domain", "ip", "url", "name"])
        self.region_input.setPlaceholderText("Phone country: IN, US…")
        self.region_input.setMaximumWidth(185)
        row.addWidget(self.query_input, 3)
        row.addWidget(self.type_combo)
        row.addWidget(self.region_input)
        layout.addLayout(row)
        self.detected_label = label("Auto detection is a suggestion; choose the type to correct it.", "muted")
        layout.addWidget(self.detected_label)
        self.purpose_input = QLineEdit()
        self.purpose_input.setPlaceholderText("Purpose or engagement ID (at least 8 characters)")
        layout.addWidget(label("Purpose — required, at least 8 characters", "muted"))
        layout.addWidget(self.purpose_input)
        choices = QHBoxLayout()
        self.mode_combo, self.import_combo = QComboBox(), QComboBox()
        self.mode_combo.addItem("Collect from selected sources", "collection")
        self.mode_combo.addItem("Import a tool export", "import")
        self.mode_combo.addItem("Extract a local document", "document")
        self.mode_combo.addItem("Guided broad research — all ready sources", "research")
        self.mode_combo.addItem("Deep domain research — up to 3 subdomain pivots", "deep_research")
        self.import_combo.addItems(list(IMPORT_CONTRACTS))
        choices.addWidget(self.mode_combo)
        choices.addWidget(self.import_combo)
        self.language_input = QLineEdit("eng")
        self.language_input.setPlaceholderText("OCR languages, e.g. eng+hin")
        choices.addWidget(self.language_input)
        layout.addLayout(choices)
        file_row = QHBoxLayout()
        self.file_input = QLineEdit()
        self.file_input.setPlaceholderText("Local export or document path")
        browse = QPushButton("Browse")
        self.browse_button = browse
        browse.clicked.connect(self._browse)
        file_row.addWidget(self.file_input, 1)
        file_row.addWidget(browse)
        layout.addLayout(file_row)
        self.contract_label = label("", "muted")
        layout.addWidget(self.contract_label)
        self.source_list = QListWidget()
        self.source_list.setMinimumHeight(155)
        self.source_list.setMaximumHeight(235)
        layout.addWidget(self.source_list)
        select_free = QPushButton("Select compatible sources without API keys")
        self.select_free_button = select_free
        select_free.clicked.connect(self._select_free)
        layout.addWidget(select_free)
        select_ready = QPushButton("Select all compatible ready sources")
        self.select_ready_button = select_ready
        select_ready.clicked.connect(lambda: self._select_free(broad=True))
        layout.addWidget(select_ready)
        scope = QFormLayout()
        self.hosts_input, self.terms_input, self.pages_input = QLineEdit(), QLineEdit(), QLineEdit()
        self.hosts_input.setPlaceholderText("Exact permitted hostnames, separated by commas")
        self.terms_input.setPlaceholderText("Reviewed collection permission URL")
        self.pages_input.setPlaceholderText("Exact page URLs for phone evidence, separated by commas")
        scope.addRow("Page scope", self.hosts_input)
        scope.addRow("Permission", self.terms_input)
        scope.addRow("Phone pages", self.pages_input)
        layout.addLayout(scope)
        limits = QHBoxLayout()
        self.max_pages, self.max_requests = QSpinBox(), QSpinBox()
        self.max_pages.setRange(1, 20)
        self.max_pages.setValue(3)
        self.max_requests.setRange(1, 200)
        self.max_requests.setValue(50)
        limits.addWidget(label("Max pages", wrap=False))
        limits.addWidget(self.max_pages)
        limits.addWidget(label("HTTP request budget", wrap=False))
        limits.addWidget(self.max_requests)
        self.snapshot_check = QCheckBox("Preserve fetched page evidence locally")
        self.snapshot_check.setChecked(True)
        limits.addWidget(self.snapshot_check)
        limits.addStretch()
        layout.addLayout(limits)
        self.authorized_check = QCheckBox("This investigation is authorized; I accept the policy below.")
        layout.addWidget(self.authorized_check)
        layout.addWidget(label(POLICY_TEXT, "muted"))
        buttons = QHBoxLayout()
        self.run_button, self.demo_button = QPushButton("Run investigation"), QPushButton("Try synthetic case")
        self.run_button.setObjectName("primary")
        self.run_button.clicked.connect(self._submit)
        self.demo_button.clicked.connect(self._demo)
        buttons.addWidget(self.run_button)
        buttons.addWidget(self.demo_button)
        layout.addLayout(buttons)
        self.query_input.textChanged.connect(self._refresh_sources)
        self.type_combo.currentIndexChanged.connect(self._refresh_sources)
        for field in (self.hosts_input, self.terms_input, self.pages_input, self.region_input):
            field.textChanged.connect(self._sync_guided_selection)
        self.mode_combo.currentIndexChanged.connect(self._mode_changed)
        self.import_combo.currentIndexChanged.connect(self._mode_changed)
        self._mode_changed()
        return scroll

    def _case_tab(self):
        root, layout = QWidget(), QVBoxLayout()
        root.setLayout(layout)
        actions = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Filter evidence by identifier, source, date, or review decision")
        self.filter_input.textChanged.connect(self._refresh_case)
        actions.addWidget(self.filter_input, 1)
        for title, handler in (("Open case report", self._export_case), ("Export STIX", self._export_stix), ("Analyze evidence", self._analyze),
                               ("Stop current run", self._cancel)):
            button = QPushButton(title)
            button.clicked.connect(handler)
            actions.addWidget(button)
        layout.addLayout(actions)
        self.case_stats = label("No evidence saved yet.", "muted")
        layout.addWidget(self.case_stats)
        split = QSplitter(Qt.Orientation.Vertical)
        self.graph = EvidenceGraph()
        self.graph.selected.connect(self._graph_selected)
        split.addWidget(self.graph)
        self.evidence_table = table(["SUBJECT", "RELATION", "OBSERVATION", "SOURCE", "REVIEW"])
        self.evidence_table.itemSelectionChanged.connect(self._inspect)
        split.addWidget(self.evidence_table)
        split.setSizes([260, 230])
        layout.addWidget(split, 1)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumHeight(175)
        layout.addWidget(self.details)
        reviewbar = QHBoxLayout()
        self.review_combo, self.review_reason = QComboBox(), QLineEdit()
        self.review_combo.addItems(["unreviewed", "accepted", "rejected"])
        self.review_reason.setPlaceholderText("Reason for your evidence review")
        save = QPushButton("Save review")
        save.clicked.connect(self._review)
        pivot = QPushButton("Use selected identifier")
        pivot.clicked.connect(self._pivot)
        source = QPushButton("Open evidence source")
        source.clicked.connect(self._open_source)
        for widget in (self.review_combo, self.review_reason, save, pivot, source):
            reviewbar.addWidget(widget)
        layout.addLayout(reviewbar)
        notes = QHBoxLayout()
        self.note_input = QLineEdit()
        self.note_input.setPlaceholderText("Add a case note; saved without changing source evidence")
        save_note = QPushButton("Save note")
        save_note.clicked.connect(self._note)
        notes.addWidget(self.note_input, 1)
        notes.addWidget(save_note)
        layout.addLayout(notes)
        self.run_combo = QComboBox()
        load = QPushButton("Load saved run for another lookup")
        load.clicked.connect(self._load_run)
        runs = QHBoxLayout()
        runs.addWidget(self.run_combo, 1)
        runs.addWidget(load)
        layout.addLayout(runs)
        return root

    def _sources_tab(self):
        root, layout = QWidget(), QVBoxLayout()
        root.setLayout(layout)
        layout.addWidget(label("Live collection, installed runners, and offline imports are listed separately. Readiness is a local setup check.", "muted"))
        self.catalog_table = table(["SOURCE", "MODE / ACCESS", "SETUP", "LAST SAVED OUTCOME"])
        layout.addWidget(self.catalog_table, 1)
        keys = QHBoxLayout()
        self.key_combo, self.key_value = QComboBox(), QLineEdit()
        self.key_combo.addItems(list(KEY_NAMES))
        self.key_value.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_value.setPlaceholderText("Credential value; hidden and excluded from reports")
        keys.addWidget(self.key_combo)
        keys.addWidget(self.key_value, 1)
        layout.addLayout(keys)
        self.persist_key = QCheckBox("Also save this credential in the operating system keychain")
        layout.addWidget(self.persist_key)
        actions = QHBoxLayout()
        for text, callback in (("Use credential", self._set_key), ("Load OS keychain", self._load_keys),
                               ("Clear session credentials", self._clear_keys), ("Refresh setup status", self._refresh_sources)):
            button = QPushButton(text)
            button.clicked.connect(callback)
            actions.addWidget(button)
        layout.addLayout(actions)
        layout.addWidget(label("Saved keys require an OS-backed keychain. Session keys are cleared when the window closes. Provider subscriptions remain separate.", "muted"))
        return root

    def _jobs_tab(self):
        root, layout = QWidget(), QVBoxLayout()
        root.setLayout(layout)
        layout.addWidget(label("Queue the authorized collection form, or create finite scheduled rechecks. A worker must be running for due jobs to execute.", "muted"))
        row = QHBoxLayout()
        self.repeat_count, self.interval_hours = QSpinBox(), QSpinBox()
        self.repeat_count.setRange(1, 100)
        self.interval_hours.setRange(1, 8760)
        self.interval_hours.setValue(24)
        row.addWidget(label("Total runs", wrap=False))
        row.addWidget(self.repeat_count)
        row.addWidget(label("Hours between runs", wrap=False))
        row.addWidget(self.interval_hours)
        for text, callback in (("Queue current form", self._enqueue), ("Process one due job", self._process_job),
                               ("Refresh jobs", self._refresh_jobs), ("Cancel selected schedule", self._cancel_job)):
            button = QPushButton(text)
            button.clicked.connect(callback)
            row.addWidget(button)
        layout.addLayout(row)
        self.jobs_table = table(["JOB", "CASE", "STATUS", "DUE", "RUNS LEFT"])
        layout.addWidget(self.jobs_table)
        layout.addWidget(label("Continuous worker: osint jobs worker --continuous. Team API: osint team serve. These services start only when you run them. Encrypted workspaces also require an unlocked worker process.", "muted"))
        self.queue_rows = []
        return root

    def _select_free(self, _checked=False, *, broad=False):
        def select():
            context = make_context(self.query_input.text(), self.type_combo.currentText(), "Source selection preview", True,
                region=self.region_input.text() or None, allowed_hosts=[x.strip() for x in self.hosts_input.text().split(",") if x.strip()],
                terms_url=self.terms_input.text().strip() or None, seed_urls=[x.strip() for x in self.pages_input.text().split(",") if x.strip()])
            selected = [row["source"] for row in source_plan(context, secrets=self.secrets) if row["selected"]] if broad else free_selection(context)
            for i in range(self.source_list.count()):
                item = self.source_list.item(i)
                item.setCheckState(Qt.CheckState.Checked if item.data(Qt.ItemDataRole.UserRole) in selected else Qt.CheckState.Unchecked)
            self.message.setText("Selected compatible ready sources." if broad else "Selected compatible no-key sources. Page collectors are included only when their scope fields are supplied.")
        self._guard(select)

    def _enqueue(self):
        def enqueue():
            if self._job or self.mode_combo.currentData() != "collection":
                raise ValueError("Queue supports idle collection mode; imports and document paths stay local")
            context, names = self.build_request()
            case_id = self.case_combo.currentData()
            if not case_id:
                raise ValueError("Create or select a case before queueing")
            AuditLog(self.state_dir).accept_policy()
            identifier = JobStore(self.state_dir).enqueue(case_id, context, names,
                repeat=self.repeat_count.value(), interval_seconds=self.interval_hours.value() * 3600)
            self.authorized_check.setChecked(False)
            self._refresh_jobs()
            self.message.setText("Queued " + identifier + ". Worker credentials come from its environment, not this window's session keys.")
        self._guard(enqueue)

    def _refresh_jobs(self):
        def refresh():
            from datetime import datetime, timezone
            self.queue_rows = JobStore(self.state_dir).jobs(self.case_combo.currentData())
            PhoneWindow._fill_table(self.jobs_table, [[row["id"], row["case_id"], row["status"],
                datetime.fromtimestamp(row["due"], timezone.utc).isoformat()[:19], str(row["remaining"])] for row in self.queue_rows])
        self._guard(refresh)

    def _cancel_job(self):
        index = self.jobs_table.currentRow()
        if 0 <= index < len(self.queue_rows):
            self._guard(lambda: JobStore(self.state_dir).cancel(self.queue_rows[index]["id"]))
            self._refresh_jobs()

    def _process_job(self):
        if not self._job:
            self._begin(InvestigationWorker(mode="queue", context=None, source_names=[], file="", tool="",
                state=self.state_dir, out=self.out_dir, case_id=None, secrets={}, parent=self))

    def _analyze(self):
        def analyze():
            from .analysis import analyze_case
            self.details.setPlainText(json.dumps(analyze_case(self.state_dir, self.case_combo.currentData()), indent=2))
        self._guard(analyze)

    def _mode_changed(self):
        mode = self.mode_combo.currentData()
        self.import_combo.setEnabled(mode == "import")
        self.import_combo.setVisible(mode == "import")
        self.file_input.setEnabled(mode in {"import", "document"})
        self.file_input.setVisible(mode in {"import", "document"})
        self.browse_button.setVisible(mode in {"import", "document"})
        self.language_input.setEnabled(mode == "document")
        self.language_input.setVisible(mode == "document")
        self.source_list.setEnabled(mode == "collection")
        self.select_free_button.setEnabled(mode == "collection")
        self.select_ready_button.setEnabled(mode == "collection")
        self.contract_label.setText(IMPORT_CONTRACTS[self.import_combo.currentText()] if mode == "import" else
            "Automatically selects ready public sources, uses one shared request budget, and reports coverage gaps. Deep mode adds at most 3 discovered subdomains; domain input required." if mode in {"research", "deep_research"} else
            "Local TXT/HTML/PDF/DOCX and image OCR. OCR needs installed Tesseract and language packs." if mode == "document" else
            "Choose sources below. Additional page collection needs exact host scope and a permission reference.")
        self._sync_guided_selection()

    def _sync_guided_selection(self, *_):
        if self.mode_combo.currentData() not in {"research", "deep_research"}:
            return
        try:
            context = make_context(self.query_input.text(), self.type_combo.currentText(), "Source selection preview", True,
                region=self.region_input.text() or None, allowed_hosts=[x.strip() for x in self.hosts_input.text().split(",") if x.strip()],
                terms_url=self.terms_input.text().strip() or None, seed_urls=[x.strip() for x in self.pages_input.text().split(",") if x.strip()])
            selected = {row["source"] for row in source_plan(context, secrets=self.secrets) if row["selected"]}
        except ValueError:
            selected = set()
        for index in range(self.source_list.count()):
            item = self.source_list.item(index)
            item.setCheckState(Qt.CheckState.Checked if item.data(Qt.ItemDataRole.UserRole) in selected else Qt.CheckState.Unchecked)

    def _refresh_sources(self, *_):
        if not hasattr(self, "source_list"):
            return
        kind = self.type_combo.currentText()
        if kind == "auto":
            kind = detect_type(self.query_input.text())
        self.detected_label.setText(f"Selected input type: {kind}. Auto detection is a suggestion; you can override it.")
        selected = {self.source_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.source_list.count())
                    if self.source_list.item(i).checkState() == Qt.CheckState.Checked}
        old_kind = getattr(self, "_source_kind", None)
        self._source_kind = kind
        self.source_list.clear()
        data = inventory(credentials=self.secrets, health=self.store.source_health())
        for item in data:
            if kind not in item["inputs"]:
                continue
            row = QListWidgetItem(f"{item['name']} · {item['setup']} · {item['description']}")
            row.setData(Qt.ItemDataRole.UserRole, item["name"])
            row.setFlags(row.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            default = modules()[item["name"]].spec.default_enabled
            row.setCheckState(Qt.CheckState.Checked if (item["name"] in selected if old_kind == kind else default) else Qt.CheckState.Unchecked)
            self.source_list.addItem(row)
        if hasattr(self, "catalog_table"):
            PhoneWindow._fill_table(self.catalog_table, [[row["name"], row["mode"] + " / " + row.get("access", "local"), row["setup"],
                ((row["last_run"]["status"] + " · " + row["last_run"]["at"][:19]) if row.get("last_run") else "not run in a saved case")]
                for row in data])
        self._sync_guided_selection()

    def _refresh_cases(self, selected=None):
        prior = selected or self.case_combo.currentData()
        self.case_combo.blockSignals(True)
        self.case_combo.clear()
        self.case_combo.addItem("Choose a case, or create one when running", None)
        for row in self.store.list():
            self.case_combo.addItem(f"{row['title']} · {row['runs']} runs", row["id"])
        index = self.case_combo.findData(prior)
        self.case_combo.setCurrentIndex(max(0, index))
        self.case_combo.blockSignals(False)
        self._refresh_case()

    def _create_case(self):
        self._guard(lambda: self._refresh_cases(self.store.create(self.case_title.text())))

    def _guard(self, operation):
        try:
            return operation()
        except (ValueError, OSError) as exc:
            self.message.setText(str(exc))
        except Exception as exc:
            self.message.setText(f"Operation failed ({type(exc).__name__}). Check local storage and installed extras.")

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose an authorized export or document")
        if path:
            self.file_input.setText(path)

    def build_request(self):
        if not self.authorized_check.isChecked():
            raise ValueError("Confirm authorization for this investigation before running")
        if len(self.purpose_input.text().strip()) < 8:
            self.tabs.setCurrentIndex(0)
            self.investigation_scroll.ensureWidgetVisible(self.purpose_input)
            self.purpose_input.setFocus()
            raise ValueError("Enter your investigation purpose above (at least 8 characters), for example: Authorized domain review.")
        context = make_context(self.query_input.text(), self.type_combo.currentText(), self.purpose_input.text(), True,
            region=self.region_input.text() or None, allowed_hosts=[x.strip() for x in self.hosts_input.text().split(",") if x.strip()],
            terms_url=self.terms_input.text().strip() or None, seed_urls=[x.strip() for x in self.pages_input.text().split(",") if x.strip()],
            max_pages=self.max_pages.value(), max_requests=self.max_requests.value(), preserve_pages=self.snapshot_check.isChecked())
        names = [self.source_list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.source_list.count())
                 if self.source_list.item(i).checkState() == Qt.CheckState.Checked]
        mode = self.mode_combo.currentData()
        if mode == "collection" and not names:
            raise ValueError("Select a source for this input type")
        if mode in {"import", "document"} and not Path(self.file_input.text()).is_file():
            raise ValueError("Choose an existing export or document file")
        if mode == "deep_research" and context.input_type != "domain":
            raise ValueError("Deep domain research requires a domain. Use guided broad research for other identifiers.")
        if mode == "collection" and set(names) & {"webpage", "scrapy_pages", "phone_pages"}:
            if not context.allowed_hosts or not context.terms_url:
                raise ValueError("Page collectors require exact permitted hosts and a permission reference")
        return context, names

    def _submit(self):
        if self._job:
            return
        def begin():
            context, names = self.build_request()
            audit = AuditLog(self.state_dir)
            if not audit.consented():
                audit.accept_policy()
            case_id = self.case_combo.currentData() or self.store.create(self.case_title.text().strip() or "Investigation: " + context.query)
            self._refresh_cases(case_id)
            self._begin(InvestigationWorker(mode=self.mode_combo.currentData(), context=context, source_names=names,
                file=self.file_input.text(), tool=self.import_combo.currentText(), state=self.state_dir, out=self.out_dir,
                case_id=case_id, secrets=self.secrets, language=self.language_input.text() or "eng", parent=self))
        self._guard(begin)

    def _demo(self):
        if not self._job:
            self._begin(InvestigationWorker(mode="demo", context=None, source_names=[], file="", tool="",
                state=self.state_dir, out=self.out_dir, case_id=None, secrets={}, parent=self))

    def _begin(self, worker):
        self._job = worker
        self.query_form.setEnabled(False)
        self.progress.setRange(0, 0)
        self.progress.show()
        self.message.setText("Investigation running. Source pacing applies; Stop current run is on the case tab.")
        worker.completed.connect(self._completed)
        worker.failed.connect(lambda message: self.message.setText(message))
        worker.finished.connect(self._finished)
        worker.start()

    def _completed(self, outcome):
        self._outcome = outcome
        self._refresh_cases(outcome.case_id)
        self._refresh_sources()
        self.tabs.setCurrentIndex(1)
        statuses = ", ".join(f"{r.module}: {r.status}" for r in outcome.report.results)
        self.message.setText("Saved to case. " + statuses)

    def _finished(self):
        job, self._job = self._job, None
        self.query_form.setEnabled(True)
        self.progress.hide()
        self._refresh_jobs()
        if job:
            job.deleteLater()
        if self._closing:
            self.close()

    def _cancel(self):
        if self._job:
            self._job.cancel_event.set()
            self.message.setText("Stopping pending source work; completed sources will be saved.")

    def _refresh_case(self, *_):
        if not hasattr(self, "evidence_table"):
            return
        case_id = self.case_combo.currentData()
        self._graph_entity = None
        self._shown = []
        self.run_combo.clear()
        self.evidence_table.setRowCount(0)
        self.details.clear()
        if not case_id:
            self.graph.display({})
            self.case_stats.setText("No case selected.")
            return
        try:
            reports = self.store.reports(case_id)
            rows = self.store.evidence(case_id)
        except (ValueError, OSError) as exc:
            self.case_stats.setText(str(exc))
            return
        for report in reports:
            self.run_combo.addItem(f"{report.created_at.isoformat()[:19]} · {report.context.input_type}: {report.context.query}", report)
        term = self.filter_input.text().casefold().strip()
        self._shown = [row for row in rows if not term or term in (row["finding"].model_dump_json() + json.dumps(row["review"])).casefold()][:5000]
        PhoneWindow._fill_table(self.evidence_table, [[r["finding"].subject.value, r["finding"].relation,
            r["finding"].object.value, r["finding"].source, r["review"]["decision"]] for r in self._shown])
        self.graph.display(correlate([row["finding"] for row in self._shown]))
        history = self.store.history(case_id)
        self.case_stats.setText(f"{len(reports)} runs · {len(rows)} unique evidence records · {len(self._shown)} shown · "
            f"{sum(row['changed'] for row in rows)} changed evidence records · {len(history['notes'])} notes. Graph preview: up to 200 entities.")

    def _selected_row(self):
        index = self.evidence_table.currentRow()
        return self._shown[index] if 0 <= index < len(self._shown) else None

    def _inspect(self):
        row = self._selected_row()
        if row:
            f = row["finding"]
            self._graph_entity = (f.object.kind, f.object.value)
            self.details.setPlainText(f"Evidence {f.id}\nConfidence: {f.confidence} · {row['review']['decision']}\n"
                f"First: {row['first_seen'].isoformat()}\nLast: {row['last_seen'].isoformat()}\n"
                f"Origins: {', '.join(row['origins'])}; repeated sightings do not establish independence.\n"
                f"Source: {f.evidence_url}\n\n" + json.dumps(f.metadata, ensure_ascii=False, indent=2))

    def _graph_selected(self, kind, value):
        self._graph_entity = (kind, value)
        self.details.setPlainText(f"Selected {kind}: {value}\nUse selected identifier copies this into the investigation form. No lookup runs automatically.")

    def _pivot(self):
        if self._graph_entity:
            kind, value = self._graph_entity
            if self.type_combo.findText(kind) < 0:
                self.message.setText("This entity type has no direct collection module")
                return
            self.type_combo.setCurrentText(kind)
            self.query_input.setText(value)
            self.mode_combo.setCurrentIndex(0)
            self.authorized_check.setChecked(False)
            self.tabs.setCurrentIndex(0)

    def _load_run(self):
        report = self.run_combo.currentData()
        if report:
            self.type_combo.setCurrentText(report.context.input_type)
            self.query_input.setText(report.context.query)
            self.purpose_input.setText(report.context.purpose)
            self.hosts_input.setText(", ".join(report.context.allowed_hosts))
            self.terms_input.setText(report.context.terms_url or "")
            self.pages_input.setText(", ".join(report.context.seed_urls))
            self.authorized_check.setChecked(False)
            self.mode_combo.setCurrentIndex(0)
            failed = {r.module for r in report.results if r.status in {"error", "rate_limited", "cancelled", "skipped"}}
            selected = failed or {r.module for r in report.results}
            for i in range(self.source_list.count()):
                row = self.source_list.item(i)
                row.setCheckState(Qt.CheckState.Checked if row.data(Qt.ItemDataRole.UserRole) in selected else Qt.CheckState.Unchecked)
            self.tabs.setCurrentIndex(0)

    def _review(self):
        row = self._selected_row()
        if row:
            def save():
                self.store.review(self.case_combo.currentData(), row["finding"].id, self.review_combo.currentText(), self.review_reason.text())
                self._refresh_case()
            self._guard(save)

    def _note(self):
        def save():
            self.store.note(self.case_combo.currentData(), self.note_input.text())
            self.note_input.clear()
            self._refresh_case()
        self._guard(save)

    def _open_source(self):
        row = self._selected_row()
        if row:
            url = row["finding"].evidence_url
            if url.startswith("urn:"):
                self.message.setText("This is local document evidence. Its file hash and exact location are shown in the evidence details.")
            else:
                self._guard(lambda: QDesktopServices.openUrl(QUrl(normalize("url", url))))

    def _export_case(self):
        def export():
            report = self.store.combined(self.case_combo.currentData())
            paths = write_report(report, self.out_dir / report.run_id)
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(paths["html"].resolve())))
        self._guard(export)

    def _export_stix(self):
        def export():
            report = self.store.combined(self.case_combo.currentData())
            payload = export_stix(report)
            directory = self.out_dir / report.run_id
            directory.mkdir(parents=True, exist_ok=True)
            path = directory / "opencti.stix.json"
            path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            self.message.setText("STIX bundle saved: " + str(path.resolve()))
        self._guard(export)

    def _set_key(self):
        def save():
            name, value = self.key_combo.currentText(), self.key_value.text().strip()
            if not value:
                raise ValueError("Enter a credential value")
            if self.persist_key.isChecked():
                save_secret(name, value)
            self.secrets[name] = value
            self.key_value.clear()
            self._refresh_sources()
            self.message.setText("Credential available for subsequent runs" + (" and saved in OS keychain." if self.persist_key.isChecked() else " in this session."))
        self._guard(save)

    def _load_keys(self):
        def load():
            self.secrets.update(load_secrets())
            self._refresh_sources()
            self.message.setText("Loaded available credentials from the OS keychain.")
        self._guard(load)

    def _clear_keys(self):
        self.secrets.clear()
        self.key_value.clear()
        self._refresh_sources()
        self.message.setText("Session credentials cleared. Stored OS-keychain entries are unchanged.")

    def closeEvent(self, event):  # noqa: N802
        if self._job:
            self._closing = True
            self._cancel()
            event.ignore()
            return
        self.secrets.clear()
        self.key_value.clear()
        event.accept()
