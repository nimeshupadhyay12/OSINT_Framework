"""Guided public-source research with transparent planning and bounded domain pivots."""

import hashlib
import uuid
from pathlib import Path
from urllib.parse import urlsplit

from .catalog import inventory, modules
from .core.audit import AuditLog
from .core.cases import CaseStore
from .core.correlator import correlate
from .core.credentials import credentials
from .core.engine import Engine
from .core.http import HttpClient
from .core.schema import Entity, RunReport, utcnow
from .core.vault import Vault
from .workflow import save_outcome


def source_plan(context, *, profile="broad", secrets=None):
    if profile not in {"quick", "broad"}:
        raise ValueError("Profile must be quick or broad")
    plan = []
    for row in inventory(credentials=secrets):
        if context.input_type not in row["inputs"]:
            continue
        reason = ""
        if row["mode"] == "external runner":
            reason = "External tools require explicit manual selection"
        elif row["setup"] != "ready":
            reason = row["setup"]
        elif profile == "quick" and row["access"] != "no_key":
            reason = "Quick profile uses no-key sources"
        elif row["scope_required"] and not (context.allowed_hosts and context.terms_url):
            reason = "Page collection needs exact hosts and a permission reference"
        elif row["name"] == "phone_pages" and not context.seed_urls:
            reason = "Phone pages need explicit page URLs"
        plan.append({"source": row["name"], "selected": not reason, "reason": reason,
                     "access": row["access"], "description": row["description"]})
    return plan


def domain_pivots(report, root, maximum):
    """One hop within the supplied domain; never expand person identifiers."""
    seen, candidates = {root}, []
    for result in report.results:
        for finding in result.findings:
            target = finding.object
            host = target.value if target.kind == "domain" else urlsplit(target.value).hostname if target.kind == "url" else None
            if host and host.endswith("." + root) and host not in seen:
                try:
                    entity = Entity(kind="domain", value=host)
                except ValueError:
                    continue
                seen.add(host)
                candidates.append(entity)
    return sorted(candidates, key=lambda entity: entity.value)[:maximum]


async def research(context, state, out, *, profile="broad", max_pivots=0, case_id=None,
                   secrets=None, cancel_event=None, http=None, available=None, plan=None):
    if type(max_pivots) is not int or not 0 <= max_pivots <= 5:
        raise ValueError("Choose 0–5 domain pivots")
    if max_pivots and context.input_type != "domain":
        raise ValueError("Automatic expansion supports domain queries only; review other identifiers manually")
    plan = source_plan(context, profile=profile, secrets=secrets) if plan is None else plan
    selected = [row["source"] for row in plan if row["selected"]]
    if not selected:
        raise ValueError("No sources are ready. Review Sources and credentials, or use an offline import.")
    available = modules() if available is None else available
    engine = Engine(AuditLog(Path(state)))
    if not engine.audit.consented():
        raise ValueError("Run osint init before research")
    store, vault = CaseStore(state), Vault(state)
    case_id = case_id or store.create("Research: " + context.query[:180])
    store.get(case_id)
    artifacts = []

    def snapshot(url, raw):
        digest = hashlib.sha256(raw).hexdigest()
        path = Path(out) / "evidence" / (digest + (".bin.enc" if vault.enabled else ".bin"))
        vault.write_bytes(path, raw)
        artifacts.append({"schema_version": 1, "url": url, "captured_at": utcnow().isoformat(), "sha256": digest,
                          "bytes": len(raw), "path": str(path.resolve()), "encrypted": vault.enabled})

    async def collect(client):
        reports = []
        root = await engine.run(context, [available[name] for name in selected], http=client, cancel_event=cancel_event)
        root.artifacts = list(artifacts)
        save_outcome(root, state, out, case_id)
        reports.append(root)
        for entity in domain_pivots(root, context.query, max_pivots) if max_pivots else []:
            if (cancel_event and cancel_event.is_set()) or getattr(client, "request_count", 0) >= context.max_requests:
                break
            # Reuse the same HTTP budget. Only public database/DNS lookups, no crawling.
            names = [name for name in ("dns", "rdap", "crtsh") if name in available
                     and "domain" in available[name].spec.input_types]
            if not names:
                break
            child = context.model_copy(update={"query": entity.value, "allowed_hosts": [], "seed_urls": [], "terms_url": None})
            report = await engine.run(child, [available[name] for name in names], http=client, cancel_event=cancel_event)
            save_outcome(report, state, out, case_id)
            reports.append(report)
        return reports

    with credentials(secrets):
        if http is not None:
            reports = await collect(http)
            requests = getattr(http, "request_count", None)
        else:
            async with HttpClient(engine.limiter, max_requests=context.max_requests,
                                  snapshot=snapshot if context.preserve_pages else None) as client:
                reports = await collect(client)
                requests = client.request_count
    results = [result.model_copy(update={"module": result.module if i == 0 else result.module + " / " + report.context.query})
               for i, report in enumerate(reports) for result in report.results]
    findings = [finding for result in results for finding in result.findings]
    report = RunReport(run_id="research-" + uuid.uuid4().hex, title="Research: " + context.query[:180], context=context,
        results=results, graph=correlate(findings), artifacts=artifacts,
        coverage={"profile": profile, "plan": plan, "queries": [r.context.query for r in reports],
                  "http_requests": requests, "http_budget": context.max_requests, "pivot_limit": max_pivots,
                  "entire_internet_searched": False, "identity_verified": False})
    skipped = [row["source"] + ": " + row["reason"] for row in plan if not row["selected"]]
    failures = [r.module + " (" + r.status + ")" for r in results if r.status not in {"ok", "empty"}]
    report.notes.extend([f"Research profile: {profile}. Queries: {len(reports)}. Shared HTTP budget: {context.max_requests}.",
        "Not searched: " + ("; ".join(skipped) or "No configured profile sources were excluded."),
        "Incomplete sources: " + (", ".join(failures) or "None reported a failure; provider result caps still apply."),
        "Public indexes cover only part of the web. Empty results do not establish absence; search hits do not prove identity."])
    return save_outcome(report, state, out, case_id)
