"""Isolated local text extractor. No network or document macros are executed."""

import json
import re
import sys
import zipfile
from pathlib import Path

MAX_BYTES = 10_000_000
MAX_TEXT = 200_000


def extract(path: Path, language="eng"):
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise ValueError("Document must be a regular file smaller than 10 MB")
    if not re.fullmatch(r"[a-zA-Z0-9_+]{1,60}", language):
        raise ValueError("Invalid OCR language selection")
    extension = path.suffix.lower()
    pages = []
    if extension == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(path)
        if reader.is_encrypted:
            raise ValueError("Encrypted PDF is unsupported")
        if len(reader.pages) > 50:
            raise ValueError("PDF exceeds the 50-page extraction limit")
        for index, page in enumerate(reader.pages):
            pages.append({"location": f"page {index + 1}", "text": page.extract_text() or ""})
    elif extension == ".docx":
        from docx import Document

        with zipfile.ZipFile(path) as archive:
            if sum(item.file_size for item in archive.infolist()) > 50_000_000:
                raise ValueError("Expanded document exceeds its size budget")
        document = Document(path)
        for index, paragraph in enumerate(document.paragraphs):
            pages.append({"location": f"paragraph {index + 1}", "text": paragraph.text})
        for index, table in enumerate(document.tables):
            pages.append({"location": f"table {index + 1}",
                          "text": "\n".join(" | ".join(cell.text for cell in row.cells) for row in table.rows)})
    elif extension in {".png", ".jpg", ".jpeg", ".tif", ".tiff"}:
        import pytesseract
        from PIL import Image

        Image.MAX_IMAGE_PIXELS = 20_000_000
        with Image.open(path) as picture:
            if picture.width * picture.height > 20_000_000:
                raise ValueError("Image exceeds the 20-megapixel OCR limit")
            pages.append({"location": "image OCR", "text": pytesseract.image_to_string(picture, lang=language, timeout=20)})
    elif extension in {".txt", ".md", ".html", ".htm"}:
        text = path.read_text(encoding="utf-8-sig")
        if extension in {".html", ".htm"}:
            from .phone import public_text

            text, _ = public_text(text)
        pages.append({"location": "document", "text": text})
    else:
        raise ValueError("Supported files: TXT, Markdown, HTML, PDF, DOCX, PNG, JPEG and TIFF")
    if sum(len(page["text"]) for page in pages) > MAX_TEXT:
        raise ValueError("Extracted text exceeds the 200000-character budget")
    return pages


if __name__ == "__main__":
    try:
        result = extract(Path(sys.argv[1]), sys.argv[2] if len(sys.argv) > 2 else "eng")
        print(json.dumps(result, ensure_ascii=True))
    except Exception as exc:
        print(json.dumps({"error": f"Extraction failed ({type(exc).__name__}). Check the format, limits and optional dependencies."}))
        raise SystemExit(1)
