"""Bounded concurrent orchestration with fail-closed auditing and isolated source failures."""

import asyncio
import time
import uuid

from .audit import AuditLog, query_fingerprint
from .correlator import correlate
from .credentials import get_secret
from .http import HttpClient, SourceError, SourceSkipped
from .ratelimit import RateLimited, RateLimiter
from .schema import Finding, ModuleResult, QueryContext, RunReport


class Engine:
    def __init__(self, audit: AuditLog):
        self.audit = audit
        self.limiter = RateLimiter(audit)

    def start(self, context: QueryContext, module_names: list[str]) -> str:
        if not self.audit.consented():
            raise ValueError("Run 'osint init' to read and accept the authorized-use policy")
        valid, _ = self.audit.verify()
        if not valid:
            raise ValueError("Audit chain verification failed; inspect the state database before continuing")
        run_id = str(uuid.uuid4())
        self.audit.append("run_started", {"run_id": run_id, "input_type": context.input_type,
                                         "query_sha256": query_fingerprint(context.input_type, context.query),
                                         "purpose": context.purpose, "authorized": True, "modules": module_names})
        return run_id

    def finish(self, run_id: str, context: QueryContext, results: list[ModuleResult]) -> RunReport:
        findings = [finding for result in results for finding in result.findings]
        report = RunReport(run_id=run_id, context=context, results=results, graph=correlate(findings))
        self.audit.append("run_finished", {"run_id": run_id, "findings": len(findings),
                                          "statuses": {r.module: r.status for r in results}})
        return report

    async def run(self, context: QueryContext, modules: list, http=None, *, cancel_event=None, snapshot=None) -> RunReport:
        if not modules:
            raise ValueError("No modules selected for this input type")
        run_id = self.start(context, [module.spec.name for module in modules])
        try:
            await self.limiter.acquire(f"queries:{context.input_type}", 10)
            if http is not None:
                results = await self._run_modules(context, modules, http, run_id, cancel_event)
            else:
                async with HttpClient(self.limiter, max_requests=context.max_requests, snapshot=snapshot) as client:
                    results = await self._run_modules(context, modules, client, run_id, cancel_event)
            return self.finish(run_id, context, results)
        except BaseException:
            self.audit.append("run_aborted", {"run_id": run_id})
            raise

    async def _run_modules(self, context, modules, http, run_id, cancel_event=None):
        semaphore = asyncio.Semaphore(4)

        async def run_one(module):
            spec = module.spec
            start = time.monotonic()
            result = ModuleResult(module=spec.name, status="skipped")
            if context.input_type not in spec.input_types:
                result.message = "Unsupported input type"
            elif any(not get_secret(key) for key in spec.key_env):
                result.message = "Missing environment variables: " + ", ".join(spec.key_env)
            else:
                async with semaphore:
                    try:
                        async with asyncio.timeout(240):
                            findings = await module.run(context, http)
                        if not isinstance(findings, list):
                            raise ValueError("Adapter must return a list of canonical findings")
                        result.truncated = len(findings) > context.max_findings
                        result.findings = [Finding.model_validate(finding) for finding in findings[:context.max_findings]]
                        result.status = "ok" if result.findings else "empty"
                        result.message = "No matching observations returned" if not result.findings else ""
                    except SourceSkipped as exc:
                        result.message = str(exc)
                    except RateLimited as exc:
                        result.status, result.message = "rate_limited", str(exc)
                    except SourceError as exc:
                        result.status, result.message = "error", str(exc)
                    except TimeoutError:
                        result.status, result.message = "error", "Source exceeded the 240-second time budget"
                    except Exception as exc:
                        result.status = "error"
                        result.message = f"Adapter failed ({type(exc).__name__}); no absence claim is made"
            result.elapsed_ms = int((time.monotonic() - start) * 1000)
            self.audit.append("module_finished", {"run_id": run_id, "module": spec.name,
                                                   "status": result.status, "findings": len(result.findings)})
            return result

        if cancel_event is None:
            return await asyncio.gather(*(run_one(module) for module in modules))

        async def cancellable(module):
            try:
                if cancel_event.is_set():
                    raise asyncio.CancelledError()
                return await run_one(module)
            except asyncio.CancelledError:
                if not cancel_event.is_set():
                    raise
                result = ModuleResult(module=module.spec.name, status="cancelled",
                                      message="Stopped by operator; completed sources remain available")
                self.audit.append("module_cancelled", {"run_id": run_id, "module": module.spec.name})
                return result

        tasks = [asyncio.create_task(cancellable(module)) for module in modules]
        await asyncio.sleep(0)
        pending = set(tasks)
        try:
            while pending:
                if cancel_event.is_set():
                    for task in pending:
                        task.cancel()
                    break
                _, pending = await asyncio.wait(pending, timeout=0.1, return_when=asyncio.FIRST_COMPLETED)
            return await asyncio.gather(*tasks)
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
