"""Versioned evidence contract. Confidence describes a claim, never a person's identity."""

import hashlib
import ipaddress
import json
import re
from datetime import datetime, timezone
from typing import Any, Literal, Protocol
from urllib.parse import urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

InputType = Literal["username", "email", "phone", "domain", "ip", "url", "name"]
EntityType = Literal["username", "email", "phone", "domain", "ip", "url", "name", "profile", "breach", "organization", "record"]
Confidence = Literal["certain", "likely", "tentative"]


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def normalize(kind: str, value: str) -> str:
    value = value.strip()
    if not value or len(value) > 2048 or any(ord(c) < 32 for c in value):
        raise ValueError("Identifiers must contain 1–2048 printable characters")
    if kind == "domain":
        value = value.rstrip(".").encode("idna").decode("ascii").lower()
        if len(value) > 253 or "." not in value or any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", p) for p in value.split(".")):
            raise ValueError("Expected a fully qualified domain, without a URL or wildcard")
        try:
            ipaddress.ip_address(value)
        except ValueError:
            return value
        raise ValueError("Use type ip for IP addresses")
    if kind == "ip":
        return str(ipaddress.ip_address(value))
    if kind == "email":
        if value.count("@") != 1 or any(c.isspace() for c in value):
            raise ValueError("Expected an email address")
        local, domain = value.rsplit("@", 1)
        if not local:
            raise ValueError("Email local part is empty")
        return local + "@" + normalize("domain", domain)
    if kind == "phone":
        if not re.fullmatch(r"\+[1-9][0-9]{6,14}", value):
            raise ValueError("Phone input must be E.164, for example +12025550123")
    if kind in {"url", "profile"}:
        parsed = urlsplit(value)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError("Expected an HTTP(S) URL without credentials")
        _ = parsed.port
        host = parsed.hostname.encode("idna").decode("ascii").lower()
        if ":" in host:
            host = f"[{host}]"
        netloc = host + (f":{parsed.port}" if parsed.port else "")
        return urlunsplit((parsed.scheme.lower(), netloc, parsed.path or "/", parsed.query, ""))
    if kind == "username" and not re.fullmatch(r"[\w.@+-]{1,100}", value, flags=re.UNICODE):
        raise ValueError("Username contains unsupported characters")
    return value


class Entity(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    kind: EntityType
    value: str

    @model_validator(mode="after")
    def canonicalize(self):
        object.__setattr__(self, "value", normalize(self.kind, self.value))
        return self

    @property
    def id(self) -> str:
        return hashlib.sha256(f"{self.kind}\0{self.value}".encode()).hexdigest()[:24]


class Finding(BaseModel):
    model_config = ConfigDict(extra="forbid")
    source: str = Field(min_length=1, max_length=100)
    subject: Entity
    relation: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    object: Entity
    confidence: Confidence = "tentative"
    evidence_url: str
    legal_basis: str = Field(min_length=3, max_length=2000)
    observed_at: datetime = Field(default_factory=utcnow)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("evidence_url")
    @classmethod
    def safe_evidence(cls, value):
        if re.fullmatch(r"urn:sha256:[a-f0-9]{64}", value):
            return value
        return normalize("url", value)

    @field_validator("observed_at")
    @classmethod
    def aware_time(cls, value):
        if value.tzinfo is None:
            raise ValueError("Evidence timestamps must include a timezone")
        return value

    @property
    def id(self) -> str:
        key = "\0".join((self.source, self.subject.id, self.relation, self.object.id, self.evidence_url))
        if self.metadata.get("stix_id"):
            key += "\0" + str(self.metadata["stix_id"]) + "\0" + str(self.metadata.get("stix_relationship_type", ""))
        if self.evidence_url.startswith("urn:sha256:") and isinstance(self.metadata.get("location"), str):
            key += "\0" + self.metadata["location"]
        return hashlib.sha256(key.encode()).hexdigest()[:24]


class QueryContext(BaseModel):
    model_config = ConfigDict(extra="forbid")
    query: str
    input_type: InputType
    purpose: str = Field(min_length=8, max_length=500)
    authorized: Literal[True]
    allowed_hosts: list[str] = Field(default_factory=list, max_length=20)
    seed_urls: list[str] = Field(default_factory=list, max_length=20)
    terms_url: str | None = None
    max_pages: int = Field(default=3, ge=1, le=20)
    max_findings: int = Field(default=500, ge=1, le=2000)
    max_requests: int = Field(default=50, ge=1, le=200)
    preserve_pages: bool = False

    @model_validator(mode="after")
    def validate_context(self):
        self.query = normalize(self.input_type, self.query)
        self.purpose = self.purpose.strip()
        if len(self.purpose) < 8:
            raise ValueError("Provide a meaningful purpose or engagement ID (8+ characters)")
        self.allowed_hosts = [normalize("domain", host) for host in self.allowed_hosts]
        self.seed_urls = [normalize("url", url) for url in self.seed_urls]
        if self.terms_url:
            self.terms_url = normalize("url", self.terms_url)
        return self

    @property
    def entity(self) -> Entity:
        return Entity(kind=self.input_type, value=self.query)


class ModuleSpec(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    name: str = Field(pattern=r"^[a-z][a-z0-9_]{0,63}$")
    input_types: list[InputType]
    description: str
    rate_limit_per_min: int = Field(default=10, ge=1, le=60)
    key_env: list[str] = Field(default_factory=list)
    terms_url: str
    default_enabled: bool = False


class ModuleResult(BaseModel):
    module: str
    status: Literal["ok", "empty", "skipped", "error", "rate_limited", "cancelled"]
    findings: list[Finding] = Field(default_factory=list)
    message: str = ""
    elapsed_ms: int = 0
    truncated: bool = False


class RunReport(BaseModel):
    schema_version: str = "1.0"
    run_id: str
    title: str | None = Field(default=None, max_length=200)
    created_at: datetime = Field(default_factory=utcnow)
    context: QueryContext
    results: list[ModuleResult]
    graph: dict[str, Any]
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    stix_marking_definitions: list[dict[str, Any]] = Field(default_factory=list)
    coverage: dict[str, Any] = Field(default_factory=dict)
    notes: list[str] = Field(default_factory=lambda: [
        "Matching usernames and names are leads, not proof of a shared real-world identity.",
        "Confidence applies to each reported relationship, not to ownership of an account.",
        "Reports may contain personal data. Review evidence and handle reports appropriately.",
    ])

    @model_validator(mode="after")
    def normalize_shared_markings(self):
        definitions = {}
        def add(definition):
            identifier = definition["id"]
            if identifier in definitions and definitions[identifier] != definition:
                raise ValueError("Conflicting STIX marking definitions; refusing to weaken restrictions")
            definitions[identifier] = definition
        for definition in self.stix_marking_definitions:
            add(definition)
        results = []
        for result in self.results:
            findings = []
            for finding in result.findings:
                if "stix_marking_definitions" not in finding.metadata:
                    findings.append(finding)
                    continue
                metadata = dict(finding.metadata)
                for definition in metadata.pop("stix_marking_definitions", []):
                    add(definition)
                findings.append(finding.model_copy(update={"metadata": metadata}))
            results.append(result.model_copy(update={"findings": findings}))
        self.results = results
        self.stix_marking_definitions = list(definitions.values())
        return self

    def bounded_json(self):
        """Bound serialization incrementally, including mutable post-run artifacts."""
        parts, size = [], 0
        for part in json.JSONEncoder(ensure_ascii=False, separators=(",", ":")).iterencode(self.model_dump(mode="json")):
            size += len(part.encode("utf-8"))
            if size > 16_000_000:
                raise ValueError("Report exceeds the 16 MB serialized output budget; narrow the case or source scope")
            parts.append(part)
        return "".join(parts)


class OSINTModule(Protocol):
    spec: ModuleSpec

    async def run(self, context: QueryContext, http: Any) -> list[Finding]: ...
