"""Opt-in workspace encryption using scrypt and AES-GCM; existing plaintext is never silently migrated."""

import base64
import json
import os
import uuid
from pathlib import Path

_KEYS = {}
PREFIX = "enc:v1:"
MAGIC = b"OSINT-VAULT-1\n"


class Vault:
    def __init__(self, state):
        self.state = Path(state).resolve()
        self.manifest = self.state / "vault.json"
        self.enabled = self.manifest.is_file()
        self.key = None
        if self.enabled:
            self.config = json.loads(self.manifest.read_text(encoding="utf-8"))
            if self.config.get("version") != 1:
                raise ValueError("Unsupported workspace encryption version")
            self.key = _KEYS.get(str(self.state))
            if self.key is None and os.environ.get("OSINT_VAULT_PASSPHRASE"):
                self.unlock(os.environ["OSINT_VAULT_PASSPHRASE"])
            if self.key is None:
                raise ValueError("Workspace is locked. Unlock it or set OSINT_VAULT_PASSPHRASE before starting.")

    @staticmethod
    def _derive(password, salt):
        try:
            from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
        except ImportError as exc:
            raise ValueError('Install encryption support: python -m pip install ".[security]"') from exc
        return Scrypt(salt=salt, length=32, n=32768, r=8, p=1).derive(password.encode("utf-8"))

    @classmethod
    def initialize(cls, state, password):
        state = Path(state).resolve()
        if len(password) < 12:
            raise ValueError("Use a workspace passphrase of at least 12 characters")
        if state.exists() and any(state.iterdir()):
            raise ValueError("Choose a new empty state directory; existing plaintext data is not migrated")
        state.mkdir(parents=True, exist_ok=True)
        salt = os.urandom(16)
        key = cls._derive(password, salt)
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        identifier = str(uuid.uuid4())
        nonce = os.urandom(12)
        check = nonce + AESGCM(key).encrypt(nonce, b"workspace key verified", identifier.encode())
        config = {"version": 1, "id": identifier, "salt": base64.b64encode(salt).decode(),
                  "check": base64.b64encode(check).decode(), "kdf": "scrypt N=32768 r=8 p=1", "cipher": "AES-256-GCM"}
        with (state / "vault.json").open("x", encoding="utf-8") as stream:
            json.dump(config, stream)
        _KEYS[str(state)] = key
        return cls(state)

    @classmethod
    def unlock_workspace(cls, state, password):
        state = Path(state).resolve()
        instance = object.__new__(cls)
        instance.state = state
        instance.config = json.loads((state / "vault.json").read_text(encoding="utf-8"))
        instance.unlock(password)

    def unlock(self, password):
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        try:
            if self.config.get("version") != 1:
                raise ValueError("Unsupported workspace encryption version")
            salt = base64.b64decode(self.config["salt"], validate=True)
            check = base64.b64decode(self.config["check"], validate=True)
            if len(salt) != 16 or len(check) > 256:
                raise ValueError("Invalid vault parameters")
            key = self._derive(password, salt)
            plain = AESGCM(key).decrypt(check[:12], check[12:], self.config["id"].encode())
            if plain != b"workspace key verified":
                raise ValueError("Invalid key check")
        except Exception as exc:
            raise ValueError("Incorrect passphrase or damaged workspace manifest") from exc
        _KEYS[str(self.state)] = self.key = key

    def encrypt(self, raw, purpose):
        if not self.enabled:
            return raw
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        nonce = os.urandom(12)
        return nonce + AESGCM(self.key).encrypt(nonce, raw, (self.config["id"] + ":" + purpose).encode())

    def decrypt(self, raw, purpose):
        if not self.enabled:
            return raw
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        try:
            return AESGCM(self.key).decrypt(raw[:12], raw[12:], (self.config["id"] + ":" + purpose).encode())
        except Exception as exc:
            raise ValueError("Encrypted evidence failed authentication") from exc

    def encode(self, text, purpose):
        if not self.enabled:
            return text
        return PREFIX + base64.b64encode(self.encrypt(text.encode(), purpose)).decode()

    def decode(self, text, purpose):
        if not self.enabled:
            if text.startswith(PREFIX):
                raise ValueError("Encrypted records need their original vault manifest")
            return text
        if not text.startswith(PREFIX):
            raise ValueError("Unexpected plaintext record in an encrypted workspace")
        return self.decrypt(base64.b64decode(text[len(PREFIX):], validate=True), purpose).decode()

    def write_bytes(self, path, data, purpose="artifact"):
        path = Path(path)
        if path.exists():
            if self.read_bytes(path, purpose) != data:
                raise ValueError("Existing evidence file differs; original preserved")
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(MAGIC + self.encrypt(data, purpose) if self.enabled else data)

    def read_bytes(self, path, purpose="artifact"):
        with Path(path).open("rb") as stream:
            data = stream.read(30_000_001)
        if len(data) > 30_000_000:
            raise ValueError("Evidence file exceeds its verification budget")
        if self.enabled:
            if not data.startswith(MAGIC):
                raise ValueError("Unexpected plaintext artifact in an encrypted workspace")
            return self.decrypt(data[len(MAGIC):], purpose)
        return data
