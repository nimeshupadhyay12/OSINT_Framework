"""Persistent pacing shared by CLI runs that use the same state directory."""

import asyncio
import math
import time
from contextlib import closing

from .audit import AuditLog


class RateLimited(Exception):
    pass


class RateLimiter:
    def __init__(self, audit: AuditLog):
        self.audit = audit
        with closing(self.audit.connect()) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS rate_history (source TEXT PRIMARY KEY, last_at REAL NOT NULL)")

    async def acquire(self, source: str, per_minute: int):
        if isinstance(per_minute, bool) or not isinstance(per_minute, int) or not 1 <= per_minute <= 60:
            raise ValueError("Rate must be between 1 and 60 requests/minute")
        deadline = time.monotonic() + 60
        interval = 60 / per_minute
        while True:
            now = time.time()
            with closing(self.audit.connect()) as db, db:
                db.execute("BEGIN IMMEDIATE")
                row = db.execute("SELECT next_at FROM rate_slots WHERE source=?", (source,)).fetchone()
                last = db.execute("SELECT last_at FROM rate_history WHERE source=?", (source,)).fetchone()
                if row and not last:
                    # Older state stores a reservation, not its originating rate.
                    # Begin a full interval rather than assume that rate was slow enough.
                    last = (now,)
                    db.execute("INSERT INTO rate_history VALUES(?,?)", (source, now))
                due = max(now, row[0] if row else now, last[0] + interval if last else now)
                delay = due - now
                if delay <= 0:
                    db.execute("INSERT OR REPLACE INTO rate_slots VALUES(?,?)", (source, now + interval))
                    db.execute("INSERT OR REPLACE INTO rate_history VALUES(?,?)", (source, now))
                    return
            if delay > max(0, deadline - time.monotonic()):
                raise RateLimited(f"Provider cooldown active; retry after {math.ceil(delay)} seconds")
            # Do not reserve a future slot: recheck under the database lock after
            # sleeping so concurrent requests and new Retry-After values are honored.
            await asyncio.sleep(delay)

    def defer(self, source: str, seconds: float):
        if not math.isfinite(seconds) or seconds < 0:
            raise ValueError("Cooldown must be finite and non-negative")
        until = time.time() + max(1, seconds)
        with closing(self.audit.connect()) as db, db:
            db.execute("INSERT INTO rate_slots VALUES(?,?) ON CONFLICT(source) DO UPDATE SET next_at=MAX(next_at,excluded.next_at)", (source, until))
