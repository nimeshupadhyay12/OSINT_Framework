"""Local case persistence with immutable report versions and analyst review history."""

import hashlib
import uuid
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

from .correlator import CONFIDENCE_ORDER, correlate
from .database import connect
from .schema import ModuleResult, RunReport, utcnow
from .vault import Vault


class CaseStore:
    def __init__(self, state_dir: Path):
        self.directory = Path(state_dir)
        self.vault = Vault(state_dir)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory / "cases.sqlite3"
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS cases(id TEXT PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS reports(run_id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(id),
                    saved_at TEXT NOT NULL, sha256 TEXT NOT NULL, payload TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS case_reports ON reports(case_id, saved_at);
                CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(id),
                    created_at TEXT NOT NULL, text TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(id),
                    finding_id TEXT NOT NULL, decision TEXT NOT NULL, reason TEXT NOT NULL, created_at TEXT NOT NULL);
            """)

    @contextmanager
    def connect(self):
        db = connect(self.path, named_rows=True)
        try:
            with db:
                yield db
        finally:
            db.close()

    def create(self, title):
        title = title.strip()
        if not 3 <= len(title) <= 200:
            raise ValueError("Case title must contain 3–200 characters")
        identifier = str(uuid.uuid4())
        with self.connect() as db:
            db.execute("INSERT INTO cases VALUES (?,?,?)", (identifier, self.vault.encode(title, "case:" + identifier), utcnow().isoformat()))
        return identifier

    def get(self, case_id):
        with self.connect() as db:
            row = db.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if row is None:
            raise ValueError("Case does not exist")
        result = dict(row)
        result["title"] = self.vault.decode(result["title"], "case:" + case_id)
        return result

    def list(self):
        with self.connect() as db:
            rows = [dict(row) for row in db.execute("""SELECT cases.*, COUNT(reports.run_id) AS runs
                FROM cases LEFT JOIN reports ON cases.id=reports.case_id GROUP BY cases.id ORDER BY created_at DESC""")]
        for row in rows:
            row["title"] = self.vault.decode(row["title"], "case:" + row["id"])
        return rows

    def add(self, case_id, report: RunReport):
        self.get(case_id)
        payload = report.bounded_json()
        digest = hashlib.sha256(payload.encode()).hexdigest()
        with self.connect() as db:
            prior = db.execute("SELECT case_id,sha256 FROM reports WHERE run_id=?", (report.run_id,)).fetchone()
            if prior:
                if prior["case_id"] == case_id and prior["sha256"] == digest:
                    return
                raise ValueError("Run ID already exists with different evidence or case; original preserved")
            db.execute("INSERT INTO reports VALUES (?,?,?,?,?)", (report.run_id, case_id, utcnow().isoformat(), digest,
                       self.vault.encode(payload, "report:" + report.run_id)))

    def reports(self, case_id, *, limit=None, offset=0):
        self.get(case_id)
        with self.connect() as db:
            sql = "SELECT run_id,payload,sha256 FROM reports WHERE case_id=? ORDER BY saved_at,run_id"
            args = (case_id,)
            if limit is not None:
                sql += " LIMIT ? OFFSET ?"
                args += (limit, offset)
            rows = db.execute(sql, args).fetchall()
        result = []
        for row in rows:
            payload = self.vault.decode(row["payload"], "report:" + row["run_id"])
            if hashlib.sha256(payload.encode()).hexdigest() != row["sha256"]:
                raise ValueError("Stored case report digest failed verification")
            result.append(RunReport.model_validate_json(payload))
        return result

    def note(self, case_id, text):
        self.get(case_id)
        if not 1 <= len(text.strip()) <= 10000:
            raise ValueError("A note must contain 1–10000 characters")
        with self.connect() as db:
            db.execute("INSERT INTO notes(case_id,created_at,text) VALUES (?,?,?)", (case_id, utcnow().isoformat(), self.vault.encode(text.strip(), "note:" + case_id)))

    def review(self, case_id, finding_id, decision, reason):
        if decision not in {"accepted", "rejected", "unreviewed"} or not 3 <= len(reason.strip()) <= 2000:
            raise ValueError("Choose accepted/rejected/unreviewed and supply a review reason")
        if not any(f.id == finding_id for r in self.reports(case_id) for result in r.results for f in result.findings):
            raise ValueError("Finding does not belong to this case")
        with self.connect() as db:
            db.execute("INSERT INTO reviews(case_id,finding_id,decision,reason,created_at) VALUES (?,?,?,?,?)",
                       (case_id, finding_id, decision, self.vault.encode(reason.strip(), "review:" + case_id + ":" + finding_id), utcnow().isoformat()))

    def history(self, case_id):
        self.get(case_id)
        with self.connect() as db:
            history = {name: [dict(row) for row in db.execute(f"SELECT * FROM {name} WHERE case_id=? ORDER BY id", (case_id,))]
                    for name in ("notes", "reviews")}
        for row in history["notes"]:
            row["text"] = self.vault.decode(row["text"], "note:" + case_id)
        for row in history["reviews"]:
            row["reason"] = self.vault.decode(row["reason"], "review:" + case_id + ":" + row["finding_id"])
        return history

    def evidence(self, case_id):
        rows = {}
        for report in self.reports(case_id):
            for result in report.results:
                for f in result.findings:
                    row = rows.setdefault(f.id, {"finding": f, "runs": [], "first_seen": f.observed_at,
                                                 "last_seen": f.observed_at, "origins": set(), "versions": []})
                    row["runs"].append(report.run_id)
                    row["first_seen"] = min(row["first_seen"], f.observed_at)
                    row["last_seen"] = max(row["last_seen"], f.observed_at)
                    confidence = min((row["finding"].confidence, f.confidence), key=CONFIDENCE_ORDER.get)
                    prior = row["finding"]
                    if f.observed_at >= row["finding"].observed_at:
                        row["finding"] = f.model_copy(update={"confidence": confidence})
                    else:
                        row["finding"] = row["finding"].model_copy(update={"confidence": confidence})
                    # A later observation cannot silently declassify an earlier claim.
                    metadata = dict(row["finding"].metadata)
                    for field in ("stix_object_marking_refs", "stix_granular_markings"):
                        values = list(prior.metadata.get(field, []))
                        for value in f.metadata.get(field, []):
                            if value not in values:
                                values.append(value)
                        if values:
                            metadata[field] = values
                    row["finding"] = row["finding"].model_copy(update={"metadata": metadata})
                    digest = f.metadata.get("content_sha256") or f.metadata.get("import_sha256")
                    if digest and digest not in row["versions"]:
                        row["versions"].append(digest)
                    origins = f.metadata.get("upstream_sources") or [urlsplit(f.evidence_url).hostname or f.source]
                    row["origins"].update(str(origin) for origin in origins)
        reviews = {r["finding_id"]: r for r in self.history(case_id)["reviews"]}
        for key, row in rows.items():
            row["review"] = reviews.get(key, {"decision": "unreviewed", "reason": ""})
            row["origins"] = sorted(row["origins"])
            row["changed"] = len(row["versions"]) > 1
        return list(rows.values())

    def combined(self, case_id):
        case, reports = self.get(case_id), self.reports(case_id)
        if not reports:
            raise ValueError("Case has no saved reports")
        rows = self.evidence(case_id)
        findings = []
        for row in rows:
            finding = row["finding"].model_copy(deep=True)
            finding.metadata.update({"case_review": row["review"], "case_runs": row["runs"],
                                     "case_first_seen": row["first_seen"].isoformat(),
                                     "case_last_seen": row["last_seen"].isoformat(),
                                     "case_content_changed": row["changed"], "case_origins": row["origins"]})
            findings.append(finding)
        notes = [f"Combined case: {case['title']}; {len(reports)} saved runs. Each finding retains its original subject.",
                 "Repeated sightings do not increase confidence. Analyst acceptance does not verify ownership.",
                 "Observation ranges may represent import receipt times; inspect timestamp_kind for each source."]
        notes.extend("Analyst note: " + item["text"] for item in self.history(case_id)["notes"])
        outcomes = [ModuleResult(module=f"{result.module} / {report.run_id}", status=result.status,
                      message=f"Original run: {len(result.findings)} findings. {result.message}",
                      elapsed_ms=result.elapsed_ms, truncated=result.truncated)
                    for report in reports for result in report.results]
        return RunReport(run_id="case-" + case_id, title=case["title"], context=reports[0].context,
                         results=[ModuleResult(module="case_evidence", status="ok" if findings else "empty", findings=findings), *outcomes],
                         graph=correlate(findings), notes=notes,
                         stix_marking_definitions=[definition for report in reports for definition in report.stix_marking_definitions],
                         artifacts=[artifact for report in reports for artifact in report.artifacts])

    def verify_artifacts(self, case_id):
        checked = set()
        for report in self.reports(case_id):
            for artifact in report.artifacts:
                path = Path(artifact["path"])
                if (str(path), artifact["sha256"]) in checked:
                    continue
                if not path.is_file() or path.stat().st_size > 10_001_000:
                    raise ValueError("Evidence artifact is missing or exceeds its size budget")
                if hashlib.sha256(self.vault.read_bytes(path)).hexdigest() != artifact["sha256"]:
                    raise ValueError("Evidence artifact digest failed verification")
                checked.add((str(path), artifact["sha256"]))
        return len(checked)

    def source_health(self):
        with self.connect() as db:
            rows = db.execute("SELECT run_id,payload,sha256 FROM reports ORDER BY saved_at").fetchall()
        health = {}
        for row in rows:
            payload = self.vault.decode(row["payload"], "report:" + row["run_id"])
            if hashlib.sha256(payload.encode()).hexdigest() != row["sha256"]:
                raise ValueError("Stored case report digest failed verification")
            report = RunReport.model_validate_json(payload)
            for result in report.results:
                health[result.module] = {"status": result.status, "at": report.created_at.isoformat(),
                                         "message": result.message, "run_id": report.run_id}
        return health
