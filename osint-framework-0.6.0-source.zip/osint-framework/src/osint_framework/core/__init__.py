"""Collection, policy, and evidence primitives."""
