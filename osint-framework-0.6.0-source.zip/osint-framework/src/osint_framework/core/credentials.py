"""Per-investigation credentials, with explicit optional OS-keychain persistence."""

import os
from contextlib import contextmanager
from contextvars import ContextVar

_SESSION = ContextVar("osint_credentials", default=None)
KEY_NAMES = ("BRAVE_SEARCH_API_KEY", "HIBP_API_KEY", "HUNTER_API_KEY", "VIRUSTOTAL_API_KEY",
             "SHODAN_API_KEY", "TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "URLSCAN_API_KEY",
             "CERTSPOTTER_API_KEY", "OTX_API_KEY", "ABUSECH_AUTH_KEY")


def get_secret(name):
    return (_SESSION.get() or {}).get(name) or os.environ.get(name)


@contextmanager
def credentials(values=None):
    if any(key not in KEY_NAMES or not isinstance(value, str) for key, value in (values or {}).items()):
        raise ValueError("Unsupported credential name or value")
    token = _SESSION.set(dict(values or {}))
    try:
        yield
    finally:
        _SESSION.reset(token)


def _keyring():
    try:
        import keyring
    except ImportError as exc:
        raise ValueError('Install OS-keychain support with: python -m pip install ".[desktop]"') from exc
    backend = keyring.get_keyring()
    module = type(backend).__module__
    if not module.startswith(("keyring.backends.Windows", "keyring.backends.macOS", "keyring.backends.SecretService")):
        raise ValueError("An OS-backed credential store is unavailable; use session credentials")
    return keyring


def save_secret(name, value):
    if name not in KEY_NAMES or not value.strip():
        raise ValueError("Choose a supported credential and supply a value")
    _keyring().set_password("osint-correlation-framework", name, value.strip())


def load_secrets():
    backend = _keyring()
    return {key: value for key in KEY_NAMES if (value := backend.get_password("osint-correlation-framework", key))}
