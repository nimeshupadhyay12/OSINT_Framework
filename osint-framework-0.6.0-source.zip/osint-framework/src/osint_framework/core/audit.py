"""Hash-chained audit with optional vault encryption and shared database storage."""

import hashlib
import json
from contextlib import closing
from pathlib import Path

from .database import connect
from .schema import utcnow
from .vault import Vault

POLICY_VERSION = "2026-09-12-v1"


class AuditLog:
    def __init__(self, state_dir: Path):
        self.vault = Vault(state_dir)
        state_dir.mkdir(parents=True, exist_ok=True)
        self.path = state_dir / "audit.sqlite3"
        with closing(self.connect()) as db, db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY, at TEXT NOT NULL, kind TEXT NOT NULL,
                    payload TEXT NOT NULL, previous_hash TEXT NOT NULL, hash TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS rate_slots (source TEXT PRIMARY KEY, next_at REAL NOT NULL);
            """)

    def connect(self):
        return connect(self.path)

    def append(self, kind: str, payload: dict):
        at = utcnow().isoformat()
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        encoded = self.vault.encode(encoded, "audit:" + kind + ":" + at)
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            prior = db.execute("SELECT hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            previous = prior[0] if prior else "0" * 64
            digest = hashlib.sha256(f"{previous}\n{at}\n{kind}\n{encoded}".encode()).hexdigest()
            db.execute("INSERT INTO events(at,kind,payload,previous_hash,hash) VALUES(?,?,?,?,?)",
                       (at, kind, encoded, previous, digest))

    def consented(self) -> bool:
        with closing(self.connect()) as db, db:
            row = db.execute("SELECT value FROM settings WHERE key='policy_version'").fetchone()
        return bool(row and row[0] == POLICY_VERSION)

    def accept_policy(self):
        self.append("policy_accepted", {"version": POLICY_VERSION})
        with closing(self.connect()) as db, db:
            db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES('policy_version',?)", (POLICY_VERSION,))

    def verify(self) -> tuple[bool, int]:
        previous = "0" * 64
        count = 0
        with closing(self.connect()) as db, db:
            rows = db.execute("SELECT at,kind,payload,previous_hash,hash FROM events ORDER BY seq")
            for at, kind, payload, prior, digest in rows:
                calculated = hashlib.sha256(f"{previous}\n{at}\n{kind}\n{payload}".encode()).hexdigest()
                if prior != previous or digest != calculated:
                    return False, count
                previous = digest
                count += 1
        return True, count


def query_fingerprint(input_type: str, query: str) -> str:
    return hashlib.sha256(f"{input_type}\0{query}".encode()).hexdigest()
