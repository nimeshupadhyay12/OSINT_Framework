"""Conservative graph: deduplicate observations without inferring personal identity."""

import networkx as nx

from .schema import Finding

CONFIDENCE_ORDER = {"tentative": 0, "likely": 1, "certain": 2}


def correlate(findings: list[Finding]) -> dict:
    graph = nx.MultiDiGraph()
    for finding in findings:
        for entity in (finding.subject, finding.object):
            graph.add_node(entity.id, kind=entity.kind, value=entity.value)
        key = finding.relation
        if key == "stix_relationship" and finding.metadata.get("stix_relationship_type"):
            key = "stix:" + str(finding.metadata["stix_relationship_type"])
        prior = graph.get_edge_data(finding.subject.id, finding.object.id, key)
        if prior:
            prior["sources"] = sorted(set(prior["sources"]) | {finding.source})
            if finding.id not in prior["evidence_ids"]:
                prior["evidence_ids"].append(finding.id)
            # Repetition does not increase confidence. Use the weakest supplied claim.
            if CONFIDENCE_ORDER[finding.confidence] < CONFIDENCE_ORDER[prior["confidence"]]:
                prior["confidence"] = finding.confidence
        else:
            graph.add_edge(finding.subject.id, finding.object.id, key=key, relation=key,
                           confidence=finding.confidence, sources=[finding.source], evidence_ids=[finding.id])
    return {
        "nodes": [{"id": node, **attrs} for node, attrs in sorted(graph.nodes(data=True))],
        "edges": [{"source": source, "target": target, **attrs}
                  for source, target, _, attrs in sorted(graph.edges(keys=True, data=True), key=lambda e: e[:3])],
        "method": "Exact typed identifiers; explicit source relations; no real-world identity merging",
    }
