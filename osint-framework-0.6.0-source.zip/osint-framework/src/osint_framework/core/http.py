"""Bounded GET requests, credential-safe errors, and DNS-pinned public-page retrieval."""

import asyncio
import ipaddress
import json
import math
import socket
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlencode, urljoin, urlsplit, urlunsplit

import httpx

from .ratelimit import RateLimited, RateLimiter

USER_AGENT = "OSINTCorrelation/0.6 (+authorized research; no bot evasion)"
MAX_RESPONSE_BYTES = 5_000_000
REQUEST_BUDGET_SECONDS = 90
API_HOSTS = {
    "api.github.com", "public.api.bsky.app", "dns.google", "crt.sh", "rdap.org",
    "lookups.twilio.com", "haveibeenpwned.com", "api.hunter.io", "www.virustotal.com",
    "api.shodan.io", "api.search.brave.com",
    "internetdb.shodan.io", "stat.ripe.net", "archive.org", "www.wikidata.org",
    "en.wikipedia.org", "hacker-news.firebaseio.com", "urlscan.io",
    "api.certspotter.com", "index.commoncrawl.org", "otx.alienvault.com",
    "urlhaus-api.abuse.ch", "threatfox-api.abuse.ch",
    "web.archive.org",
}


class SourceError(Exception):
    """Safe-to-display error, deliberately excluding request URLs and credentials."""


class SourceSkipped(Exception):
    pass


def retry_delay(value: str | None) -> float:
    try:
        seconds = float(value)
        if not math.isfinite(seconds) or seconds < 0:
            return 60
        return max(1, seconds)
    except (ValueError, TypeError):
        try:
            date = parsedate_to_datetime(value)
            if date.tzinfo is None:
                date = date.replace(tzinfo=timezone.utc)
            return max(1, (date - datetime.now(timezone.utc)).total_seconds())
        except (ValueError, TypeError, OverflowError):
            return 60


async def public_address(host: str) -> str:
    try:
        async with asyncio.timeout(8):
            records = await asyncio.to_thread(socket.getaddrinfo, host, 443, type=socket.SOCK_STREAM)
    except (OSError, TimeoutError) as exc:
        raise SourceError("Public hostname could not be resolved") from exc
    addresses = {record[4][0] for record in records}
    try:
        permitted = addresses and all(ipaddress.ip_address(address).is_global for address in addresses)
    except ValueError:
        permitted = False
    if not permitted:
        raise SourceSkipped("Only globally routable public destinations are permitted")
    return sorted(addresses)[0]


class HttpClient:
    def __init__(self, limiter: RateLimiter, client: httpx.AsyncClient | None = None, *, max_requests=50, snapshot=None):
        self.limiter = limiter
        self.max_requests, self.request_count, self.snapshot = max_requests, 0, snapshot
        self.client = client or httpx.AsyncClient(
            timeout=httpx.Timeout(20, connect=8), follow_redirects=False, trust_env=False,
            limits=httpx.Limits(max_connections=4, max_keepalive_connections=4),
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
        )

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_):
        await self.client.aclose()

    async def _get(self, url, *, source, rate_limit_per_min, params=None, headers=None,
                   auth=None, not_found_ok=False, pinned=False, allowed_content_types=None,
                   redirect_depth=0, method="GET", content=None):
        if self.request_count >= self.max_requests:
            raise SourceSkipped("Run HTTP request budget exhausted; remaining source work was stopped")
        try:
            if len(url) > 4096 or any(ord(char) < 32 for char in url) or "\\" in url:
                raise ValueError("Invalid URL")
            parsed = urlsplit(url)
            if (
                parsed.scheme != "https" or not parsed.hostname or parsed.username is not None
                or parsed.password is not None or parsed.port not in (None, 443)
            ):
                raise ValueError("Invalid destination")
            host = parsed.hostname.encode("idna").decode("ascii").lower()
        except (ValueError, UnicodeError) as exc:
            raise SourceSkipped("Only HTTPS on port 443 without embedded credentials is permitted") from exc
        if not pinned and host not in API_HOSTS:
            raise SourceSkipped("Native API destination is not allowlisted")
        try:
            request_headers = httpx.Headers({"User-Agent": USER_AGENT, "Accept": "application/json", **(headers or {})})
        except (ValueError, TypeError, UnicodeError):
            raise SourceError("Request headers are invalid") from None
        request_headers["Accept-Encoding"] = "identity"
        extensions = {}
        connect_url = url
        if pinned:
            if auth is not None or any(name in request_headers for name in ("Authorization", "Cookie", "Proxy-Authorization", "X-Api-Key")):
                raise SourceSkipped("Credentials are not permitted for public page retrieval")
            address = await public_address(host)
            authority = f"[{address}]" if ":" in address else address
            connect_url = urlunsplit(("https", authority, parsed.path, parsed.query, ""))
            request_headers["Host"] = host
            # httpcore's AnyIO backend takes a str for TLS hostname verification.
            extensions["sni_hostname"] = host
            # Pinned IP URLs otherwise share a pool origin across distinct hosts.
            # The owned client uses HTTP/1.1; close prevents reusing another host's TLS.
            request_headers["Connection"] = "close"
        await self.limiter.acquire(source, rate_limit_per_min)
        if self.request_count >= self.max_requests:
            raise SourceSkipped("Run HTTP request budget exhausted; remaining source work was stopped")
        self.request_count += 1
        try:
            # Construct directly so client-level cookies, headers, params and auth
            # cannot silently travel to another origin or a public-page request.
            request = httpx.Request(method, connect_url, params=params, headers=request_headers, extensions=extensions, content=content)
            response = await self.client.send(request, stream=True, auth=auth, follow_redirects=False)
            try:
                status = response.status_code
                if status == 429 or (status == 503 and response.headers.get("Retry-After")):
                    delay = retry_delay(response.headers.get("Retry-After"))
                    self.limiter.defer(source, delay)
                    raise RateLimited(f"Provider requested a cooldown of {int(delay)} seconds")
                if status in (301, 302, 303, 307, 308):
                    if source != "rdap" or redirect_depth >= 3 or headers or auth is not None or params or parsed.query:
                        raise SourceSkipped("Redirect was not followed")
                    location = response.headers.get("Location", "")
                    if not location.strip() or any(ord(char) < 32 for char in location) or "\\" in location:
                        raise SourceSkipped("Redirect target is missing or invalid")
                    try:
                        destination = urljoin(url, location)
                    except ValueError as exc:
                        raise SourceSkipped("Redirect target is missing or invalid") from exc
                    if destination.split("#", 1)[0] == url.split("#", 1)[0]:
                        raise SourceSkipped("Redirect would repeat the same request")
                    await response.aclose()
                    return await self._get(destination, source=source, rate_limit_per_min=rate_limit_per_min,
                                           pinned=True, not_found_ok=not_found_ok,
                                           allowed_content_types=allowed_content_types, redirect_depth=redirect_depth + 1)
                if status == 404 and not_found_ok:
                    return None
                if status in (401, 403):
                    raise SourceSkipped("Provider denied access; check credentials, plan, or source policy")
                if not 200 <= status < 300:
                    raise SourceError(f"Provider returned HTTP {status}")
                if source == "webpage" and status != 200:
                    raise SourceSkipped("Public pages and robots.txt require a complete HTTP 200 response")
                if allowed_content_types:
                    mime = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                    if mime not in allowed_content_types:
                        raise SourceSkipped("Response content type is not supported")
                if response.headers.get("Content-Encoding", "identity").lower() not in {"", "identity"}:
                    raise SourceSkipped("Encoded response refused; an uncompressed response was requested")
                length = response.headers.get("Content-Length")
                if length is not None:
                    try:
                        declared_size = int(length)
                    except ValueError as exc:
                        raise SourceError("Provider returned an invalid content length") from exc
                    if declared_size < 0 or declared_size > MAX_RESPONSE_BYTES:
                        raise SourceError("Provider response exceeds the 5 MB limit or has invalid length")
                chunks = bytearray()
                async for chunk in response.aiter_bytes(chunk_size=65_536):
                    if len(chunks) + len(chunk) > MAX_RESPONSE_BYTES:
                        raise SourceError("Provider response exceeds the 5 MB limit")
                    chunks.extend(chunk)
                return bytes(chunks)
            finally:
                await response.aclose()
        except (httpx.HTTPError, httpx.InvalidURL, UnicodeError, ValueError):
            raise SourceError("Network request failed or timed out") from None

    async def get_json(self, url, **kwargs):
        data = await self._bounded_get(url, **kwargs)
        if data is None:
            return None
        try:
            return json.loads(data)
        except (ValueError, UnicodeError) as exc:
            raise SourceError("Provider returned invalid JSON") from exc

    async def lookup_json(self, url, *, payload, source, **kwargs):
        """Only documented, read-only lookup POSTs; never submissions or downloads."""
        if not isinstance(payload, dict):
            raise SourceSkipped("Lookup payload must be an object")
        approved = (
            source == "urlhaus" and url == "https://urlhaus-api.abuse.ch/v1/host/" and set(payload) == {"host"}
            or source == "urlhaus" and url == "https://urlhaus-api.abuse.ch/v1/url/" and set(payload) == {"url"}
            or source == "threatfox" and url == "https://threatfox-api.abuse.ch/api/v1/"
            and set(payload) == {"query", "search_term", "exact_match"}
            and payload["query"] == "search_ioc" and payload["exact_match"] is True
        )
        if not approved or any(key in kwargs for key in ("method", "content", "pinned", "params", "auth")):
            raise SourceSkipped("Only approved indicator lookup operations are supported")
        content = urlencode(payload) if source == "urlhaus" else json.dumps(payload)
        if len(content.encode()) > 8192:
            raise SourceSkipped("Lookup payload exceeds limit")
        headers = {**kwargs.pop("headers", {}), "Content-Type": "application/x-www-form-urlencoded" if source == "urlhaus" else "application/json"}
        return await self.get_json(url, method="POST", content=content.encode(), source=source, headers=headers, **kwargs)

    async def get_text(self, url, **kwargs):
        data = await self._bounded_get(url, **kwargs)
        if data is not None and self.snapshot and kwargs.get("pinned") and "text/html" in kwargs.get("allowed_content_types", ()):
            self.snapshot(url, data)
        return data.decode("utf-8", errors="replace") if data is not None else None

    async def _bounded_get(self, url, **kwargs):
        try:
            async with asyncio.timeout(REQUEST_BUDGET_SECONDS):
                return await self._get(url, **kwargs)
        except TimeoutError as exc:
            raise SourceError("Request exceeded its 90-second time budget") from exc
