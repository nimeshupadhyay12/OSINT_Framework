"""One-command research and a read-only source plan."""

import asyncio
import json
from pathlib import Path

import typer

from .commands_v04 import checked
from .research import research, source_plan
from .workflow import make_context


def register_commands(app):
    @app.command("research-plan")
    @checked
    def plan(query: str, kind: str = typer.Option("auto", "--type"), profile: str = "broad"):
        """Preview source selection and setup gaps without making any provider requests."""
        context = make_context(query, kind, "Local source planning", True)
        typer.echo(json.dumps(source_plan(context, profile=profile), indent=2))

    @app.command("research")
    @checked
    def run(query: str, purpose: str = typer.Option(...), authorized: bool = typer.Option(False, "--authorized"),
            kind: str = typer.Option("auto", "--type"), profile: str = "broad",
            max_pivots: int = typer.Option(0, min=0, max=5), max_requests: int = typer.Option(80, min=1, max=200),
            case_id: str | None = typer.Option(None, "--case"), state: Path = Path(".osint-state"), out: Path = Path("reports")):
        """Research one identifier. Optional pivots stay inside a domain; results include coverage gaps."""
        context = make_context(query, kind, purpose, authorized, max_requests=max_requests)
        outcome = asyncio.run(research(context, state, out, profile=profile, max_pivots=max_pivots, case_id=case_id))
        typer.echo("Case: " + outcome.case_id)
        for result in outcome.report.results:
            typer.echo(f"{result.module}: {result.status} ({len(result.findings)} findings)")
        for label, path in outcome.paths.items():
            typer.echo(f"{label}: {path.resolve()}")
