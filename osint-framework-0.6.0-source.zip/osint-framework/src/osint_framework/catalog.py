"""Capability and local setup inventory. Checking setup performs no provider query."""

import importlib.util
import os
import shutil

from .core.credentials import KEY_NAMES
from .integrations.imports import SUPPORTED_IMPORTS
from .integrations.subfinder import SubfinderModule
from .registry import registry

IMPORT_CONTRACTS = {
    "gau": "Plain URL lines; exact URL or domain/subdomain scope; historical leads only",
    "waybackurls": "Plain URL lines; exact URL or domain/subdomain scope; historical leads only",
    "uncover": "sources.Result JSONL (-j); exact IP or scoped hostname; no port scanning",
    "misp": "Offline event attributes matching the exact query; distribution and tags preserved as metadata",
    "sherlock": "Official positive-row CSV; exact username",
    "maigret": "Simple site-to-result JSON; exact username",
    "subfinder": "JSONL host/input/source(s); exact domain boundary",
    "canonical": "Framework Finding JSON/JSONL",
    "scrapy": "public-page-v1 JSON/JSONL; phone evidence",
    "spiderfoot": "scanexportjsonmulti JSON; supported identifier events",
    "amass": "v5 oam_subs -names -nocolor; FQDN lines",
    "theharvester": "5.0 completed-result JSONL; hostname/email/ip/url",
    "opencti": "STIX 2.1 bundle; exact observables and explicit relationships",
    "recon_ng": "Hosts/contacts CSV with headers=true; scoped host/email/IP subset",
    "photon": "Named-dataset JSON; internal URLs and subdomains only",
    "whatsmyname": "Local registry to unqueried candidate URLs; account existence remains unknown",
}


def modules():
    return {**registry(), "subfinder": SubfinderModule()}


def access_class(module):
    if module.spec.name in {"urlscan", "certspotter", "otx", "urlhaus", "threatfox"}:
        return "free_account"
    if module.spec.key_env:
        return "account_required"
    if module.spec.name == "subfinder":
        return "installed_tool"
    return "no_key"


def free_selection(context):
    selected = []
    for name, module in modules().items():
        if context.input_type not in module.spec.input_types or access_class(module) != "no_key":
            continue
        if name in {"webpage", "phone_pages", "scrapy_pages"} and not (context.allowed_hosts and context.terms_url):
            continue
        if name == "phone_pages" and not context.seed_urls:
            continue
        selected.append(name)
    return selected


def inventory(*, credentials=None, health=None):
    result = []
    for name, module in modules().items():
        spec = module.spec
        missing = [key for key in spec.key_env if not (credentials or {}).get(key) and not os.environ.get(key)]
        requirements = list(missing)
        if name == "subfinder" and not shutil.which("subfinder"):
            requirements.append("subfinder executable")
        if name == "subfinder" and not os.environ.get("OSINT_SUBFINDER_SHA256"):
            requirements.append("reviewed OSINT_SUBFINDER_SHA256")
        if name == "scrapy_pages" and importlib.util.find_spec("scrapy") is None:
            requirements.append("crawler extra")
        result.append({"name": name, "inputs": spec.input_types,
                       "access": access_class(module),
                       "mode": "external runner" if name == "subfinder" else "local" if name == "phone_local" else "live collection",
                       "setup": "ready" if not requirements else "missing: " + ", ".join(requirements),
                       "scope_required": name in {"webpage", "phone_pages", "scrapy_pages"},
                       "keys": spec.key_env, "description": spec.description,
                       "reference": spec.terms_url, "last_run": (health or {}).get(name),
                       "validation": "fixture-tested; live account access is deployment-specific"})
    result.extend({"name": name, "inputs": [], "mode": "offline import", "setup": "ready",
                   "keys": [], "description": IMPORT_CONTRACTS[name], "last_run": (health or {}).get("import:" + name),
                   "validation": "versioned parser fixtures"} for name in SUPPORTED_IMPORTS)
    for name, package, description in (("opencti_export", "stix2", "STIX 2.1 bundle export; exchange extra"),
                                        ("workspace_encryption", "cryptography", "Opt-in encrypted workspace; security extra"),
                                        ("team_api", "fastapi", "Optional loopback API; team extra and separate jobs worker"),
                                        ("pdf_documents", "pypdf", "PDF text extraction; documents extra"),
                                        ("word_documents", "docx", "DOCX paragraphs and tables; documents extra"),
                                        ("image_ocr", "pytesseract", "Image OCR; documents extra and Tesseract language packs")):
        ready = importlib.util.find_spec(package) is not None
        if name == "image_ocr":
            ready = ready and bool(shutil.which("tesseract"))
        result.append({"name": name, "inputs": [], "mode": "local utility", "setup": "ready" if ready else "missing dependency",
                       "keys": [], "description": description, "validation": "local fixtures; OCR requires installed languages"})
    return result


def credential_names():
    return list(KEY_NAMES)
