"""Optional native phone workbench. Keys stay in memory; collection runs off the UI thread."""

import asyncio
import os
import re
import uuid
from pathlib import Path
from urllib.parse import urlsplit

from pydantic import ValidationError

from .core.audit import AuditLog
from .core.correlator import correlate
from .core.schema import Entity, Finding, ModuleResult, QueryContext, RunReport, normalize
from .phone_workflow import PhoneOutcome, PhoneRequest, run_phone, summarize_phone
from .report import write_report

try:
    from PySide6.QtCore import Qt, QThread, QUrl, Signal
    from PySide6.QtGui import QDesktopServices, QFont
    from PySide6.QtWidgets import (
        QAbstractItemView,
        QApplication,
        QCheckBox,
        QFormLayout,
        QFrame,
        QHBoxLayout,
        QHeaderView,
        QInputDialog,
        QLabel,
        QLineEdit,
        QMainWindow,
        QMessageBox,
        QPlainTextEdit,
        QProgressBar,
        QPushButton,
        QScrollArea,
        QSpinBox,
        QTableWidget,
        QTableWidgetItem,
        QTabWidget,
        QToolButton,
        QVBoxLayout,
        QWidget,
    )
except ImportError:
    QT_AVAILABLE = False
else:
    QT_AVAILABLE = True


POLICY_TEXT = (
    "Collect only public or explicitly authorized data. Review provider terms; respect rate "
    "limits and robots.txt. No login/CAPTCHA/access-control bypass, private-profile scraping, "
    "raw breach dumps, live tracking, or bulk person enumeration. Identifiers are leads; "
    "ownership is unknown. Queries are audited locally; reports may contain personal data. "
    "This records your statement, not verified consent."
)

STYLE = """
QMainWindow, QWidget { background: #101923; color: #e5edf4; font-family: 'Segoe UI'; font-size: 13px; }
QFrame#header { border-bottom: 1px solid #293b4b; }
QLabel#eyebrow { color: #77d5c2; font-size: 11px; font-weight: 700; }
QLabel#title { font-size: 25px; font-weight: 650; }
QLabel#muted { color: #9fb0c0; }
QLabel#section { font-size: 16px; font-weight: 650; }
QLabel#scope { color: #90e1ce; background: #193631; padding: 10px; border-radius: 6px; }
QLabel#error { color: #ffb8a8; padding: 5px 0px; }
QLabel#number { font-size: 23px; font-weight: 650; }
QLabel#notice { color: #dfca9e; background: #302e27; padding: 10px; border-radius: 6px; }
QLineEdit, QPlainTextEdit, QSpinBox { background: #172431; border: 1px solid #364c60; border-radius: 5px; padding: 8px; selection-background-color: #247d71; }
QLineEdit:focus, QPlainTextEdit:focus { border-color: #6fd6bc; }
QLineEdit:disabled, QPlainTextEdit:disabled { color: #6e8294; border-color: #263747; }
QCheckBox { spacing: 8px; padding: 4px 0px; }
QCheckBox::indicator { width: 16px; height: 16px; }
QPushButton { background: #213344; border: 1px solid #3c5265; border-radius: 5px; padding: 9px 13px; font-weight: 600; }
QPushButton:hover { background: #2d465b; border-color: #75b7b0; }
QPushButton#primary { background: #79d9bd; color: #102922; border-color: #79d9bd; }
QPushButton#primary:hover { background: #a3edd5; }
QPushButton:disabled { background: #1c2a36; color: #667b8e; border-color: #293d4d; }
QToolButton { border: none; color: #a5dddb; padding: 5px 0px; text-align: left; }
QTabWidget::pane { border: 1px solid #314454; border-radius: 5px; }
QTabBar::tab { background: #182734; color: #a3b5c5; padding: 10px 13px; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: #d7fff2; border-bottom: 2px solid #79d9bd; }
QTableWidget { background: #14212d; gridline-color: #293e4f; border: none; selection-background-color: #245750; selection-color: #f2fffb; }
QTableWidget::item { padding: 7px; }
QHeaderView::section { background: #1c2e3d; color: #abc1d2; padding: 8px; border: none; font-size: 11px; font-weight: 600; }
QScrollArea { border: none; }
QScrollBar:vertical { background: #14212d; width: 9px; }
QScrollBar::handle:vertical { background: #3b5367; border-radius: 4px; min-height: 25px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
QProgressBar { border: none; background: #1b2d3b; max-height: 3px; }
QProgressBar::chunk { background: #79d9bd; }
"""


def synthetic_outcome(out_dir: Path) -> PhoneOutcome:
    """Produce a clearly synthetic phone report without any network requests or real query."""
    context = QueryContext(query="+12025550123", input_type="phone", purpose="Synthetic desktop demo",
                           authorized=True)
    findings = []
    for address, page in (("hello@example.org", "contact"), ("press@example.org", "press")):
        url = f"https://example.org/{page}"
        for relation, kind, value in (("public_number_mention", "url", url),
                                     ("email_near_number", "email", address)):
            findings.append(Finding(source="synthetic_fixture", subject=context.entity,
                                    relation=relation, object=Entity(kind=kind, value=value),
                                    evidence_url=url, legal_basis="Synthetic fixture; no collection",
                                    metadata={"synthetic": True, "ownership_verified": False,
                                              "excerpt": f"Fictional example: +1 202-555-0123 · {address}"}))
    report = RunReport(run_id=f"synthetic-phone-{uuid.uuid4().hex[:10]}", context=context,
                       results=[ModuleResult(module="synthetic_fixture", status="ok", findings=findings,
                                             message="Synthetic examples only. No live source was queried.")],
                       graph=correlate(findings),
                       notes=["SYNTHETIC DEMO: fictional number and example.org email addresses.",
                              "No network requests were made. No identity or ownership is established."])
    return PhoneOutcome(report, write_report(report, out_dir / report.run_id), summarize_phone(report))


if QT_AVAILABLE:

    def label(text: str, name: str = "", *, wrap: bool = True) -> QLabel:
        result = QLabel(text)
        result.setTextFormat(Qt.TextFormat.PlainText)
        result.setWordWrap(wrap)
        if name:
            result.setObjectName(name)
        return result


    def table(headers: list[str]) -> QTableWidget:
        widget = QTableWidget(0, len(headers))
        widget.setHorizontalHeaderLabels(headers)
        widget.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        widget.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        widget.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        widget.setAlternatingRowColors(False)
        widget.verticalHeader().setVisible(False)
        widget.verticalHeader().setDefaultSectionSize(38)
        widget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        widget.setWordWrap(False)
        return widget


    class PhoneWorker(QThread):
        completed = Signal(object)
        failed = Signal(str)

        def __init__(self, request: PhoneRequest | None, state_dir: Path, out_dir: Path,
                     api_key: str | None = None, *, demo: bool = False, parent=None):
            super().__init__(parent)
            self.request = request
            self.state_dir = state_dir
            self.out_dir = out_dir
            self.api_key = api_key
            self.demo = demo

        def run(self):
            try:
                if self.demo:
                    outcome = synthetic_outcome(self.out_dir)
                else:
                    if self.request is None:
                        raise ValueError("A validated request is required")
                    # Validation precedes consent and audit creation, even for non-UI callers.
                    self.request.context()
                    audit = AuditLog(self.state_dir)
                    if not audit.consented():
                        audit.accept_policy()
                    outcome = asyncio.run(run_phone(self.request, self.state_dir, self.out_dir,
                                                    api_key=self.api_key))
                self.completed.emit(outcome)
            except Exception as exc:
                # Provider/transport exceptions can contain request headers. Do not echo them.
                self.failed.emit(f"The run could not complete ({type(exc).__name__}). "
                                 "Check input, source availability, and writable state/report folders.")
            finally:
                self.api_key = None


    class PhoneWindow(QMainWindow):
        """One-number workbench with an explicit collection scope for each run."""

        def __init__(self, state_dir: Path, out_dir: Path):
            super().__init__()
            self.state_dir = Path(state_dir)
            self.out_dir = Path(out_dir)
            self._worker = None
            self._outcome = None
            self._lead_findings = []
            self.setWindowTitle("OSINT Framework · Phone workbench")
            self.resize(1220, 900)
            self.setMinimumSize(1000, 700)
            self.setStyleSheet(STYLE)
            self._build()
            self._update_scope()

        def _build(self):
            root = QWidget()
            self.setCentralWidget(root)
            layout = QVBoxLayout(root)
            layout.setContentsMargins(26, 18, 26, 16)
            layout.setSpacing(18)
            header = QFrame()
            header.setObjectName("header")
            header_layout = QVBoxLayout(header)
            header_layout.setContentsMargins(0, 0, 0, 18)
            header_layout.addWidget(label("OSINT CORRELATION FRAMEWORK / LOCAL WORKSPACE", "eyebrow"))
            header_layout.addWidget(label("Phone workbench", "title"))
            header_layout.addWidget(label("Find public mentions and nearby email leads. Every match keeps its source.", "muted"))
            layout.addWidget(header)
            body = QHBoxLayout()
            body.setSpacing(26)
            layout.addLayout(body, 1)

            left_scroll = QScrollArea()
            left_scroll.setWidgetResizable(True)
            left_scroll.setMinimumWidth(350)
            left_scroll.setMaximumWidth(400)
            self.form = QWidget()
            controls = QVBoxLayout(self.form)
            controls.setContentsMargins(0, 0, 10, 0)
            controls.setSpacing(10)
            controls.addWidget(label("1  Choose a number", "section"))
            self.number_input = QLineEdit()
            self.number_input.setPlaceholderText("Paste a phone number, e.g. +1 202-555-0123")
            self.number_input.setAccessibleName("Phone number")
            self.number_input.setMaxLength(80)
            controls.addWidget(self.number_input)
            self.region_input = QLineEdit()
            self.region_input.setPlaceholderText("Country for national format: IN, US, GB (optional)")
            self.region_input.setMaxLength(2)
            self.region_input.setAccessibleName("Country code for national number")
            controls.addWidget(self.region_input)
            self.purpose_input = QLineEdit()
            self.purpose_input.setPlaceholderText("Purpose or case ID (at least 8 characters)")
            self.purpose_input.setMaxLength(500)
            self.purpose_input.setAccessibleName("Purpose or case ID")
            controls.addWidget(self.purpose_input)
            controls.addSpacing(5)
            controls.addWidget(label("2  Select sources", "section"))
            controls.addWidget(label("Numbering-plan metadata is always checked locally.", "muted"))
            self.search_toggle = QCheckBox("Search indexed public pages with Brave")
            self.search_toggle.toggled.connect(self._update_scope)
            controls.addWidget(self.search_toggle)
            self.api_key_input = QLineEdit()
            self.api_key_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.api_key_input.setPlaceholderText("Optional Brave API key · kept in memory")
            self.api_key_input.setAccessibleName("Session-only Brave API key")
            self.api_key_input.setMaxLength(500)
            self.api_key_input.setClearButtonEnabled(True)
            self.api_key_input.textChanged.connect(self._update_scope)
            controls.addWidget(self.api_key_input)
            self.key_status = label("", "muted")
            controls.addWidget(self.key_status)

            self.pages_toggle = QToolButton()
            self.pages_toggle.setText("Approved public pages (optional)")
            self.pages_toggle.setCheckable(True)
            self.pages_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
            self.pages_toggle.setArrowType(Qt.ArrowType.RightArrow)
            controls.addWidget(self.pages_toggle)
            self.pages_panel = QWidget()
            page_controls = QFormLayout(self.pages_panel)
            page_controls.setContentsMargins(0, 0, 0, 0)
            page_controls.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapAllRows)
            self.page_urls_input = QPlainTextEdit()
            self.page_urls_input.setPlaceholderText("https://example.org/contact\nOne approved HTTPS URL per line")
            self.page_urls_input.setMaximumHeight(80)
            self.page_urls_input.setAccessibleName("Approved page URLs")
            self.page_urls_input.textChanged.connect(self._update_scope)
            page_controls.addRow("Page URLs", self.page_urls_input)
            self.hosts_input = QLineEdit()
            self.hosts_input.setPlaceholderText("example.org, www.example.org")
            page_controls.addRow("Exact allowed hostnames", self.hosts_input)
            self.terms_input = QLineEdit()
            self.terms_input.setPlaceholderText("https://example.org/terms")
            page_controls.addRow("Permission / reviewed terms URL", self.terms_input)
            self.max_pages_input = QSpinBox()
            self.max_pages_input.setRange(1, 20)
            self.max_pages_input.setValue(3)
            page_controls.addRow("Maximum pages per run", self.max_pages_input)
            self.pages_panel.setVisible(False)
            self.pages_toggle.toggled.connect(self._toggle_pages)
            controls.addWidget(self.pages_panel)

            self.scope_label = label("", "scope")
            controls.addWidget(self.scope_label)
            self.authorized_check = QCheckBox("This run is authorized; I accept the policy below.")
            self.authorized_check.setChecked(False)
            controls.addWidget(self.authorized_check)
            policy = label(POLICY_TEXT, "muted")
            policy.setStyleSheet("font-size: 11px;")
            controls.addWidget(policy)
            self.error_label = label("", "error")
            self.error_label.hide()
            controls.addWidget(self.error_label)
            self.run_button = QPushButton("Find information")
            self.run_button.setObjectName("primary")
            self.run_button.clicked.connect(self._start_run)
            controls.addWidget(self.run_button)
            self.demo_button = QPushButton("Try offline demo")
            self.demo_button.clicked.connect(self._start_demo)
            controls.addWidget(self.demo_button)
            controls.addWidget(label("The demo uses fictional data and needs no API key.", "muted"))
            controls.addStretch()
            left_scroll.setWidget(self.form)
            body.addWidget(left_scroll)

            results = QVBoxLayout()
            results.setSpacing(12)
            body.addLayout(results, 1)
            self.result_badge = label("READY / NO QUERY SENT", "eyebrow")
            results.addWidget(self.result_badge)
            self.result_number = label("Your evidence workspace", "number")
            self.result_number.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            results.addWidget(self.result_number)
            self.result_stats = label("Start with a number, or explore the offline demo.", "muted")
            results.addWidget(self.result_stats)
            self.association_note = label("Email leads mean nearby public text. Subscriber and email ownership are not verified.", "notice")
            results.addWidget(self.association_note)
            self.progress = QProgressBar()
            self.progress.setRange(0, 0)
            self.progress.setTextVisible(False)
            self.progress.hide()
            results.addWidget(self.progress)

            self.tabs = QTabWidget()
            results.addWidget(self.tabs, 1)
            lead_panel = QWidget()
            lead_layout = QVBoxLayout(lead_panel)
            lead_layout.setContentsMargins(12, 12, 12, 12)
            self.leads_empty = label("Email leads appear here when selected sources contain a matching number and a nearby address.", "muted")
            lead_layout.addWidget(self.leads_empty)
            self.lead_table = table(["EMAIL LEAD", "SOURCE", "EVIDENCE PAGE"])
            self.lead_table.itemSelectionChanged.connect(self._select_lead)
            lead_layout.addWidget(self.lead_table, 1)
            self.excerpt = QPlainTextEdit()
            self.excerpt.setReadOnly(True)
            self.excerpt.setPlaceholderText("Select a lead to inspect its source excerpt and observation time.")
            self.excerpt.setMaximumHeight(135)
            lead_layout.addWidget(self.excerpt)
            self.open_source_button = QPushButton("Open selected source ↗")
            self.open_source_button.setEnabled(False)
            self.open_source_button.clicked.connect(self._open_selected_source)
            lead_layout.addWidget(self.open_source_button)
            self.tabs.addTab(lead_panel, "Email leads")

            metadata_panel = QWidget()
            metadata_layout = QVBoxLayout(metadata_panel)
            metadata_layout.addWidget(label("Local prefix data cannot establish current carrier, subscriber, assignment, or live location.", "muted"))
            self.metadata_table = table(["NUMBERING-PLAN FIELD", "VALUE"])
            metadata_layout.addWidget(self.metadata_table)
            self.tabs.addTab(metadata_panel, "Number details")
            self.status_table = table(["SOURCE", "STATUS", "DETAIL"])
            self.tabs.addTab(self.status_table, "Source status")
            pages_panel = QWidget()
            pages_layout = QVBoxLayout(pages_panel)
            self.pages_table = table(["PUBLIC MENTION URL", "SOURCE"])
            pages_layout.addWidget(self.pages_table)
            self.open_page_button = QPushButton("Open selected page ↗")
            self.open_page_button.setEnabled(False)
            self.open_page_button.clicked.connect(self._open_selected_page)
            self.pages_table.itemSelectionChanged.connect(
                lambda: self.open_page_button.setEnabled(self.pages_table.currentRow() >= 0))
            pages_layout.addWidget(self.open_page_button)
            self.tabs.addTab(pages_panel, "Public pages")

            results.addWidget(label("Manual search links open in your browser and send this number to the chosen provider.", "muted"))
            self.manual_links = QHBoxLayout()
            results.addLayout(self.manual_links)
            self.report_button = QPushButton("Open saved HTML report ↗")
            self.report_button.setEnabled(False)
            self.report_button.clicked.connect(self._open_report)
            results.addWidget(self.report_button)
            self.storage_label = label("Reports and the audit trail are saved on this computer.", "muted")
            results.addWidget(self.storage_label)

        def _toggle_pages(self, expanded: bool):
            self.pages_panel.setVisible(expanded)
            self.pages_toggle.setArrowType(Qt.ArrowType.DownArrow if expanded else Qt.ArrowType.RightArrow)

        def _update_scope(self):
            if not hasattr(self, "scope_label"):
                return
            key_ready = bool(self.api_key_input.text().strip() or os.environ.get("BRAVE_SEARCH_API_KEY"))
            if self.api_key_input.text().strip():
                self.key_status.setText("Brave key supplied for this session; never written to reports.")
            elif os.environ.get("BRAVE_SEARCH_API_KEY"):
                self.key_status.setText("Brave key available from the environment.")
            else:
                self.key_status.setText("No Brave key configured. Local checks and manual search links are available.")
            modes = []
            if self.search_toggle.isChecked():
                modes.append("Brave web search" if key_ready else "Brave web search · key needed")
            if self.page_urls_input.toPlainText().strip():
                modes.append("approved page collection")
            self.scope_label.setText("Internet selected: " + " + ".join(modes) if modes else
                                     "Local check only · no internet lookup")

        def build_request(self) -> PhoneRequest:
            """Validate the complete run before starting a worker or recording consent."""
            if not self.authorized_check.isChecked():
                raise ValueError("Confirm authorization and the policy for this run.")
            request = PhoneRequest(
                number=self.number_input.text().strip(), region=self.region_input.text().strip() or None,
                purpose=self.purpose_input.text().strip(), authorized=True,
                search_web=self.search_toggle.isChecked(),
                seed_urls=[value.strip() for value in self.page_urls_input.toPlainText().splitlines() if value.strip()],
                allowed_hosts=[value for value in re.split(r"[\s,]+", self.hosts_input.text().strip()) if value],
                terms_url=self.terms_input.text().strip() or None,
                max_pages=self.max_pages_input.value(),
            )
            context = request.context()
            if request.search_web and not (self.api_key_input.text().strip() or os.environ.get("BRAVE_SEARCH_API_KEY")):
                raise ValueError("Add a Brave API key, or turn off indexed web search for this run.")
            if context.seed_urls:
                if not context.terms_url:
                    raise ValueError("Add a permission or reviewed terms URL for the approved pages.")
                from .modules.webpage import _page_url
                for url in context.seed_urls:
                    if not _page_url(url) or urlsplit(url).hostname not in context.allowed_hosts:
                        raise ValueError("Each approved page needs HTTPS and its exact hostname in the allowlist.")
            return request

        def _show_error(self, message: str):
            self.error_label.setText(message)
            self.error_label.show()

        def _start_run(self):
            if self._worker is not None:
                return
            try:
                request = self.build_request()
            except ValidationError as exc:
                self._show_error("Invalid input: " + exc.errors(include_input=False)[0]["msg"])
                return
            except ValueError as exc:
                self._show_error(str(exc))
                return
            self._begin(PhoneWorker(request, self.state_dir, self.out_dir,
                                    api_key=self.api_key_input.text().strip() or None, parent=self))

        def _start_demo(self):
            if self._worker is None:
                self._begin(PhoneWorker(None, self.state_dir, self.out_dir, demo=True, parent=self))

        def _begin(self, worker: PhoneWorker):
            self._worker = worker
            self._outcome = None
            self.error_label.hide()
            self.form.setEnabled(False)
            self.progress.show()
            self.report_button.setEnabled(False)
            self.result_badge.setText("RUNNING / SYNTHETIC DEMO" if worker.demo else "RUNNING / SELECTED SOURCES")
            self.result_number.setText("Collecting evidence…")
            self.result_stats.setText("The window stays responsive while sources complete.")
            self.lead_table.setRowCount(0)
            self.pages_table.setRowCount(0)
            self.status_table.setRowCount(0)
            self.metadata_table.setRowCount(0)
            self._lead_findings = []
            self.excerpt.clear()
            self.leads_empty.setText("Waiting for the selected sources.")
            self.leads_empty.show()
            self.open_source_button.setEnabled(False)
            self.open_page_button.setEnabled(False)
            self._clear_manual_links()
            worker.completed.connect(self.render_outcome)
            worker.failed.connect(self._run_failed)
            worker.finished.connect(self._finish_run)
            worker.start()

        def _finish_run(self):
            self.progress.hide()
            self.form.setEnabled(True)
            if self._worker is not None:
                self._worker.deleteLater()
            self._worker = None

        def _run_failed(self, message: str):
            self._show_error(message)
            self.result_badge.setText("RUN FAILED / RESULTS UNAVAILABLE")
            self.result_number.setText("The collection did not complete")
            self.result_stats.setText("Review the error and retry when the source is available.")
            self.leads_empty.setText("No conclusion can be drawn from an incomplete run.")

        @staticmethod
        def _fill_table(widget: QTableWidget, rows: list[list[str]]):
            widget.setRowCount(len(rows))
            for row_index, values in enumerate(rows):
                for column_index, value in enumerate(values):
                    item = QTableWidgetItem(str(value))
                    item.setToolTip(str(value))
                    widget.setItem(row_index, column_index, item)

        def render_outcome(self, outcome: PhoneOutcome):
            self._outcome = outcome
            summary = outcome.summary
            synthetic = all(result.module == "synthetic_fixture" for result in outcome.report.results)
            internet = any(result.module in {"phone_search", "phone_pages"} for result in outcome.report.results)
            mode = "SYNTHETIC DEMO / NO INTERNET" if synthetic else "INTERNET SOURCES SELECTED" if internet else "LOCAL ONLY / NO INTERNET"
            self.result_badge.setText(mode)
            self.result_number.setText(summary["number"])
            self.result_stats.setText(f"{len(summary['emails'])} email leads · {len(summary['pages'])} public pages · "
                                      f"{len(outcome.report.results)} source(s)")
            findings = [finding for result in outcome.report.results for finding in result.findings]
            self._lead_findings = [finding for finding in findings if finding.relation == "email_near_number"]
            self._fill_table(self.lead_table, [[f.object.value, f.source, f.evidence_url] for f in self._lead_findings])
            self.leads_empty.setVisible(not self._lead_findings)
            self.leads_empty.setText("No email leads found from the selected sources. This does not mean no email exists." +
                                      (" Only local numbering data was checked." if not internet and not synthetic else ""))
            self.association_note.setText("SYNTHETIC EXAMPLES: fictional addresses, no live lookup. Ownership is not verified." if synthetic else
                                          summary.get("association_note", "Email leads are unverified public co-occurrences."))
            metadata_rows = [[key.replace("_", " ").capitalize(), ", ".join(map(str, value)) if isinstance(value, list) else str(value)]
                             for key, value in summary.get("metadata", {}).items()]
            if not metadata_rows:
                metadata_rows = [["Numbering-plan data", "No local metadata in this synthetic demo" if synthetic else "Unavailable; see source status"]]
            self._fill_table(self.metadata_table, metadata_rows)
            self._fill_table(self.status_table, [[row["source"], row["status"].replace("_", " "), row.get("message") or "Completed"]
                                                 for row in summary["statuses"]])
            self._fill_table(self.pages_table, [[f.object.value, f.source] for f in findings if f.relation == "public_number_mention"])
            self._clear_manual_links()
            for link in summary.get("manual_search_links", []):
                button = QPushButton(link["label"].split(" · ")[0] + " ↗")
                button.setToolTip("Open a browser search for this number")
                button.clicked.connect(lambda checked=False, url=link["url"]: self._open_url(url))
                self.manual_links.addWidget(button)
            self.manual_links.addStretch()
            self.report_button.setEnabled(bool(outcome.paths.get("html")))
            self.storage_label.setText("Saved locally: " + str(outcome.paths.get("html", self.out_dir).parent.resolve()))
            if self._lead_findings:
                self.lead_table.selectRow(0)

        def _clear_manual_links(self):
            while self.manual_links.count():
                item = self.manual_links.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

        def _select_lead(self):
            row = self.lead_table.currentRow()
            valid = 0 <= row < len(self._lead_findings)
            self.open_source_button.setEnabled(valid)
            if not valid:
                self.excerpt.clear()
                return
            finding = self._lead_findings[row]
            self.excerpt.setPlainText(f"{finding.metadata.get('excerpt', 'No source excerpt available.')}\n\n"
                                      f"Observed: {finding.observed_at.isoformat(timespec='seconds')}\n"
                                      f"Evidence: {finding.evidence_url}\nOwnership: unverified")

        def _open_selected_source(self):
            row = self.lead_table.currentRow()
            if 0 <= row < len(self._lead_findings):
                self._open_url(self._lead_findings[row].evidence_url)

        def _open_selected_page(self):
            item = self.pages_table.item(self.pages_table.currentRow(), 0)
            if item:
                self._open_url(item.text())

        @staticmethod
        def _open_url(url: str):
            try:
                safe = normalize("url", url)
            except (ValueError, TypeError):
                return
            QDesktopServices.openUrl(QUrl(safe))

        def _open_report(self):
            if self._outcome and self._outcome.paths.get("html"):
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._outcome.paths["html"].resolve())))

        def closeEvent(self, event):  # noqa: N802 - Qt override
            if self._worker is not None:
                self._show_error("A collection is running. Wait for it to finish before closing the window.")
                event.ignore()
                return
            self.api_key_input.clear()
            event.accept()


def launch(state_dir: Path, out_dir: Path, *, phone_only=False) -> int:
    """Launch the optional desktop without making Qt a dependency of the CLI."""
    if not QT_AVAILABLE:
        raise RuntimeError('The desktop needs PySide6. Install it with: python -m pip install ".[desktop]"')
    app = QApplication.instance() or QApplication([])
    app.setApplicationName("OSINT Investigation Workbench")
    app.setFont(QFont("Segoe UI", 10))
    from .core.vault import Vault
    if (Path(state_dir) / "vault.json").is_file():
        while True:
            try:
                Vault(state_dir)
                break
            except ValueError:
                password, accepted = QInputDialog.getText(None, "Unlock workspace",
                    "Workspace passphrase", QLineEdit.EchoMode.Password)
                if not accepted:
                    return 0
                try:
                    Vault.unlock_workspace(state_dir, password)
                except ValueError as exc:
                    QMessageBox.warning(None, "Workspace remains locked", str(exc))
                finally:
                    password = ""
    if phone_only:
        window = PhoneWindow(state_dir, out_dir)
    else:
        from .workbench import WorkbenchWindow

        window = WorkbenchWindow(state_dir, out_dir)
    window.show()
    return app.exec()


def main() -> int:
    """Entry point for the optional native launcher."""
    return launch(Path.cwd() / ".osint-state", Path.cwd() / "reports")


if __name__ == "__main__":
    raise SystemExit(main())
