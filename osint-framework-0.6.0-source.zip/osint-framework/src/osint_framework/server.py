"""ASGI factory for explicitly configured container deployment."""

import os
from pathlib import Path

from .team import create_app


def application():
    hosts = [value.strip() for value in os.environ.get("OSINT_TRUSTED_HOSTS", "localhost,127.0.0.1").split(",")]
    if not hosts or any(not host or "*" in host for host in hosts):
        raise ValueError("Supply exact trusted hostnames; wildcard hosts are not supported")
    sources = os.environ.get("OSINT_ALLOWED_SOURCES", "phone_local,dns,email_dns,rdap,crtsh,ripe,internetdb,commoncrawl")
    return create_app(Path(os.environ.get("OSINT_STATE", "/data/state")), trusted_hosts=hosts,
                      allowed_sources=[name.strip() for name in sources.split(",")])
