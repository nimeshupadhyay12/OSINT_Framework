"""Portable evidence bundles, encrypted signing keys, and explicit WARC exports."""

import base64
import hashlib
import io
import json
import os
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

from .core.schema import RunReport, normalize
from .core.vault import Vault

MAX_BUNDLE = 200_000_000


def signing_modules():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    except ImportError as exc:
        raise ValueError("Install the security extra for evidence signatures") from exc
    return serialization, Ed25519PrivateKey


def new_signing_key(path, password):
    serialization, Ed25519PrivateKey = signing_modules()
    if len(password) < 12:
        raise ValueError("Signing key passphrase requires at least 12 characters")
    path = Path(path)
    public = path.with_suffix(".pub")
    if path.exists() or public.exists():
        raise ValueError("Key destination already exists; existing keys are never overwritten")
    private = Ed25519PrivateKey.generate()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(private.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
            serialization.BestAvailableEncryption(password.encode())))
    with public.open("xb") as stream:
        stream.write(private.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    return public


def read_limited(path, limit=30_000_000):
    with Path(path).open("rb") as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("File exceeds its input budget")
    return raw


def load_report(path, state):
    return RunReport.model_validate_json(Vault(state).read_bytes(path, "report-file"))


def sign_bytes(raw, key, password):
    serialization, Ed25519PrivateKey = signing_modules()
    private = serialization.load_pem_private_key(read_limited(key, 16384), password=password.encode())
    if not isinstance(private, Ed25519PrivateKey):
        raise ValueError("Signing requires an Ed25519 private key")
    return private.sign(raw)


def verify_signature(raw, signature, public_key):
    serialization, _ = signing_modules()
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    key = serialization.load_pem_public_key(read_limited(public_key, 16384))
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("Verification requires a trusted Ed25519 public key")
    try:
        key.verify(signature, raw)
    except InvalidSignature:
        raise ValueError("Evidence signature does not match the trusted key") from None


def artifact_bytes(artifact, vault, root):
    path = Path(artifact["path"]).resolve()
    root = Path(root).resolve()
    if not path.is_relative_to(root) or path == root:
        raise ValueError("Artifact path is outside the explicitly selected evidence root")
    raw = vault.read_bytes(path)
    if hashlib.sha256(raw).hexdigest() != artifact.get("sha256") or len(raw) != artifact.get("bytes"):
        raise ValueError("Stored artifact does not match its report digest or size")
    return raw


def bundle(report, out, key, password, state, evidence_root):
    vault = Vault(state)
    portable = report.model_copy(deep=True)
    files, total = {}, 0
    for artifact in portable.artifacts:
        raw = artifact_bytes(artifact, vault, evidence_root)
        name = "evidence/" + hashlib.sha256(raw).hexdigest() + ".bin"
        if name not in files:
            total += len(raw)
            if total > MAX_BUNDLE or len(files) >= 998:
                raise ValueError("Evidence bundle exceeds 200 MB or 998 artifact limit")
            files[name] = raw
        artifact.update(path=name, encrypted=False)
    files["report.json"] = portable.bounded_json().encode()
    if total + len(files["report.json"]) > MAX_BUNDLE:
        raise ValueError("Evidence bundle exceeds 200 MB")
    manifest = json.dumps({"format": "osint-evidence-bundle-v1", "run_id": report.run_id,
        "files": {name: {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)} for name, raw in sorted(files.items())}}, sort_keys=True, separators=(",", ":")).encode()
    signature = sign_bytes(manifest, key, password)
    with zipfile.ZipFile(out, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in files.items():
            archive.writestr(name, raw)
        archive.writestr("manifest.json", manifest)
        archive.writestr("manifest.sig", base64.b64encode(signature))


def verify_bundle(path, public_key):
    try:
        with zipfile.ZipFile(path) as archive:
            entries = archive.infolist()
            names = [entry.filename for entry in entries]
            if len(names) > 1001 or len(set(names)) != len(names) or sum(entry.file_size for entry in entries) > MAX_BUNDLE + 1_000_000:
                raise ValueError("Invalid bundle size or duplicate entries")
            raw = archive.read("manifest.json")
            verify_signature(raw, base64.b64decode(archive.read("manifest.sig"), validate=True), public_key)
            manifest = json.loads(raw)
            if manifest.get("format") != "osint-evidence-bundle-v1" or set(names) != set(manifest["files"]) | {"manifest.json", "manifest.sig"}:
                raise ValueError("Invalid bundle manifest or unsigned extra file")
            if "report.json" not in manifest["files"]:
                raise ValueError("Bundle report is missing")
            for name, expected in manifest["files"].items():
                # No archive extraction is performed, even after validation.
                data = archive.read(name)
                if hashlib.sha256(data).hexdigest() != expected["sha256"] or len(data) != expected["bytes"]:
                    raise ValueError("Evidence bundle content was changed")
            return {"verified": True, "run_id": manifest["run_id"], "files": len(manifest["files"]),
                    "meaning": "Bytes signed by the supplied key; source truth and signing time are not independently certified."}
    except (zipfile.BadZipFile, KeyError, TypeError) as exc:
        raise ValueError("Malformed evidence bundle") from exc


def export_warc(report, out, state, evidence_root):
    try:
        from warcio.warcwriter import WARCWriter
    except ImportError as exc:
        raise ValueError("Install the evidence extra for WARC export") from exc
    vault = Vault(state)
    out = Path(out)
    if out.exists():
        raise FileExistsError("WARC destination already exists")
    if len(report.artifacts) > 998:
        raise ValueError("WARC exceeds the 998 artifact budget")
    artifacts, total = [], 0
    for original in report.artifacts:
        artifact = dict(original)
        note = "Preserved bytes only; original HTTP headers were not captured."
        if "original_name" in artifact:
            artifact.setdefault("url", "urn:sha256:" + artifact["sha256"])
            if "captured_at" not in artifact:
                artifact["captured_at"] = report.created_at.isoformat()
                note += " Legacy document: date is report creation, not independently verified capture time."
        try:
            uri = artifact["url"]
            if uri != "urn:sha256:" + artifact["sha256"]:
                normalize("url", uri)
            captured = datetime.fromisoformat(artifact["captured_at"].replace("Z", "+00:00"))
            if captured.tzinfo is None:
                raise ValueError("Artifact date requires a timezone")
            raw = artifact_bytes(artifact, vault, evidence_root)
        except (KeyError, TypeError, AttributeError) as exc:
            raise ValueError("Artifact lacks a valid locator, timestamp, digest or size") from exc
        total += len(raw)
        if total > MAX_BUNDLE:
            raise ValueError("WARC exceeds the 200 MB artifact budget")
        artifacts.append((artifact, note))
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=out.parent, prefix=".warc-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            writer = WARCWriter(stream, gzip=True)
            for artifact, note in artifacts:
                raw = artifact_bytes(artifact, vault, evidence_root)
                record = writer.create_warc_record(artifact["url"], "resource", payload=io.BytesIO(raw),
                    warc_content_type="application/octet-stream", warc_headers_dict={"WARC-Date": artifact["captured_at"],
                        "WARC-OSINT-Note": note})
                writer.write_record(record)
            stream.flush()
            os.fsync(stream.fileno())
        # Atomic publication without replacing an existing destination.
        os.link(temporary, out)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
