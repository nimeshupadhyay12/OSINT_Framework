"""Optional fixed-argument passive Subfinder runner; no shell or auto-installation."""

import asyncio
import os
import shutil
import tempfile
from pathlib import Path

from ..core.http import SourceError, SourceSkipped
from ..core.schema import ModuleSpec
from .imports import parse_import
from .locks import verify_binary


class SubfinderModule:
    spec = ModuleSpec(
        name="subfinder", input_types=["domain"], default_enabled=False,
        description="Installed Subfinder: passive crtsh source, 1 request/second, 1 minute budget",
        rate_limit_per_min=1, terms_url="https://github.com/projectdiscovery/subfinder",
    )

    async def run(self, context, http):
        executable = shutil.which("subfinder")
        if not executable:
            raise SourceSkipped("Subfinder is not installed on PATH; use import-results or install a reviewed release")
        try:
            digest = verify_binary(executable, os.environ.get("OSINT_SUBFINDER_SHA256", ""))
        except (ValueError, OSError) as exc:
            raise SourceSkipped(str(exc) if isinstance(exc, ValueError) else "Cannot verify tool binary") from None
        await http.limiter.acquire("tool:subfinder", 1)
        with tempfile.TemporaryDirectory(prefix="osint-subfinder-") as temp:
            directory = Path(temp)
            config = directory / "config.yaml"
            provider = directory / "providers.yaml"
            config.write_text("{}\n", encoding="utf-8")
            provider.write_text("{}\n", encoding="utf-8")
            command = [executable, "-d", context.query, "-s", "crtsh", "-rl", "1", "-timeout", "10",
                       "-max-time", "1", "-oJ", "-cs", "-silent", "-duc",
                       "-config", str(config), "-pc", str(provider)]
            permitted = {"PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "USERPROFILE", "HOME", "APPDATA", "LOCALAPPDATA"}
            env = {k: v for k, v in os.environ.items() if k.upper() in permitted}
            env.update({key: str(directory) for key in ("HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "XDG_CONFIG_HOME", "XDG_CACHE_HOME")})
            kwargs = {"creationflags": 0x08000000} if os.name == "nt" else {}
            process = await asyncio.create_subprocess_exec(
                *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                cwd=directory, env=env, **kwargs,
            )

            async def read_bounded(stream, limit):
                result = bytearray()
                while chunk := await stream.read(65536):
                    result.extend(chunk)
                    if len(result) > limit:
                        raise SourceError("Subfinder output exceeded its size budget")
                return bytes(result)

            try:
                async with asyncio.timeout(90):
                    output, _ = await asyncio.gather(read_bounded(process.stdout, 10_000_000),
                                                     read_bounded(process.stderr, 65536))
                    code = await process.wait()
                if code != 0:
                    raise SourceError(f"Subfinder exited with code {code}; raw output omitted")
            finally:
                if process.returncode is None:
                    process.kill()
                    await process.wait()
            if not output.strip():
                return []
            result_file = directory / "subfinder.jsonl"
            result_file.write_bytes(output)
            findings = parse_import("subfinder", result_file, context)
            for finding in findings:
                finding.metadata["collection_mode"] = "bounded_subfinder_passive_runner"
                finding.metadata["runner_sources"] = ["crtsh"]
                finding.metadata["runner_binary_sha256"] = digest
            return findings
