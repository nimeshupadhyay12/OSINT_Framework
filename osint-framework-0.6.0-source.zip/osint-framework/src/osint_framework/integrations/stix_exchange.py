"""Scoped STIX 2.1 file exchange for OpenCTI; no server writes or automatic enrichment."""

import ipaddress
import json
import uuid

from ..core.schema import Entity, Finding
from .imports import ImportValidationError, _decode, _provenance

REFERENCE = "https://docs.opencti.io/latest/deployment/connectors/"
TYPE_MAP = {"domain-name": "domain", "ipv4-addr": "ip", "ipv6-addr": "ip",
            "email-addr": "email", "url": "url", "user-account": "username"}


def _entity(obj):
    kind = TYPE_MAP.get(obj.get("type"))
    if not kind:
        return None
    value = obj.get("account_login" if kind == "username" else "value")
    return Entity(kind=kind, value=value) if isinstance(value, str) else None


def import_stix(text, context, base, now):
    bundle = _decode(text)
    if not isinstance(bundle, dict) or bundle.get("type") != "bundle" or not isinstance(bundle.get("objects"), list):
        raise ImportValidationError("OpenCTI import requires a STIX 2.1 bundle with objects")
    objects = {}
    for obj in bundle["objects"]:
        if not isinstance(obj, dict) or not isinstance(obj.get("id"), str) or not isinstance(obj.get("type"), str):
            raise ImportValidationError("STIX objects require an id and type")
        if obj["id"] in objects:
            raise ImportValidationError("Duplicate STIX object id; export one version of each object")
        if obj.get("spec_version", "2.1") != "2.1":
            raise ImportValidationError("Only STIX 2.1 is supported")
        objects[obj["id"]] = obj
    entities = {key: entity for key, obj in objects.items() if (entity := _entity(obj))}
    roots = {key for key, entity in entities.items() if entity == context.entity}
    definitions = [obj for obj in objects.values() if obj["type"] == "marking-definition"]

    def finding(obj, target, relation, evidence=None):
        meta, observed = _provenance({}, base, now)
        return Finding(source="import_opencti", subject=context.entity, object=target,
                       relation=relation, confidence="tentative", evidence_url=evidence or REFERENCE,
                       legal_basis="Operator-supplied STIX export; source permissions and claims are not independently verified.",
                       observed_at=observed, metadata={**meta, "stix_id": obj["id"],
                           "stix_type": obj["type"], "stix_created": obj.get("created"),
                           "stix_modified": obj.get("modified"), "stix_confidence": obj.get("confidence"),
                           "stix_object_marking_refs": obj.get("object_marking_refs", []),
                           "stix_marking_definitions": definitions,
                           "stix_granular_markings": obj.get("granular_markings", []),
                           "stix_labels": obj.get("labels", []), "stix_original": obj,
                           "adapter_contract": "STIX 2.1 exact observable and explicit relationship subset",
                           "evidence_url_is_locator": not bool(evidence),
                           "verification": "not_independently_verified"})

    for key in sorted(roots):
        yield finding(objects[key], entities[key], "stix_observable")
    for obj in objects.values():
        if obj["type"] == "relationship" and obj.get("source_ref") in roots and obj.get("target_ref") in entities:
            item = finding(obj, entities[obj["target_ref"]], "stix_relationship")
            item.metadata["stix_relationship_type"] = obj.get("relationship_type")
            # Preserve restrictions of the referenced observables too.
            refs = set(item.metadata["stix_object_marking_refs"])
            for reference in (obj["source_ref"], obj["target_ref"]):
                refs.update(objects[reference].get("object_marking_refs", []))
                refs.update(marking["marking_ref"] for marking in objects[reference].get("granular_markings", [])
                            if marking.get("marking_ref"))
            item.metadata["stix_object_marking_refs"] = sorted(refs)
            yield item
        elif obj["type"] == "note" and isinstance(obj.get("x_osint_finding"), dict):
            original = Finding.model_validate(obj["x_osint_finding"])
            if original.subject != context.entity:
                continue
            item = finding(obj, original.object, original.relation, original.evidence_url)
            refs = set(item.metadata["stix_object_marking_refs"])
            for reference in obj.get("object_refs", []):
                endpoint = objects.get(reference, {})
                refs.update(endpoint.get("object_marking_refs", []))
                refs.update(marking["marking_ref"] for marking in endpoint.get("granular_markings", [])
                            if marking.get("marking_ref"))
            item.metadata["stix_object_marking_refs"] = sorted(refs)
            item.metadata.update({"original_source": original.source,
                                  "original_observed_at": original.observed_at.isoformat(),
                                  "original_metadata": original.metadata})
            yield item


def export_stix(report):
    """Use standard SCOs and evidence Notes, preserving claims without identity inference."""
    try:
        import stix2
    except ImportError as exc:
        raise ValueError('Install STIX support with: python -m pip install ".[exchange]"') from exc
    identity = stix2.Identity(name="OSINT Correlation Framework", identity_class="system")
    objects, entities = [identity], {}
    findings = [f for result in report.results for f in result.findings]
    if any("misp_attribute" in finding.metadata for finding in findings):
        raise ValueError("MISP distribution and tags are not mapped to STIX markings; use MISP export to retain sharing context")
    definitions = {definition["id"]: definition for definition in report.stix_marking_definitions}
    markings = set()
    for finding in findings:
        for definition in finding.metadata.get("stix_marking_definitions", []):
            definitions[definition["id"]] = definition
        markings.update(finding.metadata.get("stix_object_marking_refs", []))
        for granular in finding.metadata.get("stix_granular_markings", []):
            if granular.get("marking_ref"):
                markings.add(granular["marking_ref"])
    if markings - definitions.keys():
        raise ValueError("STIX marking definitions are missing; export the complete source bundle first")
    objects.extend(stix2.parse(value, allow_custom=True) for value in definitions.values())
    constructors = {"domain": stix2.DomainName, "email": stix2.EmailAddress, "url": stix2.URL}
    for finding in findings:
        for entity in (finding.subject, finding.object):
            if entity.id in entities:
                continue
            if entity.kind in constructors:
                obj = constructors[entity.kind](value=entity.value)
            elif entity.kind == "ip":
                constructor = stix2.IPv4Address if ipaddress.ip_address(entity.value).version == 4 else stix2.IPv6Address
                obj = constructor(value=entity.value)
            elif entity.kind == "username":
                obj = stix2.UserAccount(account_login=entity.value)
            else:
                continue
            entities[entity.id] = obj.id
            objects.append(obj)
    for finding in findings:
        refs = list(dict.fromkeys(entities[e.id] for e in (finding.subject, finding.object) if e.id in entities))
        options = {"object_marking_refs": sorted(markings)} if markings else {}
        note = stix2.Note(created_by_ref=identity.id,
                          content=f"{finding.subject.kind}: {finding.subject.value}\n"
                                  f"{finding.relation}: {finding.object.value}\n"
                                  f"Source: {finding.source}; confidence: {finding.confidence}\n"
                                  f"Evidence: {finding.evidence_url}\nOwnership is not inferred.",
                          object_refs=refs or [identity.id], allow_custom=True,
                          x_osint_finding=finding.model_dump(mode="json"), **options)
        objects.append(note)
    grouping = stix2.Grouping(name=f"OSINT run {report.run_id}", context="unspecified",
                              object_refs=[obj.id for obj in objects if obj.type != "marking-definition"],
                              created_by_ref=identity.id, allow_custom=True,
                              x_osint_run_id=report.run_id,
                              **({"object_marking_refs": sorted(markings)} if markings else {}))
    objects.append(grouping)
    # Apply the strictest imported marking set to the complete exported bundle.
    values = [json.loads(obj.serialize()) for obj in objects]
    if markings:
        for obj in values:
            if obj["type"] != "marking-definition":
                obj["object_marking_refs"] = sorted(markings)
    payload = {"type": "bundle", "id": "bundle--" + str(uuid.uuid4()), "objects": values}
    stix2.parse(payload, allow_custom=True)
    return payload
