"""Bounded, evidence-preserving report imports. This module never executes tools.

Supported upstream shapes are documented in docs/tool-research.md. A positive
third-party result is a tentative lead, not an independently verified account.
"""

import csv
import hashlib
import io
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from osint_framework.core.schema import Entity, Finding, QueryContext, normalize, utcnow

MAX_IMPORT_BYTES = 10_000_000
SUPPORTED_IMPORTS = ("sherlock", "maigret", "subfinder", "canonical", "scrapy", "spiderfoot", "amass", "theharvester", "opencti", "recon_ng", "photon", "whatsmyname", "misp", "gau", "waybackurls", "uncover")
_STATUSES = {"claimed", "available", "unknown", "illegal", "waf"}


class ImportValidationError(ValueError):
    """The supplied file cannot be safely interpreted as the selected format."""


def _object_pairs(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ImportValidationError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _bad_constant(value: str):
    raise ImportValidationError(f"Non-finite JSON value: {value}")


def _decode(text: str):
    return json.loads(text, object_pairs_hook=_object_pairs, parse_constant=_bad_constant)


def _json_records(text: str) -> list[dict]:
    try:
        value = _decode(text)
    except json.JSONDecodeError:
        records = []
        for number, line in enumerate(text.splitlines(), 1):
            if not line.strip():
                continue
            try:
                records.append(_decode(line))
            except json.JSONDecodeError as exc:
                raise ImportValidationError(f"Invalid JSON on line {number}") from exc
        value = records
    if isinstance(value, dict):
        value = value["findings"] if set(value) == {"findings"} else [value]
    if not isinstance(value, list) or any(not isinstance(row, dict) for row in value):
        raise ImportValidationError("Expected JSON objects, an object array, or JSONL records")
    return value


def _required(row: dict, key: str) -> str:
    value = row.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ImportValidationError(f"Missing or invalid {key!r}")
    return value.strip()


def _username(value: str, context: QueryContext):
    if normalize("username", value) != context.query:
        raise ImportValidationError("Imported username is outside the query scope")


def _provenance(row: dict, base: dict, imported_at: datetime) -> tuple[dict, datetime]:
    original = row.get("observed_at", row.get("timestamp"))
    metadata = {**base, "imported_at": imported_at.isoformat(), "original_observed_at": original}
    if original is None or original == "":
        metadata["timestamp_kind"] = "imported_at"
        metadata["original_observed_at"] = None
        return metadata, imported_at
    if not isinstance(original, str):
        raise ImportValidationError("Source observation timestamp must be an ISO 8601 string")
    try:
        parsed = datetime.fromisoformat(original.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ImportValidationError("Invalid source observation timestamp") from exc
    if parsed.tzinfo is None:
        raise ImportValidationError("Source observation timestamp must include a timezone")
    metadata["timestamp_kind"] = "source_observed_at"
    return metadata, parsed


def _finding(tool: str, row: dict, obj: Entity, context: QueryContext,
             provenance: dict, imported_at: datetime, extra: dict) -> Finding:
    metadata, observed = _provenance(row, provenance, imported_at)
    return Finding(
        source=f"import_{tool}", subject=context.entity,
        relation="has_subdomain" if tool == "subfinder" else "reported_profile",
        object=obj, confidence="tentative",
        evidence_url=obj.value if obj.kind == "profile" else f"https://{obj.value}/",
        legal_basis=f"User-supplied local {tool} report; upstream collection permission "
                    "and terms are not independently verified by this offline importer.",
        observed_at=observed,
        metadata={**extra, **metadata, "evidence_type": "imported_tool_claim",
                  "verification": "not_independently_verified"},
    )


def _sherlock(text: str, context: QueryContext, base: dict, now: datetime):
    reader = csv.DictReader(io.StringIO(text), strict=True)
    required = {"username", "name", "url_user", "exists"}
    if not reader.fieldnames or not required.issubset(reader.fieldnames):
        raise ImportValidationError("Sherlock CSV requires username,name,url_user,exists columns")
    if len(set(reader.fieldnames)) != len(reader.fieldnames):
        raise ImportValidationError("Duplicate CSV headers")
    for row in reader:
        if None in row or any(value is None for value in row.values()):
            raise ImportValidationError(f"Malformed CSV row {reader.line_num}")
        _username(_required(row, "username"), context)
        status = _required(row, "exists").casefold()
        if status not in _STATUSES:
            raise ImportValidationError(f"Unknown Sherlock status in row {reader.line_num}")
        if status == "claimed":
            yield _finding("sherlock", row, Entity(kind="profile", value=_required(row, "url_user")),
                           context, base, now, {"site": _required(row, "name"),
                                                "upstream_status": row["exists"]})


def _maigret(text: str, context: QueryContext, base: dict, now: datetime):
    try:
        data = _decode(text)
    except json.JSONDecodeError as exc:
        raise ImportValidationError("Maigret requires its simple JSON site-to-result object") from exc
    if not isinstance(data, dict):
        raise ImportValidationError("Maigret requires its simple JSON site-to-result object")
    for site, row in data.items():
        if not isinstance(row, dict) or not isinstance(row.get("status"), dict):
            raise ImportValidationError(f"Missing Maigret status object for site {site!r}")
        status = row["status"]
        _username(_required(status, "username"), context)
        if "username" in row:
            _username(_required(row, "username"), context)
        state = _required(status, "status").casefold()
        if state not in _STATUSES:
            raise ImportValidationError(f"Unknown Maigret status for site {site!r}")
        if "is_similar" in row and not isinstance(row["is_similar"], bool):
            raise ImportValidationError("Maigret is_similar must be a boolean")
        if state != "claimed" or row.get("is_similar", False):
            continue
        url = _required(row, "url_user") if "url_user" in row else _required(status, "url")
        yield _finding("maigret", row, Entity(kind="profile", value=url), context, base, now,
                       {"site": site, "upstream_status": status["status"]})


def _subfinder(text: str, context: QueryContext, base: dict, now: datetime):
    for row in _json_records(text):
        host = normalize("domain", _required(row, "host"))
        if host == context.query or not host.endswith("." + context.query):
            continue
        if "input" in row:
            parent = normalize("domain", _required(row, "input"))
            if parent != context.query:
                raise ImportValidationError("Subfinder input domain differs from the query scope")
        sources = row.get("sources", [row["source"]] if row.get("source") else [])
        if not isinstance(sources, list) or any(not isinstance(item, str) for item in sources):
            raise ImportValidationError("Subfinder sources must be a list of strings")
        yield _finding("subfinder", row, Entity(kind="domain", value=host), context, base, now,
                       {"upstream_sources": sources, "evidence_url_is_locator": True})


def _canonical(text: str, context: QueryContext, base: dict, now: datetime):
    for row in _json_records(text):
        original = Finding.model_validate(row)
        if original.subject != context.entity:
            raise ImportValidationError("Canonical finding subject is outside the query scope")
        timestamp_row = row
        if original.metadata.get("timestamp_kind") == "imported_at":
            # Re-importing our own evidence must not promote a receipt timestamp
            # into a source observation timestamp.
            timestamp_row = {**row, "observed_at": None}
        metadata, observed = _provenance(timestamp_row, base, now)
        source = f"import_canonical:{original.source}"
        if len(source) > 100:
            source = source[:90] + ":" + hashlib.sha256(source.encode()).hexdigest()[:9]
        yield Finding(**{
            **original.model_dump(), "source": source, "confidence": "tentative",
            "observed_at": observed,
            "metadata": {**original.metadata, **metadata, "original_source": original.source,
                         "original_confidence": original.confidence,
                         "verification": "not_independently_verified"},
        })


def _scrapy(text: str, context: QueryContext, base: dict, now: datetime):
    """Explicit public-page item contract, not a guess at arbitrary Scrapy schemas."""
    from ..modules.phone_evidence import evidence_findings
    from ..phone import public_text

    for row in _json_records(text):
        url = normalize("url", _required(row, "url"))
        body = _required(row, "text")
        if len(body) > 100_000:
            raise ImportValidationError("Scrapy page text exceeds the 100000-character item limit")
        title = row.get("title", "")
        if not isinstance(title, str):
            raise ImportValidationError("Scrapy title must be text")
        if "phone" in row and normalize("phone", _required(row, "phone")) != context.query:
            raise ImportValidationError("Scrapy item phone is outside the query scope")
        metadata, observed = _provenance(row, base, now)
        visible, _ = public_text(body)
        legal_basis = "User-supplied Scrapy public-page export; original collection permissions are not independently verified."
        for finding in evidence_findings(context, visible, url, title, "import_scrapy", legal_basis):
            finding.confidence = "tentative"
            finding.observed_at = observed
            finding.metadata = {**finding.metadata, **metadata, "verification": "not_independently_verified",
                                "feed_contract": "public-page-v1: url,text,title?,observed_at?"}
            yield finding


def parse_import(tool: str, path: Path, context: QueryContext) -> list[Finding]:
    """Import one local file or fail atomically, with no network or subprocess work.

    Sherlock/Maigret require exact username scope. Subfinder drops hosts outside
    the requested domain; canonical records require the exact queried subject.
    Exceeding max_findings raises instead of silently omitting imported evidence.
    """
    tool = tool.lower().strip()
    if tool not in SUPPORTED_IMPORTS:
        raise ImportValidationError(f"Unsupported importer {tool!r}; choose {SUPPORTED_IMPORTS}")
    expected = {"sherlock": "username", "maigret": "username", "subfinder": "domain", "scrapy": "phone"}
    if tool in expected and context.input_type != expected[tool]:
        raise ImportValidationError(f"{tool} imports require input type {expected[tool]}")
    path = Path(path)
    if not path.is_file():
        raise ImportValidationError("Import path must be a regular file")
    with path.open("rb") as stream:
        raw = stream.read(MAX_IMPORT_BYTES + 1)
    if len(raw) > MAX_IMPORT_BYTES:
        raise ImportValidationError("Import exceeds the 10 MB size limit")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ImportValidationError("Import must be UTF-8 text") from exc
    if not text.strip():
        raise ImportValidationError("Import file is empty")
    base = {"import_tool": tool, "import_file": path.name,
            "import_sha256": hashlib.sha256(raw).hexdigest()}
    from .community import PARSERS as COMMUNITY_PARSERS
    from .discovery_exports import PARSERS as DISCOVERY_PARSERS
    from .misp_exchange import import_misp
    from .stix_exchange import import_stix
    from .tool_exports import PARSERS

    parser = {"sherlock": _sherlock, "maigret": _maigret,
              "subfinder": _subfinder, "canonical": _canonical, "scrapy": _scrapy,
              "opencti": import_stix, "misp": import_misp, **PARSERS, **COMMUNITY_PARSERS, **DISCOVERY_PARSERS}[tool]
    findings = []
    output_bytes = 0
    try:
        for finding in parser(text, context, base, utcnow()):
            output_bytes += len(finding.model_dump_json().encode("utf-8"))
            if output_bytes > 8_000_000:
                raise ImportValidationError("Import exceeds the 8 MB expanded evidence budget; split or narrow the input")
            findings.append(finding)
            if len(findings) > context.max_findings:
                raise ImportValidationError("Import exceeds max_findings; increase the explicit limit")
    except (ValueError, TypeError, KeyError, csv.Error, RecursionError) as exc:
        if isinstance(exc, ImportValidationError):
            raise
        raise ImportValidationError(f"Invalid {tool} report: {exc}") from exc
    return findings
