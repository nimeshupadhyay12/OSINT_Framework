"""Offline adapters for explicitly supplied third-party reports."""
