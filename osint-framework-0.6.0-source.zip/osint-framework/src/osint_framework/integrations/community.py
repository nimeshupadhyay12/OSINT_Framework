"""Small, explicit community export contracts; no registry-supplied requests are executed."""

import csv
import io
from urllib.parse import quote, urlsplit

from ..core.schema import Entity, Finding, normalize
from .imports import ImportValidationError, _decode, _provenance


def claim(tool, context, base, now, kind, value, metadata, evidence, relation="tool_reported_observation"):
    provenance, observed = _provenance({}, base, now)
    return Finding(source="import_" + tool, subject=context.entity, relation=relation,
        object=Entity(kind=kind, value=value), confidence="tentative", evidence_url=evidence,
        observed_at=observed, legal_basis="Operator-supplied public-data export; original collection not independently verified.",
        metadata={**metadata, **provenance, "verification": "not_independently_verified"})


def scoped(value, domain):
    return value == domain or value.endswith("." + domain)


def recon_ng(text, context, base, now):
    if context.input_type not in {"domain", "email"}:
        raise ImportValidationError("Recon-ng import supports domain hosts or email/domain contact queries")
    reader = csv.DictReader(io.StringIO(text))
    fields = reader.fieldnames or []
    if len(fields) != len(set(fields)) or ("host" not in fields and "email" not in fields):
        raise ImportValidationError("Recon-ng needs a hosts or contacts CSV exported with headers=true")
    for row in reader:
        if None in row or any(value is None for value in row.values()):
            raise ImportValidationError("Malformed Recon-ng CSV row")
        evidence = "https://github.com/lanmaster53/recon-ng"
        meta = {"upstream_module": row.get("module", ""), "adapter_contract": "recon-ng reporting/csv headers=true; hosts/contacts subset",
                "upstream_sources": [row["module"]] if row.get("module") else [], "evidence_url_is_locator": True}
        if "host" in fields:
            if context.input_type != "domain":
                raise ImportValidationError("Recon-ng hosts table requires a domain query")
            host = normalize("domain", row["host"])
            if not scoped(host, context.query):
                continue
            yield claim("recon_ng", context, base, now, "domain", host, meta, evidence)
            if row.get("ip_address", "").strip():
                yield claim("recon_ng", context, base, now, "ip", row["ip_address"], {**meta, "reported_host": host}, evidence)
        elif row["email"].strip():
            email = normalize("email", row["email"])
            if (context.input_type == "email" and email != context.query) or (context.input_type == "domain" and not scoped(email.rsplit("@", 1)[1], context.query)):
                continue
            yield claim("recon_ng", context, base, now, "email", email, meta, evidence)


def photon(text, context, base, now):
    if context.input_type not in {"domain", "url"}:
        raise ImportValidationError("Photon export needs a domain or URL query")
    data = _decode(text)
    known = {"files", "intel", "robots", "custom", "failed", "internal", "scripts", "external", "fuzzable", "endpoints", "keys", "subdomains"}
    if not isinstance(data, dict) or not data or set(data) - known:
        raise ImportValidationError("Photon requires its named-dataset JSON export")
    if any(not isinstance(values, list) or any(not isinstance(value, str) for value in values) for values in data.values()):
        raise ImportValidationError("Photon datasets must be string arrays")
    domain = context.query if context.input_type == "domain" else urlsplit(context.query).hostname
    for category in ("internal", "subdomains"):
        for raw in data.get(category, []):
            kind = "url" if category == "internal" else "domain"
            value = normalize(kind, raw)
            host = urlsplit(value).hostname if kind == "url" else value
            if not scoped(host, domain):
                continue
            yield claim("photon", context, base, now, kind, value,
                {"category": category, "adapter_contract": "Photon named-dataset JSON internal/subdomains subset",
                 "omitted_categories": sorted(set(data) - {"internal", "subdomains"})},
                value if kind == "url" else "https://github.com/s0md3v/Photon")


def whatsmyname(text, context, base, now):
    if context.input_type != "username":
        raise ImportValidationError("WhatsMyName registry planning needs a username query")
    data = _decode(text)
    if not isinstance(data, dict) or not all(isinstance(data.get(field), list) for field in ("license", "authors", "categories", "sites")):
        raise ImportValidationError("WhatsMyName requires a local wmn-data.json registry")
    for site in data["sites"]:
        if not isinstance(site, dict) or not isinstance(site.get("name"), str):
            raise ImportValidationError("Invalid WhatsMyName site record")
        if site.get("valid") is False or site.get("protection") or any(site.get(key) for key in ("post_body", "headers", "strip_bad_char")):
            continue
        template = site.get("uri_pretty") or site.get("uri_check")
        if not isinstance(template, str) or template.count("{account}") != 1:
            continue
        value = template.replace("{account}", quote(context.query, safe=""))
        if "{" in value or "}" in value or urlsplit(value).scheme != "https":
            continue
        url = normalize("url", value)
        if urlsplit(url).query or urlsplit(url).port not in (None, 443):
            continue
        yield claim("whatsmyname", context, base, now, "profile", url,
            {"site_name": site["name"], "category": site.get("cat"), "registry_authors": data["authors"],
             "registry_license": data["license"], "adapter_contract": "WhatsMyName GET URL planning subset",
             "profile_checked": False, "account_exists": "unknown", "note": "Generated candidate URL only. No account lookup was made."},
            "https://github.com/WebBreacher/WhatsMyName", relation="unqueried_profile_candidate")


PARSERS = {"recon_ng": recon_ng, "photon": photon, "whatsmyname": whatsmyname}
