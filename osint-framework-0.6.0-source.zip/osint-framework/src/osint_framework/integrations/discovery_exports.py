"""Documented upstream output contracts; importing performs no network requests."""

from urllib.parse import urlsplit

from ..core.schema import normalize
from .community import claim, scoped
from .imports import ImportValidationError, _json_records


def url_lines(tool, text, context, base, now):
    if context.input_type not in {"domain", "url"}:
        raise ImportValidationError(f"{tool} requires a domain or exact URL scope")
    seen = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        url = normalize("url", line.strip())
        if context.input_type == "domain" and not scoped(urlsplit(url).hostname, context.query):
            continue
        if context.input_type == "url" and url != context.query:
            continue
        if url in seen:
            continue
        seen.add(url)
        yield claim(tool, context, base, now, "url", url,
            {"adapter_contract": tool + " plain URL lines", "historical": True,
             "current_existence_verified": False, "evidence_url_is_locator": True,
             "note": "Upstream URL discovery only; no URL was fetched or tested."}, url, "historical_url_lead")


def gau(text, context, base, now):
    yield from url_lines("gau", text, context, base, now)


def waybackurls(text, context, base, now):
    yield from url_lines("waybackurls", text, context, base, now)


def uncover(text, context, base, now):
    if context.input_type not in {"domain", "ip"}:
        raise ImportValidationError("Uncover requires a domain or exact IP scope")
    for row in _json_records(text):
        if not isinstance(row.get("source"), str) or not row["source"]:
            raise ImportValidationError("Uncover JSONL needs its source field; use -j, not raw output")
        port = row.get("port", 0)
        if type(port) is not int or not 0 <= port <= 65535:
            raise ImportValidationError("Invalid Uncover port")
        host = normalize("domain", row["host"]) if row.get("host") else None
        ip = normalize("ip", row["ip"]) if row.get("ip") else None
        url = normalize("url", row["url"]) if row.get("url") else None
        if context.input_type == "domain":
            if not host or not scoped(host, context.query):
                continue
            if url and not scoped(urlsplit(url).hostname, context.query):
                raise ImportValidationError("Uncover URL differs from the permitted domain")
        elif ip != context.query:
            continue
        metadata = {"upstream_sources": [row["source"][:100]], "reported_host": host, "reported_ip": ip,
            "reported_port": port, "upstream_timestamp": row.get("timestamp"),
            "adapter_contract": "Uncover sources.Result JSONL; -j", "evidence_url_is_locator": True,
            "note": "Provider-reported service; no connection or vulnerability scan was performed."}
        for kind, value in (("domain", host), ("ip", ip), ("url", url)):
            if value:
                yield claim("uncover", context, base, now, kind, value, metadata,
                            "https://github.com/projectdiscovery/uncover", "reported_infrastructure")


PARSERS = {"gau": gau, "waybackurls": waybackurls, "uncover": uncover}
