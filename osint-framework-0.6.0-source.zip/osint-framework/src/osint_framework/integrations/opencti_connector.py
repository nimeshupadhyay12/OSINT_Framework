"""Explicit one-shot external import through the official OpenCTI connector helper."""

import json
import os
import uuid
from urllib.parse import urlsplit

from ..core.audit import AuditLog
from .stix_exchange import export_stix


def send_report(report, state, *, authorized=False, purpose="", helper_factory=None):
    if not authorized or len(purpose.strip()) < 8:
        raise ValueError("Explicit --authorized and --purpose (8+ characters) are required to transfer this report")
    audit = AuditLog(state)
    if not audit.consented():
        raise ValueError("Accept the local policy before transferring evidence")
    url = os.environ.get("OPENCTI_URL", "")
    token = os.environ.get("OPENCTI_TOKEN", "")
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment or not token:
        raise ValueError("Configure a trusted HTTPS OPENCTI_URL and OPENCTI_TOKEN")
    try:
        connector_id = str(uuid.UUID(os.environ.get("OPENCTI_CONNECTOR_ID", "")))
    except ValueError:
        raise ValueError("Set a stable UUID in OPENCTI_CONNECTOR_ID") from None
    payload = json.dumps(export_stix(report))
    if len(payload.encode()) > 10_000_000:
        raise ValueError("OpenCTI transfer exceeds 10 MB")
    if helper_factory is None:
        try:
            from pycti import OpenCTIConnectorHelper
        except ImportError as exc:
            raise ValueError("Install the opencti extra in a dedicated connector environment") from exc
        helper_factory = OpenCTIConnectorHelper
    audit.append("opencti_transfer_started", {"run_id": report.run_id, "destination": parsed.hostname, "purpose": purpose.strip()})
    helper = None
    work_id = None
    try:
        helper = helper_factory({"opencti": {"url": url, "token": token, "ssl_verify": True},
            "connector": {"id": connector_id, "name": "OSINT evidence export", "type": "EXTERNAL_IMPORT",
                          "scope": "identity,domain-name,ipv4-addr,ipv6-addr,email-addr,url,user-account,note,grouping,marking-definition", "log_level": "error"}})
        work_id = helper.api.work.initiate_work(helper.connect_id, "OSINT run " + report.run_id)
        # No entity-type filter: the payload already contains a validated STIX bundle.
        helper.send_stix2_bundle(payload, update=False, work_id=work_id)
        helper.api.work.to_processed(work_id, "Evidence bundle submitted; inspect platform worker ingestion")
        audit.append("opencti_transfer_submitted", {"run_id": report.run_id, "work_id": work_id})
        return {"submitted": True, "work_id": work_id, "note": "Queued on OpenCTI; ingestion success must be checked on the platform. No automatic retry."}
    except Exception as exc:
        audit.append("opencti_transfer_uncertain", {"run_id": report.run_id, "work_id": work_id, "error_type": type(exc).__name__})
        raise ValueError("OpenCTI transfer failed or is uncertain; check platform work before retrying") from None
    finally:
        if helper is not None:
            try:
                helper.stop()
            except Exception:
                pass
