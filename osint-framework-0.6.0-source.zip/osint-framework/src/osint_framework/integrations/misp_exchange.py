"""Offline MISP event/attribute subset. Never publishes or changes server state."""

import json
import uuid

from ..core.schema import Entity, Finding, normalize
from .imports import ImportValidationError, _decode

TYPES = {"domain": "domain", "hostname": "domain", "ip-src": "ip", "ip-dst": "ip",
         "email-src": "email", "email-dst": "email", "phone-number": "phone", "url": "url"}
EXPORT_TYPES = {"domain": "domain", "ip": "ip-dst", "email": "email-src", "phone": "phone-number", "url": "url", "profile": "url"}


def import_misp(text, context, base, now):
    data = _decode(text)
    event = data.get("Event", data) if isinstance(data, dict) else None
    if not isinstance(event, dict) or not isinstance(event.get("Attribute"), list):
        raise ImportValidationError("MISP import requires one Event with an Attribute array")
    for attribute in event["Attribute"]:
        if not isinstance(attribute, dict):
            raise ImportValidationError("MISP attribute must be an object")
        kind = TYPES.get(attribute.get("type"))
        if kind is None or attribute.get("deleted") in (True, 1, "1"):
            continue
        entity = Entity(kind=kind, value=attribute.get("value", ""))
        # An event groups intelligence; it does not establish identity links.
        if kind != context.input_type or entity.value != context.query:
            continue
        identifier = str(uuid.UUID(str(attribute.get("uuid"))))
        yield Finding(source="import_misp", subject=context.entity, relation="misp_attribute_claim",
            object=entity, confidence="tentative", evidence_url="urn:sha256:" + base["import_sha256"],
            legal_basis="User-supplied MISP export; sharing permissions remain the operator's responsibility.",
            observed_at=now, metadata={**base, "timestamp_kind": "imported_at", "imported_at": now.isoformat(),
                "location": "MISP attribute " + identifier, "misp_event_uuid": event.get("uuid"), "misp_event_distribution": event.get("distribution"),
                "misp_event_tags": event.get("Tag", []), "misp_attribute": attribute,
                "verification": "not_independently_verified"})


def export_misp(report):
    attributes = []
    for result in report.results:
        for finding in result.findings:
            if finding.metadata.get("case_review", {}).get("decision") == "rejected":
                continue
            if any(key.startswith("stix_") and ("marking" in key) and value for key, value in finding.metadata.items()):
                raise ValueError("MISP export cannot translate STIX markings; use STIX export to preserve them")
            kind = EXPORT_TYPES.get(finding.object.kind)
            if kind is None:
                continue
            value = normalize("url", finding.object.value) if finding.object.kind == "profile" else finding.object.value
            tags = []
            for tag in [*finding.metadata.get("misp_event_tags", []), *finding.metadata.get("misp_attribute", {}).get("Tag", [])]:
                if isinstance(tag, dict) and isinstance(tag.get("name"), str):
                    tags.append({"name": tag["name"]})
            attributes.append({"uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, report.run_id + ":" + finding.id)),
                "type": kind, "value": value, "category": "Person" if kind == "phone-number" else "Payload delivery" if kind == "email-src" else "Network activity", "to_ids": False, "distribution": "0",
                "timestamp": str(int(finding.observed_at.timestamp())),
                "comment": json.dumps({"source": finding.source, "finding_id": finding.id,
                    "evidence_url": finding.evidence_url, "confidence": finding.confidence,
                    "observed_at": finding.observed_at.isoformat()}, ensure_ascii=True), "Tag": tags})
    return {"Event": {"uuid": str(uuid.uuid5(uuid.NAMESPACE_URL, "osint:" + report.run_id)),
        "info": "OSINT evidence " + report.run_id, "date": report.created_at.date().isoformat(),
        "distribution": "0", "published": False, "analysis": "0", "threat_level_id": "4",
        "Attribute": attributes}}
