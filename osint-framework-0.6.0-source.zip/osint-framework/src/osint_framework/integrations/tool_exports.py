"""Versioned offline adapters verified against upstream serializers; no tool execution."""

from urllib.parse import urlsplit

from ..core.schema import Entity, Finding, normalize
from .imports import ImportValidationError, _decode, _json_records, _provenance, _required

CONTRACTS = {
    "spiderfoot": "scanexportjsonmulti:data,event_type,module,source_data,false_positive,last_seen,scan_target",
    "amass": "Amass v5 oam_subs -names -nocolor: one FQDN per line",
    "theharvester": "5.0 completed-result JSONL: summary followed by typed findings",
}
REFERENCES = {
    "spiderfoot": "https://github.com/smicallef/spiderfoot",
    "amass": "https://github.com/owasp-amass/amass",
    "theharvester": "https://github.com/laramies/theHarvester",
}


def in_domain(value, domain):
    return value == domain or value.endswith("." + domain)


def _claim(tool, context, obj, base, now, metadata, *, observed=None, evidence=None):
    provenance, timestamp = _provenance({"observed_at": observed}, base, now)
    locator = evidence or REFERENCES[tool]
    return Finding(source="import_" + tool, subject=context.entity, object=obj,
                   relation="has_subdomain" if obj.kind == "domain" and context.input_type == "domain"
                   and obj.value != context.query else "tool_reported_observation",
                   confidence="tentative", evidence_url=locator, observed_at=timestamp,
                   legal_basis=f"Operator-supplied {tool} export; collection permission is not independently verified.",
                   metadata={**metadata, **provenance, "adapter_contract": CONTRACTS[tool],
                             "evidence_url_is_locator": not bool(evidence),
                             "verification": "not_independently_verified"})


def spiderfoot(text, context, base, now):
    data = _decode(text)
    if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
        raise ImportValidationError("SpiderFoot requires its scanexportjsonmulti JSON object array")
    types = {"INTERNET_NAME": "domain", "DOMAIN_NAME": "domain", "EMAILADDR": "email",
             "IP_ADDRESS": "ip", "IPV6_ADDRESS": "ip", "PHONE_NUMBER": "phone",
             "HUMAN_NAME": "name", "LINKED_URL_INTERNAL": "url", "LINKED_URL_EXTERNAL": "url"}
    for row in data:
        target = _required(row, "scan_target")
        if normalize(context.input_type, target) != context.query:
            raise ImportValidationError("SpiderFoot scan_target differs from the query")
        event = _required(row, "event_type")
        value, module = _required(row, "data"), _required(row, "module")
        flag = row.get("false_positive")
        if not isinstance(flag, (bool, int)) or flag not in (False, True, 0, 1):
            raise ImportValidationError("SpiderFoot false_positive must be 0 or 1")
        if flag or event not in types:
            continue
        obj = Entity(kind=types[event], value=value)
        if context.input_type == "domain":
            if obj.kind == "domain" and not in_domain(obj.value, context.query):
                continue
            if obj.kind == "email" and not in_domain(obj.value.rsplit("@", 1)[1], context.query):
                continue
            if obj.kind == "url" and not in_domain(urlsplit(obj.value).hostname or "", context.query):
                continue
        source = row.get("source_data", "")
        evidence = None
        if isinstance(source, str) and source.startswith(("https://", "http://")):
            evidence = normalize("url", source)
        yield _claim("spiderfoot", context, obj, base, now,
                     {"upstream_module": module, "upstream_event_type": event,
                      "upstream_source_data": str(source)[:2000], "upstream_last_seen": row.get("last_seen"),
                      "upstream_timezone_unknown": True, "scan_name": row.get("scan_name", ""),
                      "upstream_sources": [module]}, evidence=evidence)


def amass(text, context, base, now):
    if context.input_type != "domain":
        raise ImportValidationError("Amass names export requires a domain query")
    seen = set()
    for line in text.splitlines():
        if not line.strip():
            continue
        try:
            host = normalize("domain", line)
        except ValueError as exc:
            raise ImportValidationError("Use Amass v5 oam_subs -names -nocolor output, one FQDN per line") from exc
        if host in seen or not in_domain(host, context.query):
            continue
        seen.add(host)
        yield _claim("amass", context, Entity(kind="domain", value=host), base, now,
                     {"upstream_sources": [], "source_detail_unavailable": True,
                      "note": "Names-only export contains no provider or collection timestamp."})


def theharvester(text, context, base, now):
    rows = _json_records(text)
    if not rows or rows[0].get("type") != "summary" or context.input_type != "domain":
        raise ImportValidationError("theHarvester requires a domain query and completed-result JSONL starting with summary")
    summary, results = rows[0], rows[1:]
    if normalize("domain", _required(summary, "target")) != context.query:
        raise ImportValidationError("theHarvester target differs from query scope")
    if summary.get("evidence_status") not in {"complete", "partial", "failed"}:
        raise ImportValidationError("Unsupported theHarvester evidence_status")
    if type(summary.get("result_count")) is not int or summary["result_count"] != len(results):
        raise ImportValidationError("theHarvester result_count does not match its finding records")
    completed = _required(summary, "completed_at")
    _provenance({"observed_at": completed}, base, now)
    kinds = {"hostname": "domain", "email": "email", "ip": "ip", "url": "url"}
    for row in results:
        kind, value = _required(row, "type"), _required(row, "value")
        sources, actions = row.get("sources", []), row.get("actions", [])
        if any(not isinstance(group, list) or any(not isinstance(s, str) for s in group)
               for group in (sources, actions)):
            raise ImportValidationError("theHarvester producer names must be string arrays")
        if kind not in kinds:
            # Only the explicitly documented four identifier types are imported.
            continue
        obj = Entity(kind=kinds[kind], value=value)
        if obj.kind == "domain" and not in_domain(obj.value, context.query):
            continue
        if obj.kind == "email" and not in_domain(obj.value.rsplit("@", 1)[1], context.query):
            continue
        if obj.kind == "url" and not in_domain(urlsplit(obj.value).hostname or "", context.query):
            continue
        finding = _claim("theharvester", context, obj, base, now,
                         {"upstream_sources": sources, "upstream_actions": actions,
                          "upstream_run_id": summary.get("run_id"),
                          "upstream_evidence_status": summary["evidence_status"],
                          "upstream_source_executions": summary.get("source_executions", []),
                          "upstream_completed_at": completed,
                          "unsupported_record_count": sum(r.get("type") not in kinds for r in results)},
                         observed=None)
        # The completion time applies to the run, not each source observation.
        yield finding


PARSERS = {"spiderfoot": spiderfoot, "amass": amass, "theharvester": theharvester}
