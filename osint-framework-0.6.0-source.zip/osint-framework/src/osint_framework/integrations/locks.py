"""Operator-reviewed plugin inventory; local code and dependencies remain trusted."""

import hashlib
import json
import os
from importlib.metadata import distribution
from pathlib import Path


def distribution_receipt(name):
    dist = distribution(name)
    if not dist.files or dist.read_text("direct_url.json") and '"editable": true' in dist.read_text("direct_url.json"):
        raise ValueError("Plugin approval requires a non-editable installed distribution")
    digest = hashlib.sha256()
    count = 0
    for file in sorted(dist.files, key=str):
        if str(file).endswith((".pyc", "/RECORD")):
            continue
        path = Path(dist.locate_file(file))
        if not path.is_file() or path.stat().st_size > 200_000_000:
            raise ValueError("Plugin distribution file is missing or exceeds 200 MB")
        with path.open("rb") as stream:
            checksum = hashlib.file_digest(stream, "sha256").hexdigest()
        digest.update((str(file) + "\0" + checksum + "\n").encode())
        count += 1
    return {"distribution": dist.metadata["Name"], "version": dist.version, "sha256": digest.hexdigest(), "files": count}


def require_plugin_approval(entry):
    path = os.environ.get("OSINT_PLUGIN_LOCK", "")
    if not path:
        raise ValueError("Plugins require OSINT_PLUGIN_LOCK pointing to a reviewed inventory")
    from ..evidence import read_limited
    lock = json.loads(read_limited(path, 100_000))
    expected = lock.get("plugins", {}).get(entry.name)
    if not expected or not entry.dist or expected != distribution_receipt(entry.dist.metadata["Name"]):
        raise ValueError("Plugin inventory does not match installed files; review and approve the changed package")


def verify_binary(path, expected):
    if not expected or len(expected) != 64:
        raise ValueError("Set OSINT_SUBFINDER_SHA256 to the reviewed executable's SHA-256 before running it")
    path = Path(path)
    if path.stat().st_size > 200_000_000:
        raise ValueError("Tool binary exceeds 200 MB")
    with path.open("rb") as stream:
        actual = hashlib.file_digest(stream, "sha256").hexdigest()
    if actual != expected.lower():
        raise ValueError("Tool executable changed; review its release and update the approved digest")
    return actual
