"""Optional JWT access-token validation; roles come only from local provisioning."""

import os
from urllib.parse import urlsplit


class OIDCVerifier:
    def __init__(self):
        self.issuer = os.environ.get("OSINT_OIDC_ISSUER", "")
        audience = os.environ.get("OSINT_OIDC_AUDIENCE", "")
        jwks = os.environ.get("OSINT_OIDC_JWKS_URL", "")
        self.enabled = any((self.issuer, audience, jwks))
        self.audience = audience
        self.acrs = set(filter(None, os.environ.get("OSINT_OIDC_REQUIRED_ACR", "").split(",")))
        if not self.enabled:
            return
        if not all((self.issuer, audience, jwks)):
            raise ValueError("OIDC requires issuer, API audience and JWKS URL together")
        for url in (self.issuer, jwks):
            parsed = urlsplit(url)
            if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
                raise ValueError("OIDC issuer and JWKS URL must be trusted HTTPS addresses without credentials")
        try:
            import jwt
        except ImportError as exc:
            raise ValueError("Install the team extra for OIDC token validation") from exc
        self.jwt = jwt
        self.keys = jwt.PyJWKClient(jwks, timeout=5, lifespan=300)

    def principal(self, token, store):
        if not self.enabled or len(token) > 8192 or token.count(".") != 2:
            return None
        try:
            signing_key = self.keys.get_signing_key_from_jwt(token)
            claims = self.jwt.decode(token, signing_key.key, algorithms=["RS256", "ES256"],
                audience=self.audience, issuer=self.issuer, leeway=30,
                options={"require": ["exp", "iat", "sub", "iss", "aud"]})
            if not isinstance(claims["sub"], str) or not 1 <= len(claims["sub"]) <= 500:
                return None
            if self.acrs and claims.get("acr") not in self.acrs:
                return None
        except (self.jwt.PyJWTError, ValueError, TypeError, OSError):
            return None
        return store.oidc_principal(self.issuer, claims["sub"])
