"""Local CLI. Running sources always requires a purpose and explicit authorization."""

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Annotated

import typer
from pydantic import ValidationError
from rich.console import Console
from rich.table import Table

from .core.audit import AuditLog
from .core.cases import CaseStore
from .core.engine import Engine
from .core.http import SourceError, SourceSkipped
from .core.ratelimit import RateLimited
from .core.schema import Entity, Finding, ModuleResult, QueryContext
from .integrations.imports import SUPPORTED_IMPORTS, parse_import
from .integrations.subfinder import SubfinderModule
from .registry import available_plugins, registry
from .report import write_report

app = typer.Typer(no_args_is_help=True, help="OSINT Correlation Framework — evidence, provenance, and bounded collection.")
console = Console(markup=False)
State = Annotated[Path, typer.Option("--state", help="Local audit and rate-limit directory")]
DEFAULT_STATE = Path(".osint-state")
BANNER = """Authorized-use policy
Collect only public or explicitly authorized data for a documented purpose.
Review the terms of every provider. Respect rate limits and robots directives.
Do not bypass logins, CAPTCHAs, access restrictions, or anti-bot controls.
No private-profile scraping, raw breach dumps, live tracking, or bulk person enumeration.
Matching identifiers are leads; they do not establish a person's identity.
Queries are audited locally. Reports contain raw evidence and may contain personal data.
This confirmation records the operator's statement; it does not verify consent.
"""


def failure(exc):
    if isinstance(exc, ValidationError):
        console.print("Invalid input: " + "; ".join(error["msg"] for error in exc.errors(include_input=False)))
    else:
        console.print(str(exc))
    raise typer.Exit(2)


def context_for(query, kind, purpose, authorized, **kwargs):
    if not authorized:
        raise ValueError("Specify --authorized for this query after reviewing your scope")
    return QueryContext(query=query, input_type=kind, purpose=purpose, authorized=True, **kwargs)


def output_report(report, out):
    directory = out / report.run_id
    paths = write_report(report, directory)
    console.print(f"Run: {report.run_id}")
    table = Table("Source", "Status", "Findings", "Detail")
    for result in report.results:
        table.add_row(result.module, result.status, str(len(result.findings)), result.message)
    console.print(table)
    for name, path in paths.items():
        console.print(f"{name}: {path.resolve()}")


@app.command()
def init(state: State = DEFAULT_STATE,
         accept_policy: Annotated[bool, typer.Option("--accept-policy", help="Explicit noninteractive policy acceptance")] = False):
    """Read and accept the first-launch policy."""
    console.print(BANNER)
    if not accept_policy and not typer.confirm("I confirm that I will use this framework within authorized scope"):
        raise typer.Exit(1)
    AuditLog(state).accept_policy()
    console.print(f"Policy acceptance recorded in {state.resolve()}")


@app.command()
def sources():
    """List implemented sources and optional installed plugins without loading plugins."""
    table = Table("Source", "Inputs", "Mode", "Required environment")
    for module in [*registry().values(), SubfinderModule()]:
        spec = module.spec
        table.add_row(spec.name, ", ".join(spec.input_types), "default" if spec.default_enabled else "opt-in",
                      ", ".join(spec.key_env) or "none")
    console.print(table)
    console.print("Offline imports: " + ", ".join(SUPPORTED_IMPORTS))
    console.print("Installed plugins (not loaded): " + (", ".join(available_plugins()) or "none"))


@app.command()
def run(query: str, kind: Annotated[str, typer.Option("--type")],
        purpose: Annotated[str, typer.Option("--purpose")],
        authorized: Annotated[bool, typer.Option("--authorized")] = False,
        modules: Annotated[str | None, typer.Option("--modules", help="Comma-separated source names; defaults to keyless sources")] = None,
        plugin: Annotated[list[str] | None, typer.Option("--plugin", help="Load a trusted installed entry point")] = None,
        allow_host: Annotated[list[str] | None, typer.Option("--allow-host", help="Exact public hostname allowed for webpage scraping")] = None,
        page_url: Annotated[list[str] | None, typer.Option("--page-url", help="Approved public page to inspect for phone evidence")] = None,
        terms_url: Annotated[str | None, typer.Option("--terms-url", help="Reviewed permission/terms reference for webpage collection")] = None,
        max_pages: Annotated[int, typer.Option(min=1, max=20)] = 3,
        max_findings: Annotated[int, typer.Option(min=1, max=2000)] = 500,
        max_requests: Annotated[int, typer.Option(min=1, max=200)] = 50,
        preserve_pages: Annotated[bool, typer.Option("--preserve-pages")] = False,
        free_only: Annotated[bool, typer.Option("--free-only", help="Use compatible APIs without keys; exclude account-based providers")] = False,
        case_id: Annotated[str | None, typer.Option("--case")] = None,
        out: Annotated[Path, typer.Option()] = Path("reports"), state: State = DEFAULT_STATE):
    """Collect a single identifier through selected sources and export a report."""
    try:
        context = context_for(query, kind, purpose, authorized, allowed_hosts=allow_host or [],
                              terms_url=terms_url, seed_urls=page_url or [], max_pages=max_pages, max_findings=max_findings,
                              max_requests=max_requests, preserve_pages=preserve_pages)
        # Validate authorization and audit state before importing third-party executable code.
        audit = AuditLog(state)
        if not audit.consented():
            raise ValueError("Run 'osint init' first")
        installed = registry(plugin)
        installed["subfinder"] = SubfinderModule()
        names = list(dict.fromkeys(name.strip() for name in modules.split(","))) if modules else [
            name for name, module in installed.items() if module.spec.default_enabled and kind in module.spec.input_types]
        if free_only:
            from .catalog import free_selection
            permitted = free_selection(context)
            if plugin or (modules and set(names) - set(permitted)):
                raise ValueError("--free-only accepts only compatible no-key sources with required page scope")
            names = names if modules else permitted
        unknown = set(names) - installed.keys()
        if unknown:
            raise ValueError("Unknown modules: " + ", ".join(sorted(unknown)))
        from .workflow import investigate

        outcome = asyncio.run(investigate(context, names, state, out, case_id=case_id, available=installed))
        report = outcome.report
        console.print(f"Run: {report.run_id}")
        for result in report.results:
            console.print(f"{result.module}: {result.status}; {len(result.findings)} findings; {result.message}")
        for name, path in outcome.paths.items():
            console.print(f"{name}: {path.resolve()}")
    except (ValueError, OSError, SourceError, SourceSkipped, RateLimited) as exc:
        failure(exc)
    except sqlite3.Error:
        failure(ValueError("Local audit storage could not be read or written; collection stopped"))
    if any(result.status in {"error", "rate_limited"} for result in report.results):
        raise typer.Exit(1)
    if all(result.status == "skipped" for result in report.results):
        raise typer.Exit(1)


@app.command("import-results")
def import_results(file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)],
                   tool: Annotated[str, typer.Option("--tool")],
                   query: Annotated[str, typer.Option("--query")],
                   kind: Annotated[str, typer.Option("--type")],
                   purpose: Annotated[str, typer.Option("--purpose")],
                   authorized: Annotated[bool, typer.Option("--authorized")] = False,
                   max_findings: Annotated[int, typer.Option(min=1, max=2000)] = 500,
                   case_id: Annotated[str | None, typer.Option("--case")] = None,
                   out: Annotated[Path, typer.Option()] = Path("reports"), state: State = DEFAULT_STATE):
    """Normalize an existing export without contacting any data providers."""
    try:
        context = context_for(query, kind, purpose, authorized, max_findings=max_findings)
        if case_id:
            CaseStore(state).get(case_id)
        engine = Engine(AuditLog(state))
        run_id = engine.start(context, ["import:" + tool])
        try:
            asyncio.run(engine.limiter.acquire(f"queries:{kind}", 10))
            findings = parse_import(tool, file, context)
            result = ModuleResult(module="import:" + tool, status="ok" if findings else "empty", findings=findings)
            report = engine.finish(run_id, context, [result])
        except BaseException:
            engine.audit.append("run_aborted", {"run_id": run_id})
            raise
        from .workflow import save_outcome
        outcome = save_outcome(report, state, out, case_id)
        for name, path in outcome.paths.items():
            console.print(f"{name}: {path.resolve()}")
    except (ValueError, OSError, SourceError, SourceSkipped, RateLimited) as exc:
        failure(exc)
    except sqlite3.Error:
        failure(ValueError("Local audit storage could not be read or written; import stopped"))


@app.command("audit-verify")
def audit_verify(state: State = DEFAULT_STATE):
    """Check the local audit chain for accidental or un-recomputed edits."""
    valid, count = AuditLog(state).verify()
    console.print(f"Audit chain: {'valid' if valid else 'INVALID'}; {count} verified events")
    if not valid:
        raise typer.Exit(1)


@app.command()
def demo(out: Annotated[Path, typer.Option()] = Path("demo-report")):
    """Create a clearly labeled synthetic report offline, with no real queries."""
    from .core.correlator import correlate
    from .core.schema import RunReport

    context = QueryContext(query="example.org", input_type="domain", purpose="Synthetic offline demonstration", authorized=True)
    findings = [Finding(source="synthetic_fixture", subject=context.entity,
                        relation="has_subdomain", object=Entity(kind="domain", value=domain),
                        confidence="tentative", evidence_url="https://example.org/",
                        legal_basis="Synthetic demonstration; no network collection",
                        metadata={"synthetic": True}) for domain in ["www.example.org", "mail.example.org", "docs.example.org"]]
    report = RunReport(run_id="synthetic-demo", context=context,
                       results=[ModuleResult(module="synthetic_fixture", status="ok", findings=findings)],
                       graph=correlate(findings), notes=["SYNTHETIC DEMO — these findings are invented fixtures, not research results."])
    output_report(report, out)


@app.command("export-schema")
def export_schema(out: Path = Path("finding.schema.json")):
    """Export the canonical Finding JSON schema for third-party integration."""
    out.write_text(json.dumps(Finding.model_json_schema(), indent=2), encoding="utf-8")
    console.print(str(out.resolve()))


@app.command()
def phone(number: Annotated[str | None, typer.Argument(help="A formatted phone number; omit for a paste prompt")] = None,
          region: Annotated[str | None, typer.Option(help="Country code for national numbers, e.g. IN or US")] = None,
          purpose: Annotated[str | None, typer.Option()] = None,
          authorized: Annotated[bool, typer.Option("--authorized")] = False,
          search_web: Annotated[bool, typer.Option("--search-web", help="Search indexed public snippets through Brave (requires key)")] = False,
          page_url: Annotated[list[str] | None, typer.Option("--page-url")] = None,
          allow_host: Annotated[list[str] | None, typer.Option("--allow-host")] = None,
          terms_url: Annotated[str | None, typer.Option("--terms-url")] = None,
          max_pages: Annotated[int, typer.Option(min=1, max=20)] = 3,
          max_findings: Annotated[int, typer.Option(min=1, max=2000)] = 500,
          case_id: Annotated[str | None, typer.Option("--case")] = None,
          state: State = DEFAULT_STATE, out: Annotated[Path, typer.Option()] = Path("reports")):
    """Paste one number, collect selected public evidence, and report possible email associations."""
    from .phone_workflow import PhoneRequest, run_phone

    interactive = number is None
    if interactive:
        number = typer.prompt("Paste phone number (include + and country code)")
    if purpose is None:
        purpose = typer.prompt("Purpose or engagement ID (at least 8 characters)")
    if not authorized and interactive:
        authorized = typer.confirm("I am authorized to research this number for the stated purpose")
    try:
        if not authorized:
            raise ValueError("Specify --authorized for this query after reviewing your scope")
        request = PhoneRequest(number=number, region=region, purpose=purpose, authorized=True,
                               search_web=search_web, seed_urls=page_url or [], allowed_hosts=allow_host or [],
                               terms_url=terms_url, max_pages=max_pages, max_findings=max_findings)
        request.context()  # Validate before recording any policy acceptance.
        if case_id:
            CaseStore(state).get(case_id)
        audit = AuditLog(state)
        if not audit.consented() and interactive:
            console.print(BANNER)
            if typer.confirm("Accept this policy for the local framework"):
                audit.accept_policy()
        outcome = asyncio.run(run_phone(request, state, out))
        if case_id:
            CaseStore(state).add(case_id, outcome.report)
        console.print(f"Normalized phone: {outcome.summary['number']}")
        console.print("Possible email associations: " + (", ".join(outcome.summary["emails"]) or "none found in the selected sources"))
        console.print(outcome.summary["association_note"])
        if not search_web and not page_url:
            console.print("Local metadata only. Add --search-web with a Brave key, or specify permitted --page-url sources.")
        for result in outcome.report.results:
            console.print(f"{result.module}: {result.status}" + (f" — {result.message}" if result.message else ""))
        for name, path in outcome.paths.items():
            console.print(f"{name}: {path}")
        console.print("Manual search links (not fetched; opening sends the query to that provider):")
        for link in outcome.summary["manual_search_links"]:
            console.print(f"{link['label']}: {link['url']}")
    except (ValueError, OSError, SourceError, SourceSkipped, RateLimited) as exc:
        failure(exc)
    except sqlite3.Error:
        failure(ValueError("Local audit storage is unavailable; collection stopped"))
    if any(result.status in {"error", "rate_limited"} for result in outcome.report.results):
        raise typer.Exit(1)


@app.command()
def desktop(state: State = DEFAULT_STATE, out: Annotated[Path, typer.Option()] = Path("reports"),
            phone_only: Annotated[bool, typer.Option("--phone-only")] = False):
    """Open the desktop investigation workbench for all supported input types."""
    try:
        from .desktop import launch

        launch(state.resolve(), out.resolve(), phone_only=phone_only)
    except ImportError:
        failure(ValueError('Desktop dependency missing. Install with: python -m pip install -e ".[desktop]"'))
    except RuntimeError as exc:
        failure(exc)


cases_app = typer.Typer(help="Create, inspect and review locally saved investigation cases.")
app.add_typer(cases_app, name="cases")


@cases_app.command("create")
def case_create(title: str, state: State = DEFAULT_STATE):
    try:
        console.print(CaseStore(state).create(title))
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@cases_app.command("list")
def case_list(state: State = DEFAULT_STATE):
    for item in CaseStore(state).list():
        console.print(f"{item['id']}  {item['title']}  ({item['runs']} runs)")


@cases_app.command("show")
def case_show(case_id: str, state: State = DEFAULT_STATE):
    try:
        store = CaseStore(state)
        typer.echo(json.dumps({"case": store.get(case_id), "history": store.history(case_id),
                                 "runs": [{"run_id": r.run_id, "query": r.context.query,
                                           "type": r.context.input_type, "at": r.created_at.isoformat()}
                                          for r in store.reports(case_id)]}, indent=2))
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@cases_app.command("note")
def case_note(case_id: str, text: str, state: State = DEFAULT_STATE):
    try:
        CaseStore(state).note(case_id, text)
        console.print("Case note saved")
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@cases_app.command("review")
def case_review(case_id: str, finding_id: str, decision: str, reason: str, state: State = DEFAULT_STATE):
    try:
        CaseStore(state).review(case_id, finding_id, decision, reason)
        console.print("Analyst review saved; original source claim retained")
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@cases_app.command("export")
def case_export(case_id: str, out: Path = Path("reports"), stix: bool = False, state: State = DEFAULT_STATE):
    try:
        report = CaseStore(state).combined(case_id)
        output_report(report, out)
        if stix:
            from .integrations.stix_exchange import export_stix

            path = out / report.run_id / "opencti.stix.json"
            path.write_text(json.dumps(export_stix(report), indent=2), encoding="utf-8")
            console.print(str(path.resolve()))
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@cases_app.command("verify")
def case_verify(case_id: str, state: State = DEFAULT_STATE):
    """Verify stored report digests and preserved evidence file hashes."""
    try:
        store = CaseStore(state)
        reports = store.reports(case_id)
        count = store.verify_artifacts(case_id)
        console.print(f"Verified {len(reports)} report digests and {count} evidence files")
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@app.command("doctor")
def doctor(state: State = DEFAULT_STATE, as_json: Annotated[bool, typer.Option("--json")] = False):
    """Check installed capabilities and last saved outcomes without provider requests."""
    from .catalog import inventory

    health = CaseStore(state).source_health() if (state / "cases.sqlite3").exists() else {}
    data = inventory(health=health)
    if as_json:
        typer.echo(json.dumps(data, indent=2))
    else:
        for row in data:
            console.print(f"{row['name']}: {row['mode']} — {row['setup']}")
        console.print("Ready means local setup is available; it does not verify provider access.")


@app.command("document")
def document(file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)], query: str,
             kind: Annotated[str, typer.Option("--type")], purpose: Annotated[str, typer.Option("--purpose")],
             authorized: Annotated[bool, typer.Option("--authorized")] = False,
             case_id: Annotated[str | None, typer.Option("--case")] = None,
             language: str = "eng", state: State = DEFAULT_STATE, out: Path = Path("reports")):
    """Extract scoped mentions from a local document; no provider query."""
    from .documents import import_document

    try:
        context = context_for(query, kind, purpose, authorized)
        if case_id:
            CaseStore(state).get(case_id)
        outcome = asyncio.run(import_document(context, file, state, out, case_id=case_id, language=language))
        for name, path in outcome.paths.items():
            console.print(f"{name}: {path.resolve()}")
    except (ValueError, OSError, sqlite3.Error) as exc:
        failure(exc)


@app.command("export-stix")
def export_stix_file(file: Annotated[Path, typer.Argument(exists=True, dir_okay=False)], out: Path = Path("opencti.stix.json")):
    """Convert a framework report to an offline STIX 2.1 bundle for OpenCTI."""
    from .core.schema import RunReport
    from .integrations.stix_exchange import export_stix

    try:
        if file.stat().st_size > 20_000_000:
            raise ValueError("Report exceeds the 20 MB input limit")
        report = RunReport.model_validate_json(file.read_text(encoding="utf-8"))
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(export_stix(report), indent=2), encoding="utf-8")
        console.print(str(out.resolve()))
    except (ValueError, OSError) as exc:
        failure(exc)


from .commands_v04 import register_commands  # noqa: E402

register_commands(app)

from .commands_v05 import register_commands as register_v05  # noqa: E402

register_v05(app)

from .commands_research import register_commands as register_research  # noqa: E402

register_research(app)

if __name__ == "__main__":
    app()
