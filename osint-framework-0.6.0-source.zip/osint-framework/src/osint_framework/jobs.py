"""Persistent local job queue, finite schedules, leases, and cooperative cancellation."""

import asyncio
import json
import threading
import time
import uuid

from .catalog import modules
from .core.cases import CaseStore
from .core.schema import QueryContext
from .workflow import investigate

TERMINAL = {"succeeded", "partial", "failed", "cancelled", "stale"}


class LeaseLostError(ValueError):
    """The worker must stop without changing a job owned by another lease."""


class JobStore(CaseStore):
    def __init__(self, state):
        super().__init__(state)
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, case_id TEXT NOT NULL REFERENCES cases(id), context TEXT NOT NULL,
                    sources TEXT NOT NULL, status TEXT NOT NULL, created REAL NOT NULL, due REAL NOT NULL,
                    lease TEXT, lease_until REAL, cancelled INTEGER NOT NULL DEFAULT 0,
                    run_id TEXT, error TEXT, interval_seconds INTEGER NOT NULL DEFAULT 0,
                    remaining INTEGER NOT NULL DEFAULT 1, parent_id TEXT, actor TEXT NOT NULL DEFAULT 'local');
                CREATE INDEX IF NOT EXISTS due_jobs ON jobs(status,due);
            """)

    def enqueue(self, case_id, context, sources, *, due=None, interval_seconds=0, repeat=1, actor="local"):
        self.get(case_id)
        context = QueryContext.model_validate(context)
        available = modules()
        if not sources or len(sources) > 30 or len(set(sources)) != len(sources):
            raise ValueError("Choose 1–30 distinct sources")
        if any(name not in available or context.input_type not in available[name].spec.input_types for name in sources):
            raise ValueError("Unknown or incompatible job source")
        if not 1 <= repeat <= 100 or (repeat > 1 and not 3600 <= interval_seconds <= 31_536_000):
            raise ValueError("Schedules need 1–100 runs and an interval of at least one hour")
        if interval_seconds < 0 or (due is not None and (not isinstance(due, (int, float)) or not 0 <= due <= time.time() + 31_536_000)):
            raise ValueError("Invalid scheduled time")
        identifier = str(uuid.uuid4())
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            count = db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]
            if count >= 1000:
                raise ValueError("Queue has reached its 1000-pending-job limit")
            db.execute("INSERT INTO jobs(id,case_id,context,sources,status,created,due,interval_seconds,remaining,actor) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (identifier, case_id, self.vault.encode(context.model_dump_json(), "job:" + identifier), json.dumps(sources),
                 "queued", time.time(), time.time() if due is None else due, interval_seconds, repeat, actor))
        return identifier

    def job(self, identifier):
        with self.connect() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (identifier,)).fetchone()
        if not row:
            raise ValueError("Job does not exist")
        result = dict(row)
        result["context"] = json.loads(self.vault.decode(result["context"], "job:" + identifier))
        result["sources"] = json.loads(result["sources"])
        result.pop("lease", None)
        return result

    def jobs(self, case_id=None):
        with self.connect() as db:
            query = "SELECT id FROM jobs" + (" WHERE case_id=?" if case_id else "") + " ORDER BY created DESC LIMIT 200"
            ids = [row[0] for row in db.execute(query, (case_id,) if case_id else ())]
        return [self.job(identifier) for identifier in ids]

    def claim(self, *, now=None):
        now = time.time() if now is None else now
        lease = str(uuid.uuid4())
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            # A crashed worker may already have sent requests: do not replay automatically.
            db.execute("UPDATE jobs SET status='stale',error='Worker lease expired; inspect evidence before retrying' WHERE status='running' AND lease_until<?", (now,))
            row = db.execute("SELECT id FROM jobs WHERE status='queued' AND due<=? AND cancelled=0 ORDER BY due,created LIMIT 1", (now,)).fetchone()
            if not row:
                return None
            db.execute("UPDATE jobs SET status='running',lease=?,lease_until=? WHERE id=?", (lease, now + 90, row[0]))
        return self.job(row[0]), lease

    def heartbeat(self, identifier, lease):
        with self.connect() as db:
            changed = db.execute("UPDATE jobs SET lease_until=? WHERE id=? AND lease=? AND status='running'", (time.time() + 90, identifier, lease)).rowcount
            row = db.execute("SELECT cancelled FROM jobs WHERE id=?", (identifier,)).fetchone()
        return bool(changed and row and not row[0])

    def cancel(self, identifier):
        self.job(identifier)
        with self.connect() as db:
            db.execute("UPDATE jobs SET cancelled=1,remaining=1,status=CASE WHEN status='queued' THEN 'cancelled' ELSE status END WHERE id=?", (identifier,))
            # A schedule is a parent chain. Cancel queued descendants of this run too.
            db.execute("""WITH RECURSIVE descendants(id) AS (SELECT id FROM jobs WHERE parent_id=?
                UNION ALL SELECT jobs.id FROM jobs JOIN descendants ON jobs.parent_id=descendants.id)
                UPDATE jobs SET cancelled=1,remaining=1,status=CASE WHEN status='queued' THEN 'cancelled' ELSE status END
                WHERE id IN (SELECT id FROM descendants)""", (identifier,))

    def finish(self, identifier, lease, status, *, run_id=None, error=None):
        if status not in TERMINAL:
            raise ValueError("Invalid completed job status")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM jobs WHERE id=? AND lease=? AND status='running'", (identifier, lease)).fetchone()
            if not row:
                raise LeaseLostError("Worker no longer holds this job lease")
            if row["cancelled"]:
                status = "cancelled"
            db.execute("UPDATE jobs SET status=?,run_id=?,error=?,lease=NULL,lease_until=NULL WHERE id=?",
                       (status, run_id, error, identifier))
            if row["remaining"] > 1 and not row["cancelled"] and status in {"succeeded", "partial"}:
                next_id = str(uuid.uuid4())
                context = self.vault.decode(row["context"], "job:" + identifier)
                db.execute("INSERT INTO jobs(id,case_id,context,sources,status,created,due,interval_seconds,remaining,parent_id,actor) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (next_id, row["case_id"], self.vault.encode(context, "job:" + next_id), row["sources"], "queued", time.time(),
                     time.time() + row["interval_seconds"], row["interval_seconds"], row["remaining"] - 1, identifier, row["actor"]))


async def work_once(state, out, *, runner=investigate, stop_event=None):
    store = JobStore(state)
    claimed = store.claim()
    if not claimed:
        return None
    job, lease = claimed
    stop = stop_event or threading.Event()

    async def pulse():
        while True:
            if not store.heartbeat(job["id"], lease):
                stop.set()
            await asyncio.sleep(1)

    heartbeat = asyncio.create_task(pulse())
    def finish(status, **fields):
        try:
            store.finish(job["id"], lease, status, **fields)
        except LeaseLostError:
            stop.set()

    try:
        if stop.is_set():
            finish("cancelled", error="Worker stopped before collection")
            return store.job(job["id"])
        if job["actor"] != "local":
            from .team import TeamStore
            team = TeamStore(state)
            principal = team.active_user(job["actor"])
            if not principal or not team.allowed(dict(principal), job["case_id"], True):
                finish("cancelled", error="Submitting user no longer has case access")
                return store.job(job["id"])
        context = QueryContext.model_validate(job["context"])
        outcome = await runner(context, job["sources"], state, out, case_id=job["case_id"], cancel_event=stop)
        statuses = {result.status for result in outcome.report.results}
        status = ("cancelled" if stop.is_set() or "cancelled" in statuses else "succeeded" if statuses <= {"ok", "empty"}
                  else "partial" if statuses & {"ok", "empty"} else "failed")
        finish(status, run_id=outcome.report.run_id)
    except asyncio.CancelledError:
        stop.set()
        finish("cancelled", error="Worker stopped")
        raise
    except Exception as exc:
        finish("failed", error=f"Job failed ({type(exc).__name__}); inspect source setup and local storage")
    finally:
        heartbeat.cancel()
        await asyncio.gather(heartbeat, return_exceptions=True)
    return store.job(job["id"])
