"""Built-in source adapters."""
