"""Scrapy extraction with the framework's scoped, DNS-pinned HTTP transport."""

import hashlib
from collections import deque
from importlib.metadata import version
from urllib.parse import unquote, urlsplit

from ..core.http import SourceSkipped
from ..core.schema import Entity, Finding, ModuleSpec
from ..phone import public_text
from .webpage import _page_url, _parse_robots


class ScrapyPagesModule:
    spec = ModuleSpec(name="scrapy_pages", input_types=["url", "domain"], rate_limit_per_min=6,
                      description="Scrapy HTML extraction and bounded same-origin crawl through reviewed public-page transport",
                      terms_url="https://docs.scrapy.org/en/latest/")

    async def run(self, context, http):
        try:
            import scrapy
            from scrapy.http import HtmlResponse
        except ImportError as exc:
            raise SourceSkipped('Install the crawler extra: python -m pip install ".[crawler]"') from exc
        seed = _page_url(context.query if context.input_type == "url" else "https://" + context.query + "/")
        if not seed or urlsplit(seed).hostname not in context.allowed_hosts or not context.terms_url:
            raise SourceSkipped("Scrapy collection needs a permitted HTTPS URL, exact allowed host, and permission reference")
        origin = ("https", urlsplit(seed).hostname, 443)
        robots_url = f"https://{origin[1]}/robots.txt"
        robots = _parse_robots(await http.get_text(robots_url, source="webpage", rate_limit_per_min=6,
                                                  not_found_ok=True, pinned=True, allowed_content_types=("text/plain",)))
        if not robots.permits(seed):
            raise SourceSkipped("robots.txt disallows the seed page")

        class PublicPageSpider(scrapy.Spider):
            name = "osint_scoped_pages"

            def parse(self, response):
                yield {"title": response.css("title::text").get(default="")[:300],
                       "links": response.css("a::attr(href)").getall()[:2000]}

        spider = PublicPageSpider()
        pending, queued, findings = deque([seed]), {seed}, []
        while pending and len(queued) <= context.max_pages:
            url = pending.popleft()
            if not robots.permits(url):
                continue
            body = await http.get_text(url, source="webpage", rate_limit_per_min=robots.rate_limit_per_min,
                                       not_found_ok=True, pinned=True,
                                       allowed_content_types=("text/html", "application/xhtml+xml"))
            if body is None:
                continue
            response = HtmlResponse(url=url, body=body.encode(), encoding="utf-8")
            item = next(spider.parse(response))
            text, _ = public_text(body)
            meta = {"title": item["title"], "excerpt": text[:1000],
                    "content_sha256": hashlib.sha256(body.encode()).hexdigest(),
                    "digest_scope": "UTF-8 re-encoded response text", "scrapy_version": version("scrapy"),
                    "robots_url": robots_url, "collection_mode": "framework transport; Scrapy selector/spider extraction"}

            def add(relation, obj):
                findings.append(Finding(source=self.spec.name, subject=Entity(kind="url", value=url), relation=relation,
                                        object=obj, evidence_url=url, confidence="certain",
                                        legal_basis=f"Operator-reviewed collection reference: {context.terms_url}", metadata=meta))

            add("page_observed", Entity(kind="url", value=url))
            for href in item["links"]:
                if len(findings) > context.max_findings:
                    return findings[:context.max_findings + 1]
                if href.lower().startswith("mailto:"):
                    try:
                        address = unquote(href[7:].split("?", 1)[0])
                        if "," not in address and ";" not in address:
                            add("publishes_email", Entity(kind="email", value=address))
                    except ValueError:
                        pass
                    continue
                link = _page_url(response.urljoin(href), origin)
                if link:
                    add("links_to", Entity(kind="url", value=link))
                    if link not in queued and len(queued) < context.max_pages and robots.permits(link):
                        pending.append(link)
                        queued.add(link)
        return findings[:context.max_findings + 1]
