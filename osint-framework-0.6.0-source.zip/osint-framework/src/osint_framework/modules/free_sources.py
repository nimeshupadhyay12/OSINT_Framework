"""Documented public read APIs; search hits and historical records remain source claims."""

import ipaddress
import re
from datetime import datetime, timezone
from urllib.parse import quote, urlsplit

from ..core.credentials import get_secret
from ..core.http import SourceSkipped
from ..core.schema import ModuleSpec, normalize
from .native import NativeModule, _array, _object, _selected, _text


def public_ip(value):
    address = ipaddress.ip_address(value)
    if not address.is_global:
        raise SourceSkipped("This index accepts globally routable IP addresses only")
    return address


class InternetDBModule(NativeModule):
    spec = ModuleSpec(name="internetdb", input_types=["ip"], rate_limit_per_min=10,
        description="Shodan InternetDB recorded ports, hostnames and CVE labels; no key, non-commercial terms.",
        terms_url="https://blog.shodan.io/introducing-the-internetdb-api/")

    async def run(self, context, http):
        address = public_ip(context.query)
        if address.version != 4:
            raise SourceSkipped("InternetDB adapter supports IPv4 only")
        endpoint = "https://internetdb.shodan.io/" + str(address)
        data = await self.get(http, endpoint, not_found_ok=True)
        if data is None:
            return []
        data = _object(data)
        if normalize("ip", data.get("ip", "")) != context.query:
            raise ValueError("InternetDB returned another IP")
        ports = _array(data.get("ports", []))
        if any(type(port) is not int or not 1 <= port <= 65535 for port in ports):
            raise ValueError("Invalid recorded ports")
        meta = {"ports": ports, "tags": _array(data.get("tags", []))[:50],
                "cpes": _array(data.get("cpes", []))[:50], "timestamp_kind": "retrieved_at",
                "note": "Existing index data; reported CVEs are not independently verified vulnerabilities."}
        findings = [self.finding(context, "indexed_host_summary", "ip", context.query, endpoint, metadata=meta)]
        for host in _array(data.get("hostnames", []))[:context.max_findings]:
            findings.append(self.finding(context, "index_reports_hostname", "domain", host, endpoint, confidence="tentative"))
        for cve in _array(data.get("vulns", []))[:context.max_findings]:
            if isinstance(cve, str) and re.fullmatch(r"CVE-\d{4}-\d{4,}", cve):
                findings.append(self.finding(context, "index_reports_cve", "record", cve, endpoint, confidence="tentative"))
        return findings[:context.max_findings + 1]


class RIPEModule(NativeModule):
    spec = ModuleSpec(name="ripe", input_types=["ip"], rate_limit_per_min=10,
        description="RIPE RIS containing network prefix and announcing ASNs; public read API.",
        terms_url="https://stat.ripe.net/docs/data-api/api-endpoints/network-info")

    async def run(self, context, http):
        address = public_ip(context.query)
        endpoint = "https://stat.ripe.net/data/network-info/data.json"
        response = _object(await self.get(http, endpoint, params={"resource": str(address)}))
        if response.get("status") != "ok":
            raise ValueError("RIPE did not return an OK result")
        data = _object(response.get("data"))
        if not data.get("prefix"):
            return []
        network = ipaddress.ip_network(data["prefix"])
        if address not in network:
            raise ValueError("RIPE prefix does not contain the requested IP")
        evidence = endpoint + "?resource=" + quote(str(address), safe="")
        findings = [self.finding(context, "announced_in_prefix", "record", str(network), evidence,
                    metadata={"timestamp_kind": "retrieved_at", "source_version": response.get("version"),
                              "note": "Routing data does not establish physical location or ownership."})]
        for asn in _array(data.get("asns", [])):
            if not re.fullmatch(r"\d{1,10}", str(asn)) or not 1 <= int(asn) <= 4294967295:
                raise ValueError("Invalid RIPE ASN")
            findings.append(self.finding(context, "announced_by_asn", "record", "AS" + str(asn), evidence))
        return findings[:context.max_findings + 1]


class WaybackModule(NativeModule):
    spec = ModuleSpec(name="wayback", input_types=["domain", "url"], rate_limit_per_min=6,
        description="Internet Archive closest available page snapshot; historical evidence, no archive submission.",
        terms_url="https://archive.org/help/wayback_api.php")

    async def run(self, context, http):
        target = "https://" + context.query + "/" if context.input_type == "domain" else context.query
        data = _object(await self.get(http, "https://archive.org/wayback/available", params={"url": target}))
        closest = _object(data.get("archived_snapshots", {})).get("closest")
        if not closest:
            return []
        closest = _object(closest)
        if closest.get("available") is not True or str(closest.get("status")) != "200":
            return []
        snapshot = normalize("url", closest.get("url", ""))
        parsed = urlsplit(snapshot)
        match = re.fullmatch(r"/web/(\d{14})/(https?://.+)", parsed.path)
        if parsed.hostname != "web.archive.org" or not match:
            raise ValueError("Unexpected archive locator")
        original = normalize("url", match[2] + ("?" + parsed.query if parsed.query else ""))
        source_url = urlsplit(original)
        expected = urlsplit(target)
        if source_url.hostname != expected.hostname or source_url.path != expected.path or source_url.query != expected.query:
            raise ValueError("Archived URL differs from query scope")
        when = datetime.strptime(match[1], "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
        finding = self.finding(context, "has_archived_snapshot", "url", snapshot, snapshot,
            metadata={"original_url": original, "capture_timestamp": match[1],
                      "timestamp_kind": "archive_capture", "note": "Archive availability is not current page availability."})
        finding.observed_at = when
        return [finding]


class WikidataModule(NativeModule):
    spec = ModuleSpec(name="wikidata", input_types=["name"], rate_limit_per_min=10,
        description="Up to ten Wikidata label/alias search candidates; no identity resolution.",
        terms_url="https://www.wikidata.org/wiki/Wikidata:Data_access")

    async def run(self, context, http):
        response = _object(await self.get(http, "https://www.wikidata.org/w/api.php",
            params={"action": "wbsearchentities", "search": context.query, "language": "en", "format": "json", "limit": 10}))
        if "error" in response or "search" not in response:
            raise ValueError("Wikidata search failed")
        findings = []
        for row in _array(response["search"]):
            row = _object(row)
            identifier = row.get("id", "")
            if not isinstance(identifier, str) or not re.fullmatch(r"Q[1-9]\d*", identifier):
                raise ValueError("Invalid Wikidata item")
            url = "https://www.wikidata.org/wiki/" + identifier
            findings.append(self.finding(context, "knowledge_search_candidate", "url", url, url, confidence="tentative",
                metadata={**_selected(row, ("label", "description")), "wikidata_id": identifier, "ownership_verified": False}))
        return findings[:context.max_findings + 1]


class WikipediaModule(NativeModule):
    spec = ModuleSpec(name="wikipedia", input_types=["name", "domain"], rate_limit_per_min=10,
        description="Up to ten English Wikipedia article search candidates; public API, no key.",
        terms_url="https://www.mediawiki.org/wiki/API:Search")

    async def run(self, context, http):
        response = _object(await self.get(http, "https://en.wikipedia.org/w/api.php", params={
            "action": "query", "list": "search", "srsearch": context.query, "srlimit": 10, "format": "json", "srprop": "timestamp"}))
        if "error" in response or "query" not in response:
            raise ValueError("Wikipedia search failed")
        findings = []
        for row in _array(_object(response["query"]).get("search")):
            row = _object(row)
            if type(row.get("pageid")) is not int or row["pageid"] <= 0:
                raise ValueError("Invalid Wikipedia page ID")
            url = "https://en.wikipedia.org/?curid=" + str(row["pageid"])
            findings.append(self.finding(context, "encyclopedia_search_candidate", "url", url, url,
                confidence="tentative", metadata=_selected(row, ("title", "timestamp", "pageid"))))
        return findings[:context.max_findings + 1]


class HackerNewsModule(NativeModule):
    spec = ModuleSpec(name="hackernews", input_types=["username"], rate_limit_per_min=10,
        description="One exact public Hacker News user record; submitted items are not traversed.",
        terms_url="https://github.com/HackerNews/API")

    async def run(self, context, http):
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,50}", context.query):
            raise SourceSkipped("Unsupported Hacker News username syntax")
        endpoint = "https://hacker-news.firebaseio.com/v0/user/" + quote(context.query, safe="") + ".json"
        data = await self.get(http, endpoint, not_found_ok=True)
        if data is None:
            return []
        data = _object(data)
        if data.get("id") != context.query:
            raise ValueError("Hacker News returned a different user")
        return [self.finding(context, "observed_profile", "profile", "https://news.ycombinator.com/user?id=" + quote(context.query),
            endpoint, metadata=_selected(data, ("id", "created", "karma")))]


class EmailDNSModule(NativeModule):
    spec = ModuleSpec(name="email_dns", input_types=["email"], rate_limit_per_min=10,
        description="Public DNS MX/SPF/DMARC configuration for an email domain; mailbox existence stays unknown.",
        terms_url="https://developers.google.com/speed/public-dns/docs/doh/json")

    async def run(self, context, http):
        domain = context.query.rsplit("@", 1)[1]
        findings = [self.finding(context, "uses_email_domain", "domain", domain,
            "https://dns.google/resolve?name=" + domain + "&type=MX",
            metadata={"mailbox_verified": False, "note": "DNS cannot establish whether this mailbox exists."})]
        for name, kind in ((domain, "MX"), (domain, "TXT"), ("_dmarc." + domain, "TXT")):
            data = _object(await self.get(http, "https://dns.google/resolve", params={"name": name, "type": kind}))
            if data.get("Status") not in (0, 3):
                raise ValueError("DNS resolver returned a failure")
            for row in _array(data.get("Answer", [])):
                row = _object(row)
                if str(row.get("name", "")).rstrip(".").lower() != name or row.get("type") not in (15, 16):
                    continue
                value = _text(row.get("data"), 2000)
                if kind == "TXT" and not value.strip('"').lower().startswith(("v=spf1", "v=dmarc1")):
                    continue
                findings.append(self.finding(context, "email_domain_dns_record", "record", value,
                    "https://dns.google/resolve?name=" + name + "&type=" + kind,
                    metadata={"dns_owner": name, "record_type": row["type"], "mailbox_verified": False}))
        return findings[:context.max_findings + 1]


class URLScanModule(NativeModule):
    spec = ModuleSpec(name="urlscan", input_types=["domain", "ip"], rate_limit_per_min=5,
        key_env=["URLSCAN_API_KEY"], description="Existing urlscan public scans; free account key and account quotas required; no submission.",
        terms_url="https://urlscan.io/docs/api/")

    async def run(self, context, http):
        if context.input_type == "ip":
            public_ip(context.query)
        field = "page.ip" if context.input_type == "ip" else "page.domain"
        response = _object(await self.get(http, "https://urlscan.io/api/v1/search/", params={
            "q": f'{field}:"{context.query}" AND task.visibility:public', "size": 20},
            headers={"api-key": get_secret("URLSCAN_API_KEY")}))
        findings = []
        for row in _array(response.get("results")):
            row = _object(row)
            page, task = _object(row.get("page")), _object(row.get("task"))
            expected = normalize(context.input_type, page.get("ip" if context.input_type == "ip" else "domain", ""))
            if expected != context.query or task.get("visibility", "public") != "public":
                continue
            identifier = str(row.get("_id", ""))
            if not re.fullmatch(r"[0-9a-fA-F-]{36}", identifier):
                raise ValueError("Invalid urlscan result identifier")
            evidence = "https://urlscan.io/result/" + identifier + "/"
            findings.append(self.finding(context, "indexed_scan_url", "url", page["url"], evidence, confidence="tentative",
                metadata={"scan_time": task.get("time"), "scan_id": identifier,
                          "note": "Historical public scan; no scan was submitted or repeated."}))
        return findings[:context.max_findings + 1]


def free_modules():
    return [InternetDBModule(), RIPEModule(), WaybackModule(), WikidataModule(), WikipediaModule(),
            HackerNewsModule(), EmailDNSModule(), URLScanModule()]
