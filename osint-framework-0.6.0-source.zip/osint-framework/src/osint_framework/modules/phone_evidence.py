"""Phone-to-public-evidence adapters: indexed snippets and explicitly approved pages."""

import hashlib
from urllib.parse import urlsplit

from ..core.credentials import get_secret
from ..core.http import SourceSkipped
from ..core.schema import Entity, Finding, ModuleSpec
from ..phone import nearby_emails, phone_matches, phone_variants, public_text
from .webpage import _page_url, _parse_robots

ASSOCIATION_NOTE = (
    "The number and email appear near each other in this source. This does not establish "
    "ownership: shared business contacts, recycled numbers, stale records, and unrelated text are possible."
)


def evidence_findings(context, text, url, title, source, legal_basis, *, snippet=False):
    matches = phone_matches(text, context.query)
    if not matches:
        return []
    metadata = {"title": title[:300], "evidence_type": "search_snippet" if snippet else "public_page",
                "exact_number_match": True, "matched_formats": list(dict.fromkeys(m["text"] for m in matches)),
                "national_format_assumes_query_country": any(m["national_format"] for m in matches),
                "content_sha256": hashlib.sha256(text.encode()).hexdigest(),
                "digest_scope": "normalized extracted text, capped at 100000 characters",
                "ownership_verified": False,
                "note": "A visible number match is a source observation; account or subscriber ownership is unknown."}
    first = matches[0]
    metadata["excerpt"] = text[max(0, first["start"] - 100):first["end"] + 180]
    findings = [Finding(source=source, subject=context.entity, relation="public_number_mention",
                        object=Entity(kind="url", value=url), confidence="tentative" if snippet or all(m["national_format"] for m in matches) else "certain",
                        evidence_url=url, legal_basis=legal_basis, metadata=metadata)]
    for item in nearby_emails(text, matches):
        findings.append(Finding(source=source, subject=context.entity, relation="email_near_number",
                                object=Entity(kind="email", value=item["email"]), confidence="tentative",
                                evidence_url=url, legal_basis=legal_basis,
                                metadata={**metadata, "excerpt": item["excerpt"], "note": ASSOCIATION_NOTE,
                                          "national_format_assumes_query_country": item["national_format"]}))
        if len(findings) > context.max_findings:
            break
    return findings


class PhoneSearchModule:
    spec = ModuleSpec(name="phone_search", input_types=["phone"], key_env=["BRAVE_SEARCH_API_KEY"],
                      description="Exact-number web search; nearby published emails are unverified leads",
                      rate_limit_per_min=5,
                      terms_url="https://api-dashboard.search.brave.com/api-reference/web/search/get")

    def __init__(self, api_key=None):
        self._api_key = api_key
        if api_key:
            # A session-only UI key is never added to QueryContext or report metadata.
            self.spec = self.spec.model_copy(update={"key_env": []})

    async def run(self, context, http):
        query = " OR ".join('"' + value + '"' for value in phone_variants(context.query))
        payload = await http.get_json("https://api.search.brave.com/res/v1/web/search",
                                      source="brave", rate_limit_per_min=5,
                                      params={"q": query, "count": 20, "text_decorations": "false",
                                              "spellcheck": "false", "result_filter": "web"},
                                      headers={"X-Subscription-Token": self._api_key or get_secret("BRAVE_SEARCH_API_KEY")})
        if not isinstance(payload, dict) or not isinstance(payload.get("web", {}), dict):
            raise ValueError("Search provider response has an unsupported shape")
        rows = payload.get("web", {}).get("results", [])
        if not isinstance(rows, list):
            raise ValueError("Search provider results are malformed")
        findings, seen = [], set()
        for row in rows[:20]:
            if not isinstance(row, dict):
                raise ValueError("Search provider result is malformed")
            url = _page_url(str(row.get("url", "")))
            if not url or url in seen:
                continue
            seen.add(url)
            document = str(row.get("title", ""))[:500] + " " + str(row.get("description", ""))[:5000]
            text, _ = public_text(document)
            findings.extend(evidence_findings(context, text, url, str(row.get("title", "")), self.spec.name,
                            f"Brave documented search API: {self.spec.terms_url}", snippet=True))
            if len(findings) > context.max_findings:
                break
        return findings[:context.max_findings + 1]


class PhonePagesModule:
    spec = ModuleSpec(name="phone_pages", input_types=["phone"],
                      description="Find the number and nearby public emails on specifically permitted pages",
                      rate_limit_per_min=6, terms_url="https://www.rfc-editor.org/rfc/rfc9309.html")

    async def run(self, context, http):
        if not context.seed_urls or not context.terms_url:
            raise SourceSkipped("Add approved page URLs and a permission reference to check public-page evidence")
        seeds = list(dict.fromkeys(context.seed_urls))
        for seed in seeds:
            safe = _page_url(seed)
            if not safe or urlsplit(safe).hostname not in context.allowed_hosts:
                raise SourceSkipped("Every page requires HTTPS, exact allowed hostname, and a supported public path")
        findings, robots_cache = [], {}
        for seed in seeds[:context.max_pages]:
            host = urlsplit(seed).hostname
            if host not in robots_cache:
                robots_cache[host] = _parse_robots(await http.get_text(f"https://{host}/robots.txt",
                    source="webpage", rate_limit_per_min=6, not_found_ok=True, pinned=True,
                    allowed_content_types=("text/plain",)))
            robots = robots_cache[host]
            if not robots.permits(seed):
                raise SourceSkipped("robots.txt disallows an approved page; that page was not retrieved")
            document = await http.get_text(seed, source="webpage", rate_limit_per_min=robots.rate_limit_per_min,
                                          not_found_ok=True, pinned=True,
                                          allowed_content_types=("text/html", "application/xhtml+xml"))
            if document is None:
                continue
            text, title = public_text(document)
            findings.extend(evidence_findings(context, text, seed, title, self.spec.name,
                            f"Operator-reviewed public-page permission: {context.terms_url}"))
            if len(findings) > context.max_findings:
                break
        return findings[:context.max_findings + 1]
