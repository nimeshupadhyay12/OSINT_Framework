"""Bounded index lookups. Threat labels are provider claims, never verdicts."""

import ipaddress
import json
import re
from urllib.parse import quote, urlencode, urlsplit

from ..core.credentials import get_secret
from ..core.http import SourceSkipped
from ..core.schema import ModuleSpec, normalize
from .free_sources import public_ip
from .native import NativeModule, _array, _object, _selected


def key(name):
    value = get_secret(name)
    if not value:
        raise SourceSkipped("Configure " + name + " in Sources and credentials")
    return value


class CertSpotterModule(NativeModule):
    spec = ModuleSpec(name="certspotter", input_types=["domain"], key_env=["CERTSPOTTER_API_KEY"], rate_limit_per_min=1,
        description="One page of certificate issuances; free account quota, names are certificate claims.",
        terms_url="https://sslmate.com/ct_search_api/")

    async def run(self, context, http):
        endpoint = "https://api.certspotter.com/v1/issuances"
        params = {"domain": context.query, "include_subdomains": "true", "expand": "dns_names"}
        rows = _array(await self.get(http, endpoint, params=params, headers={"Authorization": "Bearer " + key("CERTSPOTTER_API_KEY")}))
        found = {}
        for row in rows:
            row = _object(row)
            for name in _array(row.get("dns_names", [])):
                if not isinstance(name, str):
                    raise ValueError("Invalid certificate DNS name")
                name = normalize("domain", name.removeprefix("*."))
                if name != context.query and not name.endswith("." + context.query):
                    continue
                if name not in found:
                    found[name] = self.finding(context, "certificate_lists_name", "domain", name,
                        endpoint + "?" + urlencode(params), confidence="tentative",
                        metadata={**_selected(row, ("id", "not_before", "not_after")), "coverage": "first_page_only", "timestamp_kind": "retrieved_at"})
                if len(found) > context.max_findings:
                    return list(found.values())
        return list(found.values())


class CommonCrawlModule(NativeModule):
    spec = ModuleSpec(name="commoncrawl", input_types=["domain"], rate_limit_per_min=2,
        description="First index page from the latest Common Crawl collection; historical URLs only, no page downloads.",
        terms_url="https://index.commoncrawl.org/")

    async def run(self, context, http):
        collections = _array(await self.get(http, "https://index.commoncrawl.org/collinfo.json"))
        if not collections:
            return []
        identifier = _object(collections[0]).get("id", "")
        if not isinstance(identifier, str) or not re.fullmatch(r"CC-MAIN-\d{4}-\d{2}", identifier):
            raise ValueError("Invalid Common Crawl index identifier")
        endpoint = "https://index.commoncrawl.org/" + identifier + "-index"
        params = {"url": context.query, "matchType": "domain", "output": "json", "filter": "status:200", "page": "0", "pageSize": "1"}
        text = await http.get_text(endpoint, source=self.spec.name, rate_limit_per_min=2, params=params, not_found_ok=True)
        found = {}
        for line in (text or "").splitlines():
            row = _object(json.loads(line))
            url = normalize("url", row.get("url", ""))
            host = urlsplit(url).hostname
            if host != context.query and not host.endswith("." + context.query):
                raise ValueError("Common Crawl URL outside requested domain")
            if url not in found:
                found[url] = self.finding(context, "historically_indexed_url", "url", url, endpoint + "?" + urlencode(params),
                    confidence="tentative", metadata={**_selected(row, ("timestamp", "digest", "status", "mime")), "collection": identifier,
                    "coverage": "first_index_page_only", "timestamp_kind": "retrieved_at"})
            if len(found) > context.max_findings:
                break
        return list(found.values())


class OTXModule(NativeModule):
    spec = ModuleSpec(name="otx", input_types=["domain", "ip", "url"], key_env=["OTX_API_KEY"], rate_limit_per_min=4,
        description="OTX indicator summary and pulse count; community threat claims, free account key.",
        terms_url="https://github.com/AlienVault-OTX/OTX-Python-SDK")

    async def run(self, context, http):
        kind = context.input_type
        if kind == "ip":
            kind = "IPv4" if public_ip(context.query).version == 4 else "IPv6"
        endpoint = "https://otx.alienvault.com/api/v1/indicators/" + kind + "/" + quote(context.query, safe="") + "/general"
        row = _object(await self.get(http, endpoint, headers={"X-OTX-API-KEY": key("OTX_API_KEY")}))
        if normalize(context.input_type, row.get("indicator", "")) != context.query:
            raise ValueError("OTX returned another indicator")
        count = _object(row.get("pulse_info", {})).get("count", 0)
        if type(count) is not int or count < 0:
            raise ValueError("Invalid OTX pulse count")
        return [self.finding(context, "otx_indicator_summary", context.input_type, context.query, endpoint,
            confidence="tentative", metadata={"pulse_count": count, "timestamp_kind": "retrieved_at",
                "note": "A pulse association is not proof of malicious activity; zero is not proof of safety."})]


class URLhausModule(NativeModule):
    spec = ModuleSpec(name="urlhaus", input_types=["domain", "ip", "url"], key_env=["ABUSECH_AUTH_KEY"], rate_limit_per_min=4,
        description="URLhaus exact host/URL lookup; URL metadata only, no payload download or submission.",
        terms_url="https://urlhaus-api.abuse.ch/")

    async def run(self, context, http):
        if context.input_type == "ip":
            public_ip(context.query)
        field = "url" if context.input_type == "url" else "host"
        endpoint = "https://urlhaus-api.abuse.ch/v1/" + field + "/"
        row = _object(await http.lookup_json(endpoint, source=self.spec.name, rate_limit_per_min=4,
            payload={field: context.query}, headers={"Auth-Key": key("ABUSECH_AUTH_KEY")}))
        if row.get("query_status") in {"no_results", "no_result"}:
            return []
        if row.get("query_status") != "ok":
            raise ValueError("URLhaus lookup failed")
        rows = [row] if field == "url" else _array(row.get("urls", []))
        findings = []
        for record in rows[:context.max_findings + 1]:
            record = _object(record)
            url = normalize("url", record.get("url", ""))
            if (field == "url" and url != context.query) or (field == "host" and urlsplit(url).hostname != context.query):
                raise ValueError("URLhaus returned out-of-scope URL")
            findings.append(self.finding(context, "urlhaus_reports_url", "url", url, endpoint,
                confidence="tentative", metadata={**_selected(record, ("id", "url_status", "threat", "date_added", "firstseen", "last_online")),
                "timestamp_kind": "retrieved_at", "note": "Provider threat label; not an independently verified verdict."}))
        return findings


class ThreatFoxModule(NativeModule):
    spec = ModuleSpec(name="threatfox", input_types=["domain", "ip", "url"], key_env=["ABUSECH_AUTH_KEY"], rate_limit_per_min=4,
        description="ThreatFox exact IOC search; threat labels only, no malware download or submission.",
        terms_url="https://threatfox.abuse.ch/api/")

    async def run(self, context, http):
        if context.input_type == "ip":
            public_ip(context.query)
        endpoint = "https://threatfox-api.abuse.ch/api/v1/"
        row = _object(await http.lookup_json(endpoint, source=self.spec.name, rate_limit_per_min=4,
            payload={"query": "search_ioc", "search_term": context.query, "exact_match": True},
            headers={"Auth-Key": key("ABUSECH_AUTH_KEY")}))
        if row.get("query_status") in {"no_result", "no_results"}:
            return []
        if row.get("query_status") != "ok":
            raise ValueError("ThreatFox lookup failed")
        findings = []
        for record in _array(row.get("data"))[:context.max_findings + 1]:
            record = _object(record)
            ioc = record.get("ioc", "")
            if record.get("ioc_type") == "ip:port" and context.input_type == "ip":
                parsed = urlsplit("https://" + ioc)
                if not parsed.port or str(ipaddress.ip_address(parsed.hostname)) != context.query:
                    raise ValueError("ThreatFox returned another IP")
            elif normalize(context.input_type, ioc) != context.query:
                raise ValueError("ThreatFox returned another indicator")
            findings.append(self.finding(context, "threatfox_reports_indicator", "record", ioc, endpoint,
                confidence="tentative", metadata={**_selected(record, ("id", "ioc_type", "threat_type", "malware", "confidence_level", "first_seen", "last_seen")),
                "timestamp_kind": "retrieved_at", "note": "Community threat claim; confidence_level is upstream, not framework confidence."}))
        return findings


def threat_modules():
    return [CertSpotterModule(), CommonCrawlModule(), OTXModule(), URLhausModule(), ThreatFoxModule()]
