"""Read-only archive and public repository discovery; search hits remain leads."""

import re
from urllib.parse import quote, urlsplit

from ..core.schema import ModuleSpec, normalize
from .native import NativeModule, _array, _object


class ArchiveURLsModule(NativeModule):
    spec = ModuleSpec(name="archive_urls", input_types=["domain", "url"],
        description="Wayback CDX historical URLs, timestamps and content types; up to 200 indexed URLs",
        rate_limit_per_min=4, terms_url="https://archive.org/about/terms.php")

    async def run(self, context, http):
        domain = context.query if context.input_type == "domain" else urlsplit(context.query).hostname
        limit = min(context.max_findings + 1, 200)
        response = await self.get(http, "https://web.archive.org/cdx/search/cdx", params={
            "url": context.query, "matchType": "domain" if context.input_type == "domain" else "exact",
            "output": "json", "fl": "timestamp,original,mimetype,statuscode", "collapse": "urlkey", "limit": limit})
        rows = _array(response)
        if not rows:
            return []
        if rows[0] != ["timestamp", "original", "mimetype", "statuscode"]:
            raise ValueError("Unexpected archive columns")
        findings = []
        for row in rows[1:limit + 1]:
            if not isinstance(row, list) or len(row) != 4 or not all(isinstance(v, str) for v in row):
                raise ValueError("Unexpected archive record")
            timestamp, raw, mimetype, status = row
            if not re.fullmatch(r"\d{14}", timestamp):
                raise ValueError("Invalid archive timestamp")
            url = normalize("url", raw)
            host = urlsplit(url).hostname
            if context.input_type == "domain" and host != domain and not host.endswith("." + domain):
                continue
            if context.input_type == "url" and url != context.query:
                continue
            findings.append(self.finding(context, "historical_url", "url", url,
                "https://web.archive.org/web/" + timestamp + "/" + quote(url, safe=":/"), confidence="tentative",
                metadata={"archive_timestamp": timestamp, "mime_type": mimetype[:100], "http_status": status[:3],
                    "historical": True, "current_existence_verified": False, "source_result_limit": limit,
                    "possibly_truncated": len(rows) - 1 >= limit,
                    "note": "Index metadata only; archived or current page content was not fetched."}))
        return findings


class GitHubRepositorySearchModule(NativeModule):
    spec = ModuleSpec(name="github_repositories", input_types=["domain", "username", "name"],
        description="Public GitHub repository mentions in names, descriptions and README files; up to 30 search leads",
        rate_limit_per_min=4, terms_url="https://docs.github.com/en/site-policy/github-terms/github-terms-of-service")

    async def run(self, context, http):
        term = context.query.replace('"', " ").replace("\\", " ").strip()
        response = _object(await self.get(http, "https://api.github.com/search/repositories", params={
            "q": '"' + term + '" in:name,description,readme is:public', "per_page": 30, "page": 1}))
        findings = []
        for row in _array(response.get("items"))[:30]:
            row = _object(row)
            if row.get("private") is not False:
                continue
            url = normalize("url", row.get("html_url", ""))
            if urlsplit(url).hostname != "github.com":
                raise ValueError("Repository URL outside GitHub")
            findings.append(self.finding(context, "repository_search_lead", "url", url, url, confidence="tentative",
                metadata={"repository": str(row.get("full_name", ""))[:200],
                    "description": str(row.get("description") or "")[:1000],
                    "updated_at": row.get("updated_at"), "archived": row.get("archived"),
                    "source_total_count": response.get("total_count"), "source_result_limit": 30,
                    "possibly_truncated": bool(response.get("incomplete_results")) or response.get("total_count", 0) > 30,
                    "ownership_verified": False, "note": "Search relevance is not proof of repository ownership or affiliation."}))
        return findings[:context.max_findings + 1]


def discovery_modules():
    return [ArchiveURLsModule(), GitHubRepositorySearchModule()]
