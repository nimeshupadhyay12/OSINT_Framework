"""Opt-in, bounded public page observations with fail-closed robots handling.

This module does not establish account or email ownership. The shared HTTP client
must pin public DNS answers, refuse redirects, enforce content limits and pacing,
and identify itself with the OSINTCorrelation User-Agent product token.
"""

import math
import re
from collections import deque
from dataclasses import dataclass
from urllib.parse import quote, unquote, urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from ..core.http import SourceSkipped
from ..core.schema import Entity, Finding, ModuleSpec, QueryContext

USER_AGENT = "OSINTCorrelation"
_PROTECTED_HOSTS = {
    "facebook.com", "instagram.com", "linkedin.com", "twitter.com", "x.com",
    "tiktok.com", "threads.net", "threads.com", "snapchat.com", "whatsapp.com",
    "discord.com", "discord.gg", "telegram.org", "t.me", "reddit.com",
}
_PRIVATE_SEGMENTS = {
    "login", "log-in", "signin", "sign-in", "logout", "signout", "auth", "oauth",
    "oauth2", "account", "accounts", "settings", "admin", "private", "messages",
    "inbox", "checkout", "cart", "password", "reset-password", "session",
}
_NONPAGE_EXTENSIONS = {
    ".zip", ".gz", ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
    ".mp3", ".mp4", ".exe", ".dll", ".docx", ".xlsx", ".pptx", ".json",
    ".xml", ".css", ".js", ".woff", ".woff2",
}
_UNRESERVED = frozenset("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")


def _robot_path(value: str) -> str:
    """Normalize Unicode and escaped unreserved octets before robots matching."""
    value = quote(value, safe="/%!*'();:@&=+$,?[]-._~")

    def escaped(match):
        char = chr(int(match.group(1), 16))
        return char if char in _UNRESERVED else "%" + match.group(1).upper()

    return re.sub(r"%([0-9a-fA-F]{2})", escaped, value)


def _path_matches(pattern: str, path: str) -> bool:
    """Wildcard prefix matching without compiling attacker-controlled regexes."""
    anchored = pattern.endswith("$")
    pattern = pattern[:-1] if anchored else pattern + "*"
    i = j = 0
    star = retry = -1
    while i < len(path):
        if j < len(pattern) and pattern[j] == "*":
            star, retry = j, i
            j += 1
        elif j < len(pattern) and pattern[j] == path[i]:
            i += 1
            j += 1
        elif star >= 0:
            retry += 1
            i, j = retry, star + 1
        else:
            return False
    return all(char == "*" for char in pattern[j:])


@dataclass(frozen=True)
class _Robots:
    rules: tuple[tuple[bool, str], ...]
    rate_limit_per_min: int = 6

    def permits(self, url: str) -> bool:
        path = _robot_path(urlsplit(url).path or "/")
        matches = [
            (len(pattern.encode("ascii")), allow)
            for allow, pattern in self.rules
            if _path_matches(pattern, path)
        ]
        # Most-specific rule wins; equal specificity favors Allow.
        return max(matches)[1] if matches else True


def _parse_robots(text: str | None) -> _Robots:
    if text is None:  # Only the HTTP client's explicit 404 path returns None.
        return _Robots(())
    if len(text.encode("utf-8")) > 512_000 or "\ufffd" in text:
        raise SourceSkipped("robots.txt cannot be safely parsed within the supported limit")
    if "<html" in text.lower() or "<!doctype" in text.lower():
        raise SourceSkipped("robots.txt returned a document rather than robots directives")

    groups: list[tuple[list[str], list[tuple[str, str]]]] = []
    agents: list[str] = []
    directives: list[tuple[str, str]] = []
    for raw in text.lstrip("\ufeff").splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        key, separator, value = line.partition(":")
        key, value = key.strip().lower(), value.strip()
        if not separator:
            if key.startswith(("user-agent", "allow", "disallow", "crawl-delay", "request-rate")):
                raise SourceSkipped("robots.txt has a malformed access directive")
            continue
        if key == "user-agent":
            if not value or not re.fullmatch(r"[A-Za-z_-]+|\*", value):
                raise SourceSkipped("robots.txt has an unsupported User-Agent group")
            if directives:
                groups.append((agents, directives))
                agents, directives = [], []
            agents.append(value.lower())
        elif key in {"allow", "disallow", "crawl-delay", "request-rate"}:
            if not agents:
                raise SourceSkipped("robots.txt access directive has no User-Agent group")
            directives.append((key, value))
    if agents:
        groups.append((agents, directives))

    selected = [rules for names, rules in groups if USER_AGENT.lower() in names]
    if not selected:
        selected = [rules for names, rules in groups if "*" in names]
    rules = []
    delay = 10.0
    for group in selected:
        for key, value in group:
            if key in {"allow", "disallow"}:
                if not value:
                    continue
                if not value.startswith("/") or len(value) > 2048:
                    raise SourceSkipped("robots.txt contains an unsupported path rule")
                rules.append((key == "allow", _robot_path(value)))
            else:
                try:
                    if key == "crawl-delay":
                        required = float(value)
                    else:
                        count, seconds = value.split("/", 1)
                        if (
                            not count.isdigit() or not seconds.isdigit()
                            or int(count) < 1 or int(seconds) < 1
                        ):
                            raise ValueError("Invalid request-rate")
                        required = int(seconds) / int(count)
                    if not math.isfinite(required) or required < 0:
                        raise ValueError("Invalid robots delay")
                    delay = max(delay, required)
                except (ValueError, ZeroDivisionError) as exc:
                    raise SourceSkipped("robots.txt timing directive is unsupported") from exc
    if delay > 60:
        raise SourceSkipped("robots.txt requires a delay beyond this bounded scraper's limit")
    return _Robots(tuple(rules), min(6, max(1, math.floor(60 / delay))))


def _page_url(raw: str, origin: tuple[str, str, int] | None = None) -> str | None:
    """Only public-style, non-sensitive HTTPS page URLs in one exact origin."""
    try:
        if len(raw) > 2048 or any(ord(char) < 32 for char in raw) or "\\" in raw:
            return None
        parsed = urlsplit(raw)
        if (
            parsed.scheme != "https" or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
        ):
            return None
        host = parsed.hostname.encode("idna").decode("ascii").lower()
        if parsed.port not in {None, 443} or parsed.query:
            return None
        if origin is not None and (parsed.scheme, host, parsed.port or 443) != origin:
            return None
        if any(host == blocked or host.endswith("." + blocked) for blocked in _PROTECTED_HOSTS):
            return None
        path = parsed.path or "/"
        decoded = path
        for _ in range(3):
            decoded = unquote(decoded)
        if any(ord(char) < 32 for char in decoded) or "\\" in decoded or ";" in decoded:
            return None
        segments = set(filter(None, decoded.lower().split("/")))
        if segments & _PRIVATE_SEGMENTS or any(decoded.lower().endswith(ext) for ext in _NONPAGE_EXTENSIONS):
            return None
        return urlunsplit(("https", host, path, "", ""))
    except (ValueError, UnicodeError):
        return None


class WebpageModule:
    spec = ModuleSpec(
        name="webpage",
        input_types=["url"],
        description="Opt-in public page metadata and links within one reviewed HTTPS origin",
        rate_limit_per_min=6,
        terms_url="https://www.rfc-editor.org/rfc/rfc9309.html",
        default_enabled=False,
    )

    async def run(self, context: QueryContext, http) -> list[Finding]:
        if context.input_type != "url":
            raise SourceSkipped("webpage requires a URL input")
        seed = _page_url(context.query)
        if seed is None:
            raise SourceSkipped("webpage requires a public HTTPS:443 URL without queries or protected paths")
        host = urlsplit(seed).hostname
        if host not in context.allowed_hosts or not context.terms_url:
            raise SourceSkipped("webpage requires its exact hostname and an operator-reviewed terms URL")
        origin = ("https", host, 443)
        robots_url = f"https://{host}/robots.txt"
        robots = _parse_robots(await http.get_text(
            robots_url, source=self.spec.name, rate_limit_per_min=6,
            not_found_ok=True, pinned=True, allowed_content_types=("text/plain",),
        ))
        if not robots.permits(seed):
            raise SourceSkipped("robots.txt disallows the seed page for OSINTCorrelation")

        pending = deque([seed])
        queued = {seed}
        findings: list[Finding] = []
        seen_findings: set[str] = set()
        visited = 0
        while pending and visited < min(context.max_pages, 20):
            if len(findings) >= context.max_findings:
                break
            url = pending.popleft()
            if not robots.permits(url):
                continue
            visited += 1
            document = await http.get_text(
                url, source=self.spec.name, rate_limit_per_min=robots.rate_limit_per_min,
                not_found_ok=True, pinned=True,
                allowed_content_types=("text/html", "application/xhtml+xml"),
            )
            if document is None:
                continue
            soup = BeautifulSoup(document, "html.parser")
            title = soup.title.get_text(" ", strip=True)[:300] if soup.title else ""
            description_tag = soup.find("meta", attrs={"name": re.compile("^description$", re.I)})
            description = str(description_tag.get("content", ""))[:1000] if description_tag else ""
            page = Entity(kind="url", value=url)
            metadata = {
                "title": title, "description": description,
                "observation": "The fetched public page publishes this content; ownership is not inferred.",
                "robots_url": robots_url, "robots_user_agent": USER_AGENT,
                "permission_reference": context.terms_url,
            }

            def add(relation: str, target: Entity):
                finding = Finding(
                    source=self.spec.name, subject=page, relation=relation, object=target,
                    confidence="certain", evidence_url=url,
                    legal_basis=f"Operator-reviewed collection reference: {context.terms_url}",
                    metadata=metadata,
                )
                if finding.id not in seen_findings and len(findings) < context.max_findings:
                    seen_findings.add(finding.id)
                    findings.append(finding)

            add("page_observed", page)
            for anchor in soup.find_all("a", href=True):
                if len(findings) >= context.max_findings:
                    break
                href = str(anchor["href"]).strip()
                if href.lower().startswith("mailto:"):
                    # Only the visibly linked single address, never message text or cc/bcc.
                    address = unquote(href[7:].split("?", 1)[0])
                    if "," not in address and ";" not in address:
                        try:
                            add("publishes_email", Entity(kind="email", value=address))
                        except ValueError:
                            pass
                    continue
                link = _page_url(urljoin(url, href), origin)
                if not link:
                    continue
                add("links_to", Entity(kind="url", value=link))
                if link not in queued and len(queued) < context.max_pages and robots.permits(link):
                    queued.add(link)
                    pending.append(link)
        return findings
