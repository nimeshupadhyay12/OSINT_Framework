"""Bounded public-source adapters. External text is evidence, never executable input.

Only observations made by a source receive ``certain`` confidence. A matching
profile or a self-reported field never establishes a real person's identity.
"""

import ipaddress
import re
from typing import Any
from urllib.parse import quote, urlencode

import phonenumbers
from phonenumbers import carrier, geocoder, timezone

from osint_framework.core.credentials import get_secret
from osint_framework.core.http import SourceSkipped
from osint_framework.core.schema import Entity, Finding, ModuleSpec, OSINTModule, QueryContext


def _object(value: Any) -> dict:
    if not isinstance(value, dict):
        raise ValueError("Source returned an unexpected response shape")
    return value


def _array(value: Any) -> list:
    if not isinstance(value, list):
        raise ValueError("Source returned an unexpected response shape")
    return value


def _text(value: Any, limit: int = 1000) -> str:
    return value[:limit] if isinstance(value, str) else ""


def _selected(data: dict, names: tuple[str, ...]) -> dict:
    """Copy only explicitly selected scalars, never a credential-bearing raw response."""
    return {
        name: (_text(data[name]) if isinstance(data[name], str) else data[name])
        for name in names
        if name in data and (data[name] is None or isinstance(data[name], (str, int, float, bool)))
    }


class NativeModule:
    spec: ModuleSpec

    async def get(self, http: Any, url: str, **kwargs: Any) -> Any:
        return await http.get_json(
            url, source=self.spec.name, rate_limit_per_min=self.spec.rate_limit_per_min, **kwargs
        )

    def finding(
        self,
        context: QueryContext,
        relation: str,
        kind: str,
        value: str,
        evidence_url: str,
        *,
        confidence: str = "certain",
        metadata: dict | None = None,
        subject: Entity | None = None,
    ) -> Finding:
        return Finding(
            source=self.spec.name,
            subject=subject or context.entity,
            relation=relation,
            object=Entity(kind=kind, value=value),
            confidence=confidence,
            evidence_url=evidence_url,
            legal_basis=f"Documented public API/metadata access: {self.spec.terms_url}",
            metadata=metadata or {},
        )


class GitHubModule(NativeModule):
    spec = ModuleSpec(
        name="github",
        input_types=["username"],
        default_enabled=True,
        description="One public GitHub profile and explicitly self-reported fields.",
        rate_limit_per_min=1,
        terms_url="https://docs.github.com/en/rest/users/users#get-a-user",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,37}[A-Za-z0-9])?", context.query):
            raise SourceSkipped("Identifier is not a supported GitHub username")
        endpoint = f"https://api.github.com/users/{quote(context.query, safe='')}"
        data = await self.get(
            http,
            endpoint,
            not_found_ok=True,
            headers={
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2026-03-10",
            },
        )
        if data is None:
            return []
        data = _object(data)
        login = _text(data.get("login"), 100)
        if login.lower() != context.query.lower():
            raise ValueError("GitHub returned a different username")
        profile = f"https://github.com/{quote(login, safe='')}"
        metadata = _selected(
            data,
            (
                "id",
                "login",
                "type",
                "name",
                "company",
                "location",
                "bio",
                "public_repos",
                "followers",
                "following",
                "created_at",
                "updated_at",
            ),
        )
        metadata["identity_note"] = "Profile fields are self-reported; ownership is unverified."
        findings = [
            self.finding(
                context, "observed_profile", "profile", profile, endpoint, metadata=metadata
            )
        ]
        for field, kind in (("email", "email"), ("name", "name"), ("blog", "url")):
            value = _text(data.get(field))
            if not value:
                continue
            try:
                findings.append(
                    self.finding(
                        context,
                        f"self_reports_{field}",
                        kind,
                        value,
                        endpoint,
                        subject=Entity(kind="profile", value=profile),
                        metadata={"identity_note": "Public profile claim, not verified ownership."},
                    )
                )
            except ValueError:
                continue  # Optional malformed profile fields do not invalidate the profile.
        return findings[: context.max_findings + 1]


class BlueskyModule(NativeModule):
    spec = ModuleSpec(
        name="bluesky",
        input_types=["username"],
        default_enabled=True,
        description="Public Bluesky profile for a handle; bare names use .bsky.social.",
        rate_limit_per_min=10,
        terms_url="https://docs.bsky.app/docs/api/app-bsky-actor-get-profile",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        actor = context.query.lstrip("@").lower()
        if "." not in actor:
            actor += ".bsky.social"
        try:
            actor = Entity(kind="domain", value=actor).value
        except ValueError as exc:
            raise SourceSkipped("Identifier is not a supported Bluesky handle") from exc
        endpoint = "https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile"
        data = await self.get(http, endpoint, params={"actor": actor}, not_found_ok=True)
        if data is None:
            return []
        data = _object(data)
        handle = _text(data.get("handle"), 253).lower()
        if not data.get("did") or handle != actor:
            raise ValueError("Bluesky returned an unexpected profile")
        profile = f"https://bsky.app/profile/{quote(handle, safe='')}"
        metadata = _selected(
            data,
            (
                "did",
                "handle",
                "displayName",
                "description",
                "followersCount",
                "followsCount",
                "postsCount",
                "createdAt",
                "indexedAt",
            ),
        )
        metadata["requested_handle"] = actor
        metadata["identity_note"] = "A handle match is not proof of real-world identity."
        return [
            self.finding(
                context,
                "observed_profile",
                "profile",
                profile,
                endpoint + "?" + urlencode({"actor": actor}),
                metadata=metadata,
            )
        ]


class DNSModule(NativeModule):
    spec = ModuleSpec(
        name="dns",
        input_types=["domain"],
        default_enabled=True,
        description="Five bounded DNS-over-HTTPS queries: A, AAAA, MX, NS, TXT.",
        rate_limit_per_min=30,
        terms_url="https://developers.google.com/speed/public-dns/docs/doh/json",
    )
    record_types = {1: "A", 28: "AAAA", 15: "MX", 2: "NS", 16: "TXT", 5: "CNAME"}

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = "https://dns.google/resolve"
        findings = []
        seen = set()
        for requested in ("A", "AAAA", "MX", "NS", "TXT"):
            params = {"name": context.query, "type": requested}
            data = _object(await self.get(http, endpoint, params=params))
            if (
                data.get("Status") == 3
            ):  # NXDOMAIN is an empty observation, not proof of anything else.
                continue
            if data.get("Status") != 0:
                raise ValueError("DNS resolver returned a failure status")
            for answer in _array(data.get("Answer", [])):
                answer = _object(answer)
                record_type = self.record_types.get(answer.get("type"))
                value = _text(answer.get("data"), 2048)
                if not record_type or not value:
                    continue
                owner = _text(answer.get("name"), 253).rstrip(".") or context.query
                metadata = {
                    "record_type": record_type,
                    "ttl": answer.get("TTL"),
                    "requested_type": requested,
                    "dnssec_validated": data.get("AD", False),
                }
                kind = "record"
                if record_type in {"A", "AAAA"}:
                    kind = "ip"
                elif record_type in {"MX", "NS", "CNAME"}:
                    kind = "domain"
                    if record_type == "MX":
                        parts = value.split(maxsplit=1)
                        if len(parts) != 2:
                            continue
                        metadata["priority"] = parts[0]
                        value = parts[1]
                    value = value.rstrip(".")
                    if not value:  # Null MX ("0 .") is an explicit record, not a hostname.
                        kind, value = "record", "null-mx"
                key = (owner, record_type, value)
                if key in seen:
                    continue
                try:
                    finding = self.finding(
                        context,
                        f"dns_{record_type.lower()}",
                        kind,
                        value,
                        endpoint + "?" + urlencode(params),
                        metadata=metadata,
                        subject=Entity(kind="domain", value=owner),
                    )
                except ValueError:
                    continue
                seen.add(key)
                findings.append(finding)
                if len(findings) > context.max_findings:
                    return findings
        return findings


class CertificateTransparencyModule(NativeModule):
    spec = ModuleSpec(
        name="crtsh",
        input_types=["domain"],
        default_enabled=True,
        description="Certificate Transparency names for one domain; no discovered host is queried.",
        rate_limit_per_min=2,
        terms_url="https://crt.sh/",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = "https://crt.sh/"
        data = _array(
            await self.get(http, endpoint, params={"q": f"%.{context.query}", "output": "json"})
        )
        findings, seen = [], set()
        for cert in data:
            cert = _object(cert)
            for name in _text(cert.get("name_value"), 50000).splitlines():
                presented_name = name.lower().strip().rstrip(".")
                wildcard = presented_name.startswith("*.")
                name = presented_name.removeprefix("*.")
                if name != context.query and not name.endswith("." + context.query):
                    continue
                if presented_name in seen:
                    continue
                cert_id = str(cert.get("id", ""))
                evidence = endpoint + (
                    "?id=" + cert_id if cert_id.isdigit() else "?" + urlencode({"q": context.query})
                )
                try:
                    # A wildcard is a pattern, not a certificate for the apex domain.
                    Entity(kind="domain", value=name)
                    finding = self.finding(
                        context,
                        "certificate_lists_domain",
                        "record" if wildcard else "domain",
                        presented_name,
                        evidence,
                        metadata={
                            **_selected(cert, ("issuer_name", "not_before", "not_after")),
                            "certificate_id": cert_id if cert_id.isdigit() else None,
                            "wildcard": wildcard,
                            "domain_scope": name,
                            "note": "A logged certificate does not prove current DNS or ownership.",
                        },
                    )
                except ValueError:
                    continue
                seen.add(presented_name)
                findings.append(finding)
                if len(findings) > context.max_findings:
                    return findings
        return findings


class RDAPModule(NativeModule):
    spec = ModuleSpec(
        name="rdap",
        input_types=["domain", "ip"],
        default_enabled=True,
        description="Public RDAP registration summary through the RDAP.org bootstrap service.",
        rate_limit_per_min=5,
        terms_url="https://about.rdap.org/",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = f"https://rdap.org/{context.input_type}/{quote(context.query, safe='')}"
        data = await self.get(http, endpoint, not_found_ok=True)
        if data is None:
            return []
        data = _object(data)
        if data.get("errorCode"):
            raise ValueError("RDAP returned a source error")
        expected = "domain" if context.input_type == "domain" else "ip network"
        if data.get("objectClassName") != expected:
            raise ValueError("RDAP returned an unexpected object class")
        if context.input_type == "domain":
            returned_name = _text(data.get("ldhName") or data.get("unicodeName"), 253)
            if (
                not returned_name
                or Entity(kind="domain", value=returned_name).value != context.query
            ):
                raise ValueError("RDAP returned a different domain")
        else:
            start = ipaddress.ip_address(_text(data.get("startAddress")))
            end = ipaddress.ip_address(_text(data.get("endAddress")))
            address = ipaddress.ip_address(context.query)
            if (
                start.version != address.version
                or end.version != address.version
                or not start <= address <= end
            ):
                raise ValueError("RDAP returned a different IP allocation")
        metadata = _selected(
            data,
            (
                "handle",
                "ldhName",
                "unicodeName",
                "name",
                "type",
                "country",
                "startAddress",
                "endAddress",
                "ipVersion",
                "port43",
            ),
        )
        metadata["status"] = [_text(s, 200) for s in _array(data.get("status", []))[:30]]
        metadata["events"] = [
            _selected(_object(event), ("eventAction", "eventDate"))
            for event in _array(data.get("events", []))[:30]
        ]
        metadata["nameservers"] = [
            _text(_object(ns).get("ldhName"), 253)
            for ns in _array(data.get("nameservers", []))[:30]
        ]
        metadata["note"] = "Registration metadata may be redacted or describe a network allocation."
        return [
            self.finding(
                context,
                "has_registration_record",
                "record",
                f"rdap:{context.input_type}:{context.query}",
                endpoint,
                metadata=metadata,
            )
        ]


class PhoneLocalModule(NativeModule):
    spec = ModuleSpec(
        name="phone_local",
        input_types=["phone"],
        default_enabled=True,
        description="Offline numbering-plan validation; no subscriber identity or live location.",
        rate_limit_per_min=60,
        terms_url="https://github.com/daviddrysdale/python-phonenumbers",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        try:
            number = phonenumbers.parse(context.query, None)
        except phonenumbers.NumberParseException as exc:
            raise SourceSkipped(
                "Phone number cannot be parsed by the local numbering-plan library"
            ) from exc
        metadata = {
            "possible": phonenumbers.is_possible_number(number),
            "valid_numbering_plan": phonenumbers.is_valid_number(number),
            "country_calling_code": number.country_code,
            "region_code": phonenumbers.region_code_for_number(number),
            "international_format": phonenumbers.format_number(
                number, phonenumbers.PhoneNumberFormat.INTERNATIONAL
            ),
            "number_type": phonenumbers.PhoneNumberType.to_string(phonenumbers.number_type(number)),
            "prefix_description": geocoder.description_for_number(number, "en"),
            "original_carrier_prefix": carrier.name_for_number(number, "en"),
            "possible_time_zones": list(timezone.time_zones_for_number(number)),
            "library_version": phonenumbers.__version__,
            "note": "Offline prefix metadata cannot establish assignment, current carrier, owner, or live location.",
        }
        finding = self.finding(
            context,
            "has_numbering_plan_metadata",
            "record",
            f"numbering-plan:{context.query}",
            self.spec.terms_url,
            metadata=metadata,
        )
        finding.legal_basis = f"Local Apache-2.0 numbering-plan library: {self.spec.terms_url}"
        return [finding]


class TwilioModule(NativeModule):
    spec = ModuleSpec(
        name="twilio",
        input_types=["phone"],
        key_env=["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"],
        description="Twilio Lookup v2 basic phone validation; paid enrichment fields are not requested.",
        rate_limit_per_min=10,
        terms_url="https://www.twilio.com/docs/lookup/v2-api",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = f"https://lookups.twilio.com/v2/PhoneNumbers/{quote(context.query, safe='')}"
        data = _object(
            await self.get(
                http,
                endpoint,
                auth=(get_secret("TWILIO_ACCOUNT_SID"), get_secret("TWILIO_AUTH_TOKEN")),
            )
        )
        if not isinstance(data.get("valid"), bool):
            raise ValueError("Twilio returned an unexpected validation response")
        if data.get("phone_number") and data["phone_number"] != context.query:
            raise ValueError("Twilio returned a different phone number")
        metadata = _selected(
            data,
            ("phone_number", "national_format", "calling_country_code", "country_code", "valid"),
        )
        metadata["note"] = (
            "Basic validation does not identify the subscriber or establish live reachability."
        )
        return [
            self.finding(
                context,
                "has_phone_validation",
                "record",
                f"twilio:{context.query}",
                endpoint,
                metadata=metadata,
            )
        ]


class HIBPModule(NativeModule):
    spec = ModuleSpec(
        name="hibp",
        input_types=["email"],
        key_env=["HIBP_API_KEY"],
        description="Have I Been Pwned breach-name observations; no passwords or breach dumps.",
        rate_limit_per_min=6,
        terms_url="https://haveibeenpwned.com/API/v3",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = (
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{quote(context.query, safe='')}"
        )
        data = await self.get(
            http,
            endpoint,
            params={"truncateResponse": "true", "includeUnverified": "false"},
            headers={
                "hibp-api-key": get_secret("HIBP_API_KEY"),
                "User-Agent": "OSINT-Correlation-Framework/0.1",
            },
            not_found_ok=True,
        )
        if data is None:
            return []
        findings, seen = [], set()
        for breach in _array(data):
            name = _text(_object(breach).get("Name"), 500)
            if not name or name in seen:
                continue
            seen.add(name)
            findings.append(
                self.finding(
                    context,
                    "reported_in_breach",
                    "breach",
                    name,
                    endpoint,
                    metadata={
                        "attribution": "Breach data supplied by Have I Been Pwned (https://haveibeenpwned.com).",
                        "breach_details_url": "https://haveibeenpwned.com/api/v3/breach/"
                        + quote(name, safe=""),
                        "note": "Historical breach association does not establish a current compromise or identity.",
                    },
                )
            )
            if len(findings) > context.max_findings:
                break
        return findings


class HunterModule(NativeModule):
    spec = ModuleSpec(
        name="hunter",
        input_types=["email"],
        key_env=["HUNTER_API_KEY"],
        description="Hunter email verification status through its documented API.",
        rate_limit_per_min=5,
        terms_url="https://hunter.io/api-documentation/v2#email-verifier",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = "https://api.hunter.io/v2/email-verifier"
        payload = _object(
            await self.get(
                http,
                endpoint,
                params={"email": context.query, "api_key": get_secret("HUNTER_API_KEY")},
            )
        )
        data = _object(payload.get("data"))
        if not isinstance(data.get("status"), str):
            raise ValueError("Hunter returned an unexpected verification response")
        metadata = _selected(
            data,
            (
                "status",
                "result",
                "score",
                "regexp",
                "gibberish",
                "disposable",
                "webmail",
                "mx_records",
                "smtp_server",
                "smtp_check",
                "accept_all",
                "block",
                "email",
            ),
        )
        metadata["note"] = (
            "Provider verification is an observation, not proof of ownership or guaranteed delivery."
        )
        return [
            self.finding(
                context,
                "has_email_verification",
                "record",
                f"hunter:{context.query}",
                endpoint + "?" + urlencode({"email": context.query}),
                metadata=metadata,
            )
        ]


class VirusTotalModule(NativeModule):
    spec = ModuleSpec(
        name="virustotal",
        input_types=["domain", "ip"],
        key_env=["VIRUSTOTAL_API_KEY"],
        description="Existing VirusTotal domain/IP report; never submits a scan.",
        rate_limit_per_min=4,
        terms_url="https://docs.virustotal.com/reference/overview",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        path = "domains" if context.input_type == "domain" else "ip_addresses"
        endpoint = f"https://www.virustotal.com/api/v3/{path}/{quote(context.query, safe='')}"
        payload = await self.get(
            http,
            endpoint,
            headers={"x-apikey": get_secret("VIRUSTOTAL_API_KEY")},
            not_found_ok=True,
        )
        if payload is None:
            return []
        data = _object(_object(payload).get("data"))
        if (
            data.get("id")
            and Entity(kind=context.input_type, value=data["id"]).value != context.query
        ):
            raise ValueError("VirusTotal returned a different identifier")
        attributes = _object(data.get("attributes"))
        metadata = _selected(
            attributes,
            (
                "reputation",
                "last_analysis_date",
                "last_modification_date",
                "country",
                "as_owner",
                "asn",
                "registrar",
            ),
        )
        stats = _object(attributes.get("last_analysis_stats", {}))
        metadata["last_analysis_stats"] = _selected(
            stats,
            (
                "malicious",
                "suspicious",
                "undetected",
                "harmless",
                "timeout",
            ),
        )
        metadata["note"] = (
            "Vendor verdict counts are source assessments and may be stale or disagree."
        )
        return [
            self.finding(
                context,
                "has_reputation_report",
                "record",
                f"virustotal:{context.query}",
                endpoint,
                metadata=metadata,
            )
        ]


class ShodanModule(NativeModule):
    spec = ModuleSpec(
        name="shodan",
        input_types=["ip"],
        key_env=["SHODAN_API_KEY"],
        description="Existing Shodan host summary with minify=true; no active scan or banners.",
        rate_limit_per_min=5,
        terms_url="https://developer.shodan.io/api",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        endpoint = f"https://api.shodan.io/shodan/host/{quote(context.query, safe='')}"
        data = await self.get(
            http,
            endpoint,
            params={"key": get_secret("SHODAN_API_KEY"), "minify": "true", "history": "false"},
            not_found_ok=True,
        )
        if data is None:
            return []
        data = _object(data)
        if data.get("error"):
            raise ValueError("Shodan returned a source error")
        if Entity(kind="ip", value=_text(data.get("ip_str"))).value != context.query:
            raise ValueError("Shodan returned a different IP address")
        metadata = _selected(data, ("ip_str", "org", "isp", "asn", "country_code", "last_update"))
        metadata["ports"] = [
            p for p in _array(data.get("ports", []))[:500] if type(p) is int and 0 < p < 65536
        ]
        metadata["hostnames"] = [
            _text(h, 253) for h in _array(data.get("hostnames", []))[:100] if isinstance(h, str)
        ]
        metadata["note"] = (
            "Previously indexed services may no longer be exposed. No scan was requested."
        )
        return [
            self.finding(
                context,
                "has_indexed_host_report",
                "record",
                f"shodan:{context.query}",
                f"https://www.shodan.io/host/{quote(context.query, safe='')}",
                metadata=metadata,
            )
        ]


class BraveSearchModule(NativeModule):
    spec = ModuleSpec(
        name="brave",
        input_types=["name", "username", "domain", "email"],
        key_env=["BRAVE_SEARCH_API_KEY"],
        description="At most twenty indexed web results; results are unverified leads, not identity matches.",
        rate_limit_per_min=5,
        terms_url="https://api-dashboard.search.brave.com/documentation/services/web-search",
    )

    async def run(self, context: QueryContext, http: Any) -> list[Finding]:
        if len(context.query) > 600 or len(context.query.split()) > 75:
            raise SourceSkipped("Query exceeds Brave Search's 600-character or 75-word limit")
        endpoint = "https://api.search.brave.com/res/v1/web/search"
        data = _object(
            await self.get(
                http,
                endpoint,
                params={
                    "q": context.query,
                    "count": min(context.max_findings + 1, 20),
                    "text_decorations": "false",
                    "spellcheck": "false",
                    "result_filter": "web",
                },
                headers={
                    "X-Subscription-Token": get_secret("BRAVE_SEARCH_API_KEY"),
                    "Accept": "application/json",
                },
            )
        )
        web = _object(data.get("web", {}))
        findings, seen = [], set()
        for result in _array(web.get("results", []))[:20]:
            result = _object(result)
            url = _text(result.get("url"), 2048)
            if not url or url in seen:
                continue
            try:
                finding = self.finding(
                    context,
                    "appeared_in_search",
                    "url",
                    url,
                    url,
                    confidence="tentative",
                    metadata={
                        "title": _text(result.get("title"), 500),
                        "description": _text(result.get("description"), 1000),
                        "query": context.query,
                        "note": "Search indexing may be stale, ambiguous, or refer to a different person.",
                    },
                )
            except ValueError:
                continue
            seen.add(url)
            findings.append(finding)
            if len(findings) > context.max_findings:
                break
        return findings


def builtin_modules() -> list[OSINTModule]:
    return [
        GitHubModule(),
        BlueskyModule(),
        DNSModule(),
        CertificateTransparencyModule(),
        RDAPModule(),
        PhoneLocalModule(),
        TwilioModule(),
        HIBPModule(),
        HunterModule(),
        VirusTotalModule(),
        ShodanModule(),
        BraveSearchModule(),
    ]
