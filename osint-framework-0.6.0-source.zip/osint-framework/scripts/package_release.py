"""Package only project sources and the synthetic demo; never audit or live evidence."""

import argparse
import hashlib
import tomllib
import zipfile
from importlib.metadata import distributions
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist"
DIRECTORIES = ("src", "tests", "docs", "examples", "scripts", ".github", "deploy")
FILES = ("pyproject.toml", "README.md", "LICENSE", "LEGAL.md", "ETHICS.md", "SECURITY.md",
         "CONTRIBUTING.md", "CHANGELOG.md", ".env.example", ".gitignore", "osint.ps1",
         "Launch OSINT.cmd", "Setup OSINT.cmd", "requirements-dev.lock", "Dockerfile", ".dockerignore")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot-only", action="store_true",
                        help="Refresh the validated dependency snapshot before building packages")
    args = parser.parse_args()
    dependencies = sorted(
        f"{dist.metadata['Name']}=={dist.version}" for dist in distributions()
        if dist.metadata["Name"].lower() != "osint-correlation-framework"
    )
    (ROOT / "requirements-dev.lock").write_text(
        "# Exact dependency snapshot of the validated development environment.\n"
        "# Install this file, then install the framework with --no-deps.\n"
        + "\n".join(dependencies) + "\n", encoding="utf-8",
    )
    if args.snapshot_only:
        print("Updated requirements-dev.lock")
        return
    OUTPUT.mkdir(exist_ok=True)
    version = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["project"]["version"]
    archive = OUTPUT / f"osint-framework-{version}-source.zip"
    selected = [ROOT / name for name in FILES]
    for directory in DIRECTORIES:
        selected.extend(path for path in (ROOT / directory).rglob("*")
                        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc")
    demo = ROOT / "demo-report" / "synthetic-demo"
    selected.extend(demo / f"report.{extension}" for extension in ("html", "json", "graphml"))
    workbench_demo = ROOT / "demo-report" / "workbench-demo"
    selected.extend(workbench_demo / f"report.{extension}" for extension in ("html", "json", "graphml"))
    selected.extend(ROOT / "demo-report" / name for name in ("workbench.png", "investigate.png", "jobs.png"))
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as zipped:
        for path in sorted(selected):
            if path.is_file():
                zipped.write(path, Path("osint-framework") / path.relative_to(ROOT))
    artifacts = [archive, OUTPUT / f"osint_correlation_framework-{version}-py3-none-any.whl",
                 OUTPUT / f"osint_correlation_framework-{version}.tar.gz"]
    if not all(path.is_file() for path in artifacts):
        raise SystemExit("Build the wheel and source distribution with python -m build first")
    sbom = OUTPUT / ("sbom-v" + ".".join(version.split(".")[:2]) + ".cdx.json")
    if sbom.is_file():
        artifacts.append(sbom)
    (OUTPUT / "SHA256SUMS.txt").write_text("".join(
        f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n" for path in artifacts
    ), encoding="ascii")
    print(f"Source archive: {archive}")
    print(f"Packaged {len(selected)} source/demo files; audit and live evidence excluded")
    print(f"Checksums: {OUTPUT / 'SHA256SUMS.txt'} (version {version} only)")


if __name__ == "__main__":
    main()
