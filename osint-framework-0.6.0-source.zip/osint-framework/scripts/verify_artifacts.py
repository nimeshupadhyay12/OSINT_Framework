"""Check release checksums, packaged source consistency and excluded private files."""

import argparse
import hashlib
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--installed-root", type=Path)
    args = parser.parse_args()
    version = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]["version"]
    dist = ROOT / "dist"
    for line in (dist / "SHA256SUMS.txt").read_text().splitlines():
        digest, name = line.split("  ", 1)
        assert Path(name).name == name
        assert hashlib.sha256((dist / name).read_bytes()).hexdigest() == digest, name
    sources = {str(path.relative_to(ROOT / "src")).replace("\\", "/"): path
               for path in (ROOT / "src" / "osint_framework").rglob("*.py")}
    with zipfile.ZipFile(dist / f"osint_correlation_framework-{version}-py3-none-any.whl") as wheel:
        assert wheel.testzip() is None
        assert {name for name in wheel.namelist() if name.endswith(".py")} == sources.keys()
        for name, path in sources.items():
            assert wheel.read(name) == path.read_bytes(), name
            if args.installed_root:
                installed = args.installed_root / Path(name).relative_to("osint_framework")
                assert installed.read_bytes() == path.read_bytes(), str(installed)
    with zipfile.ZipFile(dist / f"osint-framework-{version}-source.zip") as archive:
        assert archive.testzip() is None
        for name in archive.namelist():
            path = Path(name)
            assert path.parts[0] == "osint-framework" and ".." not in path.parts
            assert not {".venv", ".release-check", ".osint-state", "reports", "validation-reports", "__pycache__"}.intersection(path.parts)
            assert path.suffix not in {".key", ".pem", ".sqlite3", ".enc"} and path.name != ".env"
        for name, path in sources.items():
            assert archive.read("osint-framework/src/" + name) == path.read_bytes()
    print(f"Version {version}: checksums, ZIP integrity, exclusions and {len(sources)} source files verified"
          + (" against the clean installation" if args.installed_root else ""))


if __name__ == "__main__":
    main()
