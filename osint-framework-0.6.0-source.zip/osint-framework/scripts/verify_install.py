"""Offline smoke checks for an installed release, including the optional desktop."""

import argparse
import json
import os
import socket
import subprocess
import sys
import time
from importlib.metadata import distribution
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True, help="New directory for synthetic outputs")
    parser.add_argument("--desktop", action="store_true")
    parser.add_argument("--integrations", action="store_true")
    parser.add_argument("--operations", action="store_true", help="Check encryption, queue and a temporary loopback API")
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=False)

    import osint_framework

    installed = distribution("osint-correlation-framework")
    assert installed.version == osint_framework.__version__
    assert "site-packages" in Path(osint_framework.__file__).parts, "Install the wheel, without -e"
    assert {"osint", "osint-desktop"}.issubset({entry.name for entry in installed.entry_points})

    def cli(*arguments, extra_env=None):
        completed = subprocess.run(
            [sys.executable, "-m", "osint_framework", *map(str, arguments)],
            cwd=output, capture_output=True, text=True, timeout=30,
            env={**os.environ, "PYTHONUTF8": "1", **(extra_env or {})}, encoding="utf-8",
        )
        assert completed.returncode == 0, completed.stdout + completed.stderr
        return completed.stdout

    assert "phone_pages" in cli("sources")
    assert "archive_urls" in cli("research-plan", "example.org")
    assert "max-pivots" in cli("research", "--help")
    cli("demo", "--out", output / "demo")
    cli("init", "--accept-policy", "--state", output / "state")
    result = cli("phone", "+1 (202) 555-0123", "--purpose", "Synthetic release smoke check",
                 "--authorized", "--state", output / "state", "--out", output / "phone")
    assert "Normalized phone: +12025550123" in result
    report_path, = (output / "phone").glob("*/report.json")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    assert [item["module"] for item in report["results"]] == ["phone_local"]
    assert report["results"][0]["status"] == "ok"
    assert "No internet lookup" in report["notes"][0]
    cli("audit-verify", "--state", output / "state")
    cli("export-schema", "--out", output / "finding.schema.json")
    case_id = cli("cases", "create", "Release smoke case", "--state", output / "state").strip()
    cli("cases", "note", case_id, "Synthetic installation check", "--state", output / "state")
    assert case_id in cli("cases", "list", "--state", output / "state")
    assert "scrapy_pages" in cli("doctor", "--json", "--state", output / "state")

    if args.operations:
        from osint_framework.catalog import modules
        from osint_framework.core.vault import Vault
        from osint_framework.integrations.imports import SUPPORTED_IMPORTS
        assert len(modules()) == 32 and len(SUPPORTED_IMPORTS) == 16
        signing_env = {"OSINT_SIGNING_PASSPHRASE": "synthetic release signing phrase"}
        key = output / "synthetic-signing.key"
        cli("evidence", "keygen", key, extra_env=signing_env)
        cli("evidence", "bundle", report_path, output / "bundle.zip", "--key", key,
            "--evidence-root", output, "--state", output / "state", extra_env=signing_env)
        assert json.loads(cli("evidence", "verify", output / "bundle.zip", "--public-key", key.with_suffix(".pub")))["verified"]
        cli("export-misp", report_path, output / "misp.json", "--state", output / "state")
        assert json.loads((output / "misp.json").read_text())["Event"]["distribution"] == "0"
        assert json.loads(cli("retention-plan", "--state", output / "state"))["candidates"] == []
        protected_state = output / "protected-state"
        password = "synthetic release vault password"
        vault_env = {"OSINT_VAULT_PASSPHRASE": password}
        # Windows getpass reads the console rather than redirected stdin.
        # Create this synthetic vault through the installed library, then verify
        # unlocked state access across actual CLI processes.
        Vault.initialize(protected_state, password)
        cli("init", "--accept-policy", "--state", protected_state, extra_env=vault_env)
        protected_case = cli("cases", "create", "Encrypted release case", "--state", protected_state, extra_env=vault_env).strip()
        cli("jobs", "enqueue", protected_case, "+12025550123", "--type", "phone", "--sources", "phone_local",
            "--purpose", "Synthetic encrypted queue check", "--authorized", "--state", protected_state, extra_env=vault_env)
        cli("jobs", "worker", "--once", "--state", protected_state, "--out", output / "protected-reports", extra_env=vault_env)
        queued = json.loads(cli("jobs", "list", "--state", protected_state, extra_env=vault_env))
        assert queued[0]["status"] == "succeeded"
        assert '"unique_evidence"' in cli("analyze-case", protected_case, "--state", protected_state, extra_env=vault_env)
        assert list((output / "protected-reports").rglob("*.enc"))
        assert not list((output / "protected-reports").rglob("report.json"))
        for database in protected_state.glob("*.sqlite3"):
            assert b"+12025550123" not in database.read_bytes()

        token = cli("team", "user-add", "release-analyst", "--role", "analyst", "--state", output / "state").strip().splitlines()[-1]
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        server = subprocess.Popen([sys.executable, "-m", "osint_framework", "team", "serve", "--state", str(output / "state"),
            "--port", str(port), "--sources", "phone_local"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0)
        try:
            import httpx
            with httpx.Client(base_url=f"http://127.0.0.1:{port}", trust_env=False, timeout=2) as client:
                deadline = time.monotonic() + 20
                while True:
                    try:
                        assert client.get("/health").status_code == 200
                        break
                    except httpx.TransportError:
                        assert server.poll() is None and time.monotonic() < deadline, "Loopback API did not start"
                        time.sleep(0.1)
                assert client.get("/cases").status_code == 401
                headers = {"Authorization": "Bearer " + token}
                created = client.post("/cases", headers=headers, json={"title": "Loopback release case"})
                assert created.status_code == 201
                api_case = created.json()["id"]
                payload = {"context": {"input_type": "phone", "query": "+12025550123",
                    "purpose": "Synthetic loopback API check", "authorized": True}, "sources": ["phone_local"]}
                submitted = client.post(f"/cases/{api_case}/jobs", headers=headers, json=payload)
                assert submitted.status_code == 202
                cli("jobs", "worker", "--once", "--state", output / "state", "--out", output / "api-reports")
                result = client.get("/jobs/" + submitted.json()["id"], headers=headers)
                assert result.status_code == 200 and result.json()["status"] == "succeeded"
                assert client.get(f"/cases/{api_case}/analysis", headers=headers).json()["unique_evidence"] > 0
                assert client.get(f"/cases/{api_case}/search", headers=headers, params={"text": "+12025550123"}).json()["matches"]
                cli("team", "user-revoke", "release-analyst", "--state", output / "state")
                assert client.get("/cases", headers=headers).status_code == 401
        finally:
            server.terminate()
            try:
                server.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                server.kill()
                server.communicate(timeout=5)

    if args.integrations:
        from osint_framework.core.audit import AuditLog
        from osint_framework.core.cases import CaseStore
        from osint_framework.core.schema import RunReport
        from osint_framework.integrations.stix_exchange import export_stix

        store = CaseStore(output / "state")
        store.add(case_id, RunReport.model_validate(report))
        assert export_stix(store.combined(case_id))["type"] == "bundle"
        cli("cases", "verify", case_id, "--state", output / "state")
        import scrapy
        assert scrapy.Selector(text="<title>Fixture</title>").css("title::text").get() == "Fixture"
        file = output / "document.txt"
        file.write_text("example.org · hello@example.org", encoding="utf-8")
        cli("document", file, "example.org", "--type", "domain", "--purpose", "Synthetic document check",
            "--authorized", "--state", output / "state", "--out", output / "documents", "--case", case_id)
        assert len(store.reports(case_id)) == 2
        assert AuditLog(output / "state").verify()[0]
        document_report, = (output / "documents").glob("*/report.json")
        cli("evidence", "warc", document_report, output / "document.warc.gz",
            "--state", output / "state", "--evidence-root", output / "documents")
        assert (output / "document.warc.gz").stat().st_size > 0

    if args.desktop:
        os.environ["QT_QPA_PLATFORM"] = "offscreen"
        from PySide6.QtGui import QFont, QFontDatabase
        from PySide6.QtWidgets import QApplication

        from osint_framework.workbench import WorkbenchWindow, synthetic_case

        app = QApplication.instance() or QApplication([])
        # Qt's offscreen Windows platform can omit installed system fonts.
        # Register the existing fonts for this headless check; do not bundle them.
        if sys.platform == "win32":
            font_dir = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
            for filename in ("segoeui.ttf", "segoeuib.ttf", "seguisb.ttf", "seguisym.ttf"):
                font = font_dir / filename
                if font.is_file():
                    assert QFontDatabase.addApplicationFont(str(font)) >= 0
        app.setApplicationName("OSINT Investigation Workbench")
        app.setFont(QFont("Segoe UI", 10))
        window = WorkbenchWindow(output / "desktop-state", output / "desktop-reports")
        window.query_input.setText("example.org")
        window.purpose_input.setText("Synthetic example only")
        window._completed(synthetic_case(output / "desktop-state", output / "desktop-reports"))
        window.show()
        app.processEvents()
        assert window.evidence_table.rowCount() >= 5
        assert window.graph.scene().items()
        assert window.grab().save(str(output / "desktop.png"))
        window.tabs.setCurrentIndex(0)
        window.mode_combo.setCurrentIndex(window.mode_combo.findData("research"))
        app.processEvents()
        assert window.grab().save(str(output / "investigate.png"))
        window.tabs.setCurrentIndex(3)
        app.processEvents()
        assert window.grab().save(str(output / "jobs.png"))
        window.close()
        app.processEvents()
    print(f"Installed version {installed.version}: CLI, local phone, reports and audit passed"
          + ("; desktop rendered successfully" if args.desktop else "")
          + ("; Scrapy, STIX and local document checks passed" if args.integrations else ""))
    if args.operations:
        print("Encrypted queue, signed bundle, MISP export, retention and authenticated loopback API/search passed; temporary server stopped")


if __name__ == "__main__":
    main()
