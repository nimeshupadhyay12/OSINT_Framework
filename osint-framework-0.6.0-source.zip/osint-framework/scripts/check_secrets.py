"""Small offline credential-pattern check; not a substitute for a dedicated scanner."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED = {".venv", ".release-check", ".git", "__pycache__", ".pytest_cache", ".ruff_cache", "dist", "reports", "demo-report", ".osint-state", ".validation-state", "validation-reports"}
PATTERNS = [
    re.compile(r"gh[pousr]_[A-Za-z0-9]{30,}"),
    re.compile(r"AKIA[A-Z0-9]{16}"),
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"(?:api[_-]?key|auth[_-]?token|password)\s*=\s*['\"][A-Za-z0-9_+/=-]{24,}['\"]", re.I),
]
failures = []
for path in ROOT.rglob("*"):
    if not path.is_file() or any(part in EXCLUDED for part in path.relative_to(ROOT).parts):
        continue
    if path.stat().st_size > 1_000_000:
        continue
    try:
        content = path.read_text(encoding="utf-8")
    except (UnicodeError, OSError):
        continue
    if any(pattern.search(content) for pattern in PATTERNS):
        failures.append(str(path.relative_to(ROOT)))
if failures:
    raise SystemExit("Potential credentials in: " + ", ".join(failures))
print("Credential-pattern check passed")
