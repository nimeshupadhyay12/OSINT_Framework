"""Render an offline synthetic workbench preview with existing system fonts."""

import os
from pathlib import Path

os.environ["QT_QPA_PLATFORM"] = "offscreen"

from PySide6.QtGui import QFont, QFontDatabase  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from osint_framework.report import write_report  # noqa: E402
from osint_framework.workbench import WorkbenchWindow, synthetic_case  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main():
    app = QApplication.instance() or QApplication([])
    if os.name == "nt":
        for name in ("segoeui.ttf", "segoeuib.ttf", "seguisb.ttf", "seguisym.ttf"):
            path = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / name
            if path.is_file():
                QFontDatabase.addApplicationFont(str(path))
    app.setFont(QFont("Segoe UI", 10))
    state, out = ROOT / ".release-check" / "workbench-demo-state", ROOT / "demo-report" / "workbench-demo"
    window = WorkbenchWindow(state, out)
    outcome = synthetic_case(state, out)
    window._completed(outcome)
    window.query_input.setText("example.org")
    window.type_combo.setCurrentText("domain")
    window.purpose_input.setText("Synthetic example investigation")
    window.show()
    app.processEvents()
    window.evidence_table.setCurrentCell(0, 0)
    assert window.grab().save(str(ROOT / "demo-report" / "workbench.png"))
    window.tabs.setCurrentIndex(0)
    app.processEvents()
    assert window.grab().save(str(ROOT / "demo-report" / "investigate.png"))
    window.tabs.setCurrentIndex(3)
    app.processEvents()
    assert window.grab().save(str(ROOT / "demo-report" / "jobs.png"))
    combined = window.store.combined(outcome.case_id)
    write_report(combined, out)
    window.close()
    print("Rendered synthetic workbench and combined report under demo-report")


if __name__ == "__main__":
    main()
