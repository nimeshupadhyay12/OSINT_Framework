"""Opt-in live acceptance checks against public infrastructure and organization examples."""

import argparse
import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path

from osint_framework.core.audit import AuditLog
from osint_framework.workflow import investigate, make_context


async def check(output):
    state = output / "state"
    AuditLog(state).accept_policy()
    rows = []
    for kind, query, names in [
        ("ip", "1.1.1.1", ["internetdb", "ripe"]),
        ("name", "Wikimedia Foundation", ["wikidata", "wikipedia"]),
        ("domain", "example.org", ["wayback"]),
        ("email", "hello@example.org", ["email_dns"]),
    ]:
        context = make_context(query, kind, "Public infrastructure and organization API acceptance test", True, max_requests=10)
        try:
            outcome = await asyncio.wait_for(investigate(context, names, state, output / "reports"), timeout=65)
            rows.extend({"source": r.module, "status": r.status, "findings": len(r.findings),
                         "message": r.message, "elapsed_ms": r.elapsed_ms} for r in outcome.report.results)
        except TimeoutError:
            rows.extend({"source": name, "status": "acceptance_timeout"} for name in names)
    result = {"checked_at": datetime.now(timezone.utc).isoformat(), "results": rows,
              "not_live_tested": ["hackernews (fixture only)", "urlscan (requires operator key)"],
              "note": "Point-in-time acceptance only. Provider availability and returned fields may change."}
    (output / "summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true", required=True, help="Authorize these bounded public example lookups")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    asyncio.run(check(args.out))
