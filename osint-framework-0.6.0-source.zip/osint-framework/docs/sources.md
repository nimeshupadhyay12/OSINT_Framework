# Native source inventory and API references

Version 0.4 adds eight reviewed sources, seven without keys and urlscan with a free-account key. See the [current free-source matrix, primary references and live acceptance results](free-and-team-v04.md#new-source-coverage). The following inventory retains the original adapter references.

Reviewed against primary sources on **2026-09-12**. This document distinguishes implemented behavior from provider capabilities. The native adapter suite uses offline fixtures; installing this project does not establish that an API key has a suitable subscription or that a provider is currently reachable.

## Implemented sources

The rate column is this framework's cap in HTTP requests per minute, not the provider's allowance. Limits are enforced by the shared HTTP client. Other applications sharing an IP address or API key also consume provider quotas. Required environment variables are checked before any source request. Keyed sources must be selected explicitly and are disabled by default.

| Module | Inputs | Default | Framework cap | Credentials | Implemented collection and primary reference |
| --- | --- | --- | ---: | --- | --- |
| `github` | username | Enabled | 1 | None | One unauthenticated [`GET /users/{username}`](https://docs.github.com/en/rest/users/users#get-a-user), using API version `2026-03-10`. Public profile metadata and explicitly self-reported email, name, and website fields when present. No followers, repositories, or account-private endpoints are crawled. |
| `bluesky` | username | Enabled | 10 | None | One [`app.bsky.actor.getProfile`](https://docs.bsky.app/docs/api/app-bsky-actor-get-profile) request to the public AppView. A bare username is tried as `username.bsky.social`; an explicit handle is used as supplied. The requested handle is recorded. |
| `dns` | domain | Enabled | 30 | None | Five [Google Public DNS JSON DoH](https://developers.google.com/speed/public-dns/docs/doh/json) lookups: A, AAAA, MX, NS, TXT. CNAME answers are retained when included by the resolver. Each returned record is attributed to its actual DNS owner name. |
| `crtsh` | domain | Enabled | 2 | None | One `crt.sh` JSON query for `%.domain`. Names are constrained to that domain, normalized, and deduplicated. The primary service is [crt.sh](https://crt.sh/); its maintainer publishes [certwatch database code](https://github.com/crtsh/certwatch_db). This JSON interface is treated as best-effort compatibility, not a versioned API with a verified service-level guarantee. |
| `rdap` | domain, IP | Enabled | 5 | None | One lookup through the [RDAP.org bootstrap service](https://about.rdap.org/), plus at most three redirects. Registration status, events, nameservers, and domain/network summary fields are retained. Contact vCards are omitted. |
| `phone_local` | phone | Enabled | No HTTP | None | Offline validation and numbering-plan metadata from [python-phonenumbers](https://github.com/daviddrysdale/python-phonenumbers), a Python port of libphonenumber. Library version is recorded. |
| `twilio` | phone | Disabled | 10 | `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN` | One [Lookup v2](https://www.twilio.com/docs/lookup/v2-api) basic validation request, authenticated with HTTP Basic. No `Fields` enrichment packages, caller name, or subscriber lookup is requested. |
| `hibp` | email | Disabled | 6 | `HIBP_API_KEY` | One [Have I Been Pwned breached-account](https://haveibeenpwned.com/API/v3) query with `truncateResponse=true` and `includeUnverified=false`. Only breach names and HIBP attribution enter the report. |
| `hunter` | email | Disabled | 5 | `HUNTER_API_KEY` | One [Hunter Email Verifier](https://hunter.io/api-documentation/v2#email-verifier) request. Stores selected validation flags and status; does not discover contacts or call password-reset/signup endpoints. |
| `virustotal` | domain, IP | Disabled | 4 | `VIRUSTOTAL_API_KEY` | Reads existing [domain](https://docs.virustotal.com/reference/domain-info) or [IP address](https://docs.virustotal.com/reference/ip-info) reports. Stores summary verdict counts and limited context. Does not submit files, URLs, or scans. |
| `shodan` | IP | Disabled | 5 | `SHODAN_API_KEY` | Reads an existing [Shodan host report](https://developer.shodan.io/api) with `minify=true` and `history=false`. Stores ports and a small host summary; no banners or active scan requests. |
| `brave` | name, username, domain, email | Disabled | 5 | `BRAVE_SEARCH_API_KEY` | One [Brave Web Search](https://api-dashboard.search.brave.com/api-reference/web/search/get) request, with spelling changes disabled. Returns at most 20 web results from one page; linked pages are not fetched by this module. |

## Provider limits and access conditions

Version 0.3 adds `scrapy_pages` for URL/domain queries. It uses real Scrapy HTML selectors and a bounded same-origin crawl through the existing `webpage` HTTP/robots/pacing implementation (six requests per minute or stricter robots directives). It requires the `crawler` extra, exact allowed hosts, and a reviewed permission URL. Defaults are three pages and 50 shared HTTP requests per run, capped at 20 and 200 respectively. `--preserve-pages` retains retrieved HTML as inert evidence bytes with a hash. [Scrapy selector documentation](https://docs.scrapy.org/en/latest/topics/selectors.html).

The desktop now accepts all listed credential names as session values, with explicit optional OS keychain save/load. `osint doctor` and the Sources and credentials tab check local setup and display last saved case-source outcomes. These checks make no provider requests and do not establish current service availability. The nine offline tool contracts and document/STIX utilities are described in [integrations-v03.md](integrations-v03.md).

Version 0.2 also includes `phone_search`, using the same Brave endpoint and shared five-request-per-minute pacing, with exact-number variants and a maximum of 20 snippets. It records a result only when the complete number matches the returned text. Nearby emails are tentative co-occurrence leads. Its API key may come from the desktop session instead of an environment variable.

The `phone_pages` module retrieves only the supplied approved URLs, up to `max_pages`, using the same public HTTPS validation, exact host scope, robots rules, and six-request-per-minute ceiling as `webpage`. A stricter robots rate takes precedence. It does not automatically follow search results. Metadata records the matched text, evidence excerpt, and SHA-256 of the normalized text. International-format direct-page matches are source observations; national-only matches and all email associations stay tentative. See [phone research](phone-research.md) and [Scrapy import contract](scrapy-feed.md).

- **GitHub:** the unauthenticated primary quota is 60 requests/hour per originating IP. The local one-per-minute cap limits this framework's contribution, but cannot account for other clients on the same network. See [GitHub REST rate limits](https://docs.github.com/en/rest/using-the-rest-api/rate-limits-for-the-rest-api).
- **Bluesky:** public AppView limits differ from authenticated/PDS endpoints. This adapter uses the public API host and a deliberately low local rate; no throughput entitlement is assumed. See [API hosts](https://bsky.network/docs/api-directory/) and [rate limits](https://bsky.network/docs/rate-limits/).
- **DNS:** HTTP success alone is insufficient; the adapter checks the DNS `Status` field. NXDOMAIN yields no observations, while resolver failure is reported as an error. See [Google's DoH status documentation](https://developers.google.com/speed/public-dns/docs/doh).
- **crt.sh:** no numeric provider quota or uptime guarantee is asserted. The framework stops on failures, access denial, oversize responses, or cooldown responses. It does not switch to an alternate route to evade a block.
- **RDAP:** RDAP.org redirects to the authoritative registry; the registry may impose additional policies. Its documented front-door limit is 10 requests per 10 seconds. Every redirect consumes the framework's source budget and must resolve to public HTTPS. See [RDAP.org service guidance](https://about.rdap.org/).
- **Twilio:** Basic Lookup formats and validates phone numbers; additional data packages are separately requested through `Fields`. The adapter requests only Basic Lookup. See [Twilio Lookup quickstart](https://www.twilio.com/docs/lookup/quickstart).
- **HIBP:** the endpoint requires an eligible subscription, API key, and identifying User-Agent. Sensitive and retired breaches are excluded by the public API; this adapter also excludes unverified breaches. An empty response cannot establish that an account has never been breached. The displayed attribution must be retained when redistributing results. See [HIBP API documentation](https://haveibeenpwned.com/API/v3) and [terms](https://haveibeenpwned.com/TermsOfUse).
- **Hunter:** published Email Verifier ceilings are 10 requests/second and 300/minute; subscription credits remain separate. The adapter's five-per-minute cap is intentionally lower. See [Hunter API documentation](https://hunter.io/api-documentation).
- **VirusTotal:** the Public API currently allows 4 requests/minute and 500/day and restricts commercial use and certain business workflows. A suitable licensed tier is required when those restrictions apply. This adapter's rate cap does not track the account's daily quota or grant permission to use a free key commercially. See [Public versus Premium API](https://docs.virustotal.com/reference/public-vs-premium-api).
- **Shodan:** account and plan access affect available host data and quotas. A key does not imply access to every Shodan capability; only the documented host-read endpoint is called. See [Shodan API reference](https://developer.shodan.io/api).
- **Brave:** request limits are plan-specific. Queries are bounded to its documented 600 characters and 75 words; the module deliberately retrieves one result page only. See [Web Search reference](https://api-dashboard.search.brave.com/api-reference/web/search/get) and [rate-limit guidance](https://api-dashboard.search.brave.com/documentation/guides/rate-limiting).

The framework records a cooldown after HTTP 429 or a retryable 503 carrying `Retry-After`; it does not retry in a tight loop. Missing keys, incompatible source input, or denied access are marked `skipped`. Malformed responses and network failures are marked `error`. These statuses are never transformed into a claim that an identifier does not exist.

## Evidence and collection boundaries

`certain` means the source returned the stated observation. A profile claim, breach association, DNS address, or vendor assessment does not identify the same real-world person across services. Search results are always `tentative`. Phone prefix descriptions and original carrier metadata do not establish a person's location, number assignment, or current carrier.

Source URLs and identifiers are validated before findings are accepted. Returned GitHub/Bluesky handles, RDAP domains and IP ranges, and available Twilio/VirusTotal/Shodan identifiers are checked against the query. Credentials are passed only in provider-required headers, authentication, or parameters and are excluded from evidence URLs and copied metadata. The core HTTP client supplies credential-safe error messages.

The native modules do not recursively query discovered identifiers. Variable-length result sets retain at most `max_findings + 1` observations internally, allowing the engine to keep the requested number and mark `truncated=true` when a further observation was found. A false truncation flag means the local result cap was not exceeded; it does **not** mean the source, provider index, or internet was exhaustively searched. Brave has a separate fixed one-page limit, and crt.sh results may reflect historical certificates or omit unavailable records.

Certificate wildcard names such as `*.example.com` are preserved as pattern records. They are not converted into a claim that a certificate covers the apex `example.com`.

API documentation links describe interfaces and source-specific access terms. They do not replace the operator's authorization, provider agreement, or restrictions applying to a particular investigation. The software's MIT license does not relicense provider data.

## Corrections to the original source list

**Bing Search APIs are retired.** Microsoft announced complete decommissioning on **2025-08-11**. The older standalone Bing Web Search endpoint is consequently not integrated. Grounding with Bing Search in Azure AI Agents is a separate product and has not been presented as a drop-in native adapter. [Microsoft lifecycle notice](https://learn.microsoft.com/en-us/lifecycle/announcements/bing-search-api-retirement)

**Google Custom Search JSON API is closed to new customers.** Google gives existing customers a **2027-01-01** transition/decommission date. This framework therefore does not ship a new-customer Google Custom Search integration; Brave provides the implemented search adapter. [Google Custom Search overview](https://developers.google.com/custom-search/v1/overview)

Other researched tools and their integration status are documented separately in [tool-research.md](tool-research.md). Catalog inclusion is not a claim that every upstream feature runs inside this framework.
