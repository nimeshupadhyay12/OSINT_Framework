# Version 0.5: upgrade, operation and boundaries

This is an expanded OSINT workbench, not an exhaustive internet index. It has 30 collection/source modules and 13 explicit import contracts. The core desktop, CLI and SQLite workflow run locally. PostgreSQL, OIDC identity providers, Docker and OpenCTI require separate services and deployment validation.

## Start using this release

1. Close any older OSINT window, then open **Launch OSINT.cmd** in the main `osint-framework` folder. The header should show **VERSION 0.5**. For a new installation, run **Setup OSINT.cmd** first.
2. Choose **Try synthetic case** to see evidence and graphs without sending queries.
3. For your own authorized investigation, enter an identifier, select its type and write a purpose of at least eight characters, such as `Authorized domain review`. A missing purpose now brings the field into view with a direct explanation.
4. Choose compatible sources. **Select compatible sources without API keys** excludes keyed services. For additional services, open **Sources and credentials**, choose the credential, paste its key, and use the session or explicit OS-keychain action.
5. Confirm authorization and run. Review each source's status: `empty`, `error`, `skipped`, `rate_limited` and `ok` mean different things. Failed sources do not establish that an identifier has no information.
6. Inspect evidence URLs, timestamps and confidence. Accept/reject observations with a reason, add case notes, and save/export the case.

Existing cases and reports remain in their original workspace. The upgrade does not encrypt or migrate them automatically. Advanced commands below use `osint`; on this Windows installation, replace it with `.\osint.ps1` if the CLI is not on PATH.

## New data sources

| Source | Input | Setup | Returned information |
|---|---|---|---|
| `commoncrawl` | domain | No key | Historical URLs in the first index page of the latest collection; no archived-body downloads |
| `certspotter` | domain | `CERTSPOTTER_API_KEY` | First page of certificate issuances and in-scope DNS names |
| `otx` | domain, IP, URL | `OTX_API_KEY` | Indicator summary and community pulse count |
| `urlhaus` | domain, IP, URL | `ABUSECH_AUTH_KEY` | Exact-host or exact-URL metadata; no payload downloads |
| `threatfox` | domain, IP, URL | `ABUSECH_AUTH_KEY` | Exact IOC search and upstream threat labels |

Account-based free access is subject to provider terms and quotas; commercial use can require different arrangements. Cert Spotter's free account is documented by [SSLMate](https://sslmate.com/ct_search_api/). Other references: [OTX SDK](https://github.com/AlienVault-OTX/OTX-Python-SDK), [URLhaus API](https://urlhaus-api.abuse.ch/), [ThreatFox API](https://threatfox.abuse.ch/api/), [Common Crawl index](https://index.commoncrawl.org/).

All lookups have local pacing, response limits and a request budget. These five adapters use synthetic transport/response tests. The live Common Crawl check on `example.org` returned HTTP 504 on 2026-09-14; this release does **not** claim a successful live Common Crawl acceptance test. No new account-key provider was live-tested. Threat labels are provider claims, not independent maliciousness verdicts; a zero pulse count is not a safety guarantee.

```powershell
osint init
osint run example.org --type domain --modules commoncrawl --purpose "Authorized domain inventory" --authorized
osint run example.org --type domain --modules certspotter,otx,urlhaus,threatfox --purpose "Authorized threat context review" --authorized
```

## MISP and OpenCTI

`misp` imports a single event's supported typed attributes matching the exact query. Supported types are domain, hostname, source/destination IP, source/destination email, phone-number and URL. Objects, galaxies, attachments and automatic event-wide pivots are outside the contract. Event membership does not imply that attributes belong to one person.

```powershell
osint import-results event.json --tool misp --query example.org --type domain --purpose "Authorized MISP evidence review" --authorized
osint export-misp reports/RUN_ID/report.json draft-event.json
```

MISP export creates a draft event with `published=false`, distribution `0` (organisation only), and `to_ids=false`. Server-assigned IDs are omitted. Relevant tags are retained. This is an import draft, not a full MISP database backup. STIX-marked findings cannot be converted to MISP, and imported MISP sharing controls cannot be converted to STIX automatically; the application rejects those cross-format conversions rather than dropping restrictions.

An optional **one-shot OpenCTI external-import connector** uses `OpenCTIConnectorHelper`, platform work tracking and `send_stix2_bundle`, following the [official connector lifecycle](https://docs.opencti.io/latest/development/connectors/). Install it in a dedicated environment with `pip install '.[opencti]'` and configure `OPENCTI_URL` (HTTPS), `OPENCTI_TOKEN`, and a stable UUID in `OPENCTI_CONNECTOR_ID`.

```powershell
osint opencti-send reports/RUN_ID/report.json --authorized --purpose "Transfer reviewed evidence to our OpenCTI instance"
```

This command writes to that configured service. It does not run automatically during collection. A submitted receipt means the platform accepted the connector submission path; check platform worker ingestion before considering import complete. Uncertain transfers are audited and never retried automatically. The helper lifecycle is fixture-tested, but the optional SDK/server combination has not been acceptance-tested against a real OpenCTI deployment here.

## Evidence bundles and WARC

Signing keys use Ed25519 and encrypted PKCS#8 private-key storage. Keep the private key and its passphrase separate from shared evidence. The CLI uses a masked prompt or the transient `OSINT_SIGNING_PASSPHRASE` environment variable.

```powershell
osint evidence keygen .osint-state/signing.key
osint evidence bundle reports/RUN_ID/report.json case-evidence.zip --key .osint-state/signing.key --evidence-root reports
osint evidence verify case-evidence.zip --public-key .osint-state/signing.pub
osint evidence warc reports/RUN_ID/report.json preserved.warc.gz --evidence-root reports
```

For an encrypted workspace, add `--state YOUR_ENCRYPTED_STATE` to export commands. These are explicit **plaintext exports**, including any decrypted preserved evidence. A bundle contains a portable report, preserved bytes, a manifest and its signature. Its limits are 200 MB and 998 unique artifacts. Verification requires a separately trusted public key, checks every file and rejects unsigned additions. It does not extract the archive.

Signatures establish byte integrity against that key; they do not certify source truth, ownership, an independent signing time or legal admissibility. WARC output uses **resource records**, because this application preserved response bodies without complete original HTTP headers. It is not a full browser capture or replay recording. Original document artifacts retain their document URN where applicable.

Detached file signatures are available through `evidence sign-file` and `evidence verify-file`; see their `--help` output. The local release archive has SHA-256 checksums. A manually triggered GitHub build/attestation workflow is supplied, but has not run here; local archives do not claim a published GitHub attestation.

## Team access changes

New bearer tokens expire after 30 days by default; choose 1–90 days with `--days`. **Old v0.4 tokens have no expiry and become invalid when the schema upgrades.** Rotate them:

```powershell
osint team user-rotate analyst --days 30
osint team user-add researcher --role analyst --days 14
```

User revocation, role checks and case grants still apply. Queued jobs check that their submitting account is active when starting. Revocation does not roll back completed collection or immediately interrupt an already running network request.

The API enforces 120 authenticated requests/minute per principal and 600 requests/minute for the server, using shared database windows. These are application controls, not DDoS protection. Expiry and rate counters work across API processes sharing the database.

Optional OIDC accepts signed RS256/ES256 JWT access tokens. Configure `OSINT_OIDC_ISSUER`, `OSINT_OIDC_AUDIENCE` (an audience dedicated to this API) and a trusted HTTPS `OSINT_OIDC_JWKS_URL`. Exact issuer, audience, subject, issue time and expiry are checked. Provision the local role, then map the exact subject:

```powershell
osint team bind-oidc researcher https://idp.example.org/ SUBJECT_FROM_YOUR_IDP
```

Role claims in the token are ignored. Local revocation and account expiry apply to mapped users too. To require a provider-defined MFA context, set `OSINT_OIDC_REQUIRED_ACR` to its documented accepted `acr` values. Configure MFA at the identity provider; this application does not perform MFA enrollment or provide a browser login flow. JWT signatures and rejection paths are tested with generated local keys; real IdP discovery, JWKS rotation and login require deployment testing.

## Optional PostgreSQL and Docker deployment

Leave `OSINT_DATABASE_URL` empty for the existing SQLite desktop. PostgreSQL is opt-in through a `postgresql://...` URL and `OSINT_DATABASE_SCHEMA` (default `osint`). Application tables, queue leases, pacing and audit records then share that schema. The adapter uses short advisory-lock transactions for queue claims and shared counters. It is not an unbounded distributed scheduler; the pending-job limit remains 1000.

There is **no automatic SQLite-to-PostgreSQL migration**. Start a new team workspace. Workers must share the same evidence filesystem and workspace configuration; encrypted workers need the same vault manifest and key. Database administrators and local filesystem owners remain trusted. Back up the database, evidence and any vault manifest together.

Docker and PostgreSQL are not installed on the development machine, so these templates have not been launched locally. A real PostgreSQL concurrency/audit test is included in CI and can be run with `OSINT_TEST_POSTGRES_URL` against a disposable test server; it creates and removes its own uniquely named schema.

From the project folder, after installing Docker, set `POSTGRES_PASSWORD` to a strong URL-safe secret (for example a randomly generated hex password), then:

```powershell
docker compose -f deploy/compose.yml build
docker compose -f deploy/compose.yml up -d db
docker compose -f deploy/compose.yml run --rm api osint init --state /data/state --accept-policy
docker compose -f deploy/compose.yml run --rm api osint team user-add administrator --role admin --state /data/state --days 30
docker compose -f deploy/compose.yml up -d api worker
```

The API port is published on loopback only; PostgreSQL is not published. Containers run as a non-root application user with a read-only root filesystem, dropped capabilities and a bounded temporary filesystem. The default shared workspace is plaintext. Image tags are supplied for setup; pin reviewed image digests and validate backups, TLS, OIDC and resource limits before production use. `deploy/Caddyfile.example` shows a host TLS proxy; configure your real domain, DNS, certificates and exact `OSINT_TRUSTED_HOSTS`. No domain or external service is deployed by this release.

## Plugin and tool approval

Installed Python plugins now require an approved distribution name, version and file digest:

```powershell
osint approve-plugin PLUGIN_ENTRY_NAME plugin-lock.json --reviewed
$env:OSINT_PLUGIN_LOCK = (Resolve-Path plugin-lock.json).Path
```

Only run approval after reviewing the installed code and dependencies. Changes to the distribution invalidate its approval. Editable distributions are rejected. The lock does not audit dependency packages or sandbox code; use a dedicated environment for plugins. A lock can contain multiple reviewed entries in its `plugins` object.

Subfinder now requires `OSINT_SUBFINDER_SHA256` equal to the independently reviewed executable's hash. It runs with an isolated home/config directory and fixed passive-source arguments. That is integrity checking, not OS-level network isolation. No scanner binary is installed or bundled. **Sherlock, Maigret, theHarvester and Amass remain offline-import integrations, not newly validated executable runners.** Their existing export contracts are documented in README.md.

## Search and retention

```powershell
osint search-case CASE_ID example.org --source dns --limit 100
osint retention-plan --days 90
osint delete-case-records CASE_ID --confirm-case-id CASE_ID
```

Search is literal and case-insensitive, with source/review filters and evidence IDs; the team endpoint `/cases/{id}/search` enforces case access. It does not merge identities. Existing graph paths preserve evidence direction and exclude rejected claims.

Retention planning only lists cases older than the last saved report (or creation time). Read recent notes/reviews before deleting. Deletion requires the exact ID twice, refuses cases with queued/running jobs, and deletes only that case's database records. It preserves exported files, original documents, audit records and other cases. This is **not secure erasure**; database free pages, filesystem copies and backups require a separate retention policy. No user case is purged by the v0.5 release cleanup.

## Remaining professional-readiness work

The project includes controls and tests, but does not claim an independent security review or universal coverage. Remaining work includes live provider contract testing with supplied accounts, real PostgreSQL/container/IdP/OpenCTI acceptance tests, reviewed runners for the four import-only tools, source-pagination expansion, measured false-positive/reliability benchmarks, full evidence retention across backups, and cross-platform hosted CI execution. Review [validation.md](validation.md) for actual completed checks. A bigger integration count is not evidence that every source works for every input.
