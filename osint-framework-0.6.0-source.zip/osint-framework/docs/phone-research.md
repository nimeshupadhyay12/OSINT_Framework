# Phone-number public-evidence research

Reviewed against the linked directory and primary project documentation on **2026-09-12**. This is a research and integration-boundary record. An upstream feature appearing here does not mean that this framework runs it. See the [README](../README.md), [source inventory](sources.md), and [plugin contract](plugins.md) for implemented behavior.

## The requested Start.me reference

The supplied [OSINT directory](https://start.me/p/b59RMv/osint) was successfully opened and read in a browser. A separate web text-fetch attempt failed; the rendered browser page subsequently loaded its public bookmark lists. The page title was **OSINT**, with **dhaval upadhayay** shown as its owner.

Relevant links actually observed were:

- Under **Scrapers**: the upstream [Scrapy repository](https://github.com/scrapy/scrapy).
- Under **Email OSINT**: [SpiderFoot](https://github.com/Dhavalu585/spiderfoot) and [theHarvester](https://github.com/Dhavalu585/theHarvester) links pointing to the directory owner's forks, plus [Have I Been Pwned](https://haveibeenpwned.com/).
- Under **Chrome Extensions**: [Hunter](https://hunter.io/).
- Under **Popular OSINT Platforms**: [OSINT Framework](https://osintframework.com/).
- Under **Email OSINT - New**: [cipher387's OSINT tool collection](https://github.com/cipher387/osint_stuff_tool_collection).

This verifies those bookmarks, not their current functionality or provider entitlements. Upstream sources, rather than the directory's forks, underpin the existing [broader tool review](tool-research.md). The rendered directory did not show PhoneInfoga, python-phonenumbers, Brave Search API, or Trafilatura; those are independently researched candidates below. No subscriber, private-contact, or leaked-data lookup was performed during this review.

## Six relevant components

| Component | Role and available interface | License or access model | Integration boundary |
| --- | --- | --- | --- |
| [python-phonenumbers](https://github.com/daviddrysdale/python-phonenumbers) | Local parsing, E.164/national/international formatting, number matching in text, and numbering-plan metadata. Python library interface; no provider API needed. | Apache-2.0 | Already used by `phone_local`. Suitable foundation for input normalization and exact phone matching. |
| [PhoneInfoga](https://github.com/sundowndev/phoneinfoga) | Configurable phone research application with a CLI, browser interface, REST API, and Go modules. | GPL-3.0; upstream README describes it as stable but unmaintained. | Research reference only. No bundled binary, runner, or PhoneInfoga-specific importer is claimed. |
| [Scrapy](https://github.com/scrapy/scrapy) | Python crawler with structured extraction and [JSON/JSON Lines/CSV feed exports](https://docs.scrapy.org/en/latest/topics/feed-exports.html). | BSD-3-Clause | The v0.2 importer supports the explicit [public-page-v1 item contract](scrapy-feed.md) in JSON/JSONL. No crawler binary or arbitrary spider schema is bundled. |
| [Trafilatura](https://github.com/adbar/trafilatura) | Python and CLI text/metadata extraction, including from previously downloaded HTML; supports JSON and other output formats. | Apache-2.0 for current releases; versions before 1.8.0 use GPLv3+. | Candidate extraction component, not an installed adapter. Feed already retrieved HTML to an extractor while keeping collection scope in the framework. |
| [Brave Web Search API](https://api-dashboard.search.brave.com/api-reference/web/search/get) | Official `GET /v1/web/search`, authenticated with `X-Subscription-Token`; returns indexed result URLs and snippets. | Hosted service with provider terms and plan limits; not an open-source index. | The v0.2 `phone_search` adapter checks complete number matches in returned text and records nearby email leads. Direct page collection is separately scoped through `phone_pages`. |
| [Twilio Lookup v2](https://www.twilio.com/docs/lookup/v2-api) | Basic Lookup formats and validates a number; optional additional packages are requested separately through `Fields`. | Hosted service requiring credentials; optional data packages are paid. | Existing `twilio` adapter requests Basic Lookup only. It does not supply an email address associated with a phone number. |

PhoneInfoga's maintenance status makes it a poor mandatory dependency for a new core workflow. Its documentation advertises a REST interface, but a version-pinned response fixture and reviewed scanner configuration would be needed before writing an importer or connector. The existence of an upstream API alone does not establish that every scanner still works. [Upstream README](https://github.com/sundowndev/phoneinfoga), [official documentation](https://sundowndev.github.io/phoneinfoga/).

Scrapy and Trafilatura solve collection and extraction problems. Neither independently establishes that an email belongs to the person using a supplied number. Trafilatura can omit repetitive headers and footers, so a future contact extractor should retain the original page evidence rather than rely solely on cleaned article text. [Trafilatura extraction description](https://github.com/adbar/trafilatura).

## What a phone-to-email result can establish

Number validation describes the numbering plan. It cannot establish current assignment, reachability, the subscriber's identity, or the person's location. Portability can make the library's carrier attribution historical. These limits are explicitly described in Google's [libphonenumber FAQ](https://github.com/google/libphonenumber/blob/master/FAQ.md).

An evidence-based public-page workflow should normalize the supplied number, search a small set of its complete formats, and retain the public pages containing an exact normalized match. An email on that page is a **co-occurrence observation**. It can be a business contact, shared switchboard, unrelated directory entry, stale contact, or third-party claim. It should retain the page URL and matching context without being labelled a verified owner email.

Brave documents [quoted phrases and other search operators](https://api-dashboard.search.brave.com/documentation/resources/search-operators). Quotation marks help focus retrieval, but the collector must still validate returned text: a search result or snippet does not prove the page contains the exact number. Search indices omit unindexed and inaccessible pages, and snippets can be stale. A keyed search service also receives the query; local number formatting does not make network searches offline.

For direct collection, keep explicit public-host scope, page limits, robots decisions, response size limits, and source timestamps. Matching numbers across several pages is not by itself independent corroboration when the pages repeat the same source. A no-result report means no matching evidence was returned within that run's scope, not that the number has no public footprint.

## Imports and extension path

The generic import contract accepts canonical Finding JSON, JSON arrays, JSONL, or a `findings` wrapper. It is not a universal importer for arbitrary upstream JSON. Scrapy now has a [versioned item mapping and synthetic fixtures](scrapy-feed.md). Trafilatura and PhoneInfoga still need versioned mappings and fixtures before being labelled supported. Preserve tool version, original export digest, query subject, source URL, and collection time when known; distinguish import time from collection time.

A trusted plugin can implement the [existing source protocol](plugins.md) for a reviewed source. Keep the source name and available fields explicit. The framework's open-source license does not change a provider's access conditions or relicense upstream code or collected data. This review did not install or execute the researched third-party tools.
