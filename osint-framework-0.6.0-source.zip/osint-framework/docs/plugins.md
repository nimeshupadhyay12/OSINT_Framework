# Trusted source plugins

Version 0.5 requires a reviewed installed-distribution lock before loading a plugin. Run `osint approve-plugin NAME plugin-lock.json --reviewed` after reviewing the code and dependencies, and point `OSINT_PLUGIN_LOCK` at that file. A changed version or distribution file invalidates approval; editable distributions are rejected. The lock covers the plugin distribution, not transitive dependencies or process isolation. See [release-v05.md](release-v05.md).

Implement the protocol in `osint_framework.core.schema`. A module is a zero-argument class with `spec: ModuleSpec` and `async run(context, http) -> list[Finding]`. Installed code is loaded only after the operator specifies `--plugin NAME`; discovery alone does not import it. Plugin code has the same permissions as the CLI. Audit and HTTP helpers cannot sandbox code that chooses to bypass them.

```python
from osint_framework.core.schema import Entity, Finding, ModuleSpec

class ExampleSource:
    spec = ModuleSpec(
        name="example_source",
        input_types=["domain"],
        description="One documented public source",
        rate_limit_per_min=5,
        terms_url="https://provider.example/terms",
    )

    async def run(self, context, http):
        # The example domain is a placeholder; implement a reviewed provider here.
        # Use http.get_json(..., source=self.spec.name,
        #   rate_limit_per_min=self.spec.rate_limit_per_min, pinned=True)
        # for an additional keyless public HTTPS API host. It uses DNS-pinned public requests.
        return []
```

In the plugin distribution's `pyproject.toml`:

```toml
[project.entry-points."osint_framework.modules"]
example_source = "my_package.source:ExampleSource"
```

Then `osint run example.org --type domain --plugin example_source --modules example_source --purpose "Authorized CASE-001" --authorized`. The entry-point name must equal `spec.name` and must not replace a built-in. Do not load unreviewed packages or add credentials to evidence URLs. `SourceSkipped`, `SourceError`, and `RateLimited` support safe status reporting; other exception details are suppressed.

The shared HTTP client supports bounded HTTPS GET with optional `params`, `headers`, `auth`, and `not_found_ok`. `get_json` returns parsed JSON; `get_text` accepts `allowed_content_types`. `pinned=True` is required for additional keyless public hosts and connects to a checked public address with the original Host/TLS name. Public-page retrieval rejects authentication and common credential headers. Adding a new credentialed provider to the shared client requires review of its fixed hostname allowlist; do not disguise credentials as public-page parameters. No redirects are followed except the narrowly designated RDAP bootstrap behavior. All source requests must use a truthful User-Agent and respect finite per-request pacing.

Confidence labels describe relationships. `certain` can mean a source directly published a value; it must not imply certainty about real-world ownership. For third-party exports use tentative confidence, preserve file provenance and original source times, and keep unknown outcomes distinct from absent records.
