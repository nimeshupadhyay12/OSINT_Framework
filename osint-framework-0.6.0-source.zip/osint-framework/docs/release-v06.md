# Version 0.6 — fixes and guided research

This release addresses the four reproduced v0.5 review findings, adds two collectors and three import contracts, and introduces guided research. Start with the [quickstart](quickstart-v06.md); the [repository evaluation](repository-evaluation-v06.md) explains integration choices.

**STIX evidence**

Finding identity includes upstream STIX object ID and relationship type. Distinct relationships remain separate in cases and graphs. Repeated observations conservatively retain object/granular markings; later unmarked evidence cannot silently remove earlier restrictions. Conflicting marking definitions fail closed. Shared definitions serialize once per report and survive case combination.

Legacy reports normalize on read without rewriting stored originals. Existing analyst reviews tied to former ambiguous STIX IDs may need reassessment; review history remains stored. There is no automatic declassification operation.

**Resource limits**

Imports enforce an 8 MB aggregate serialized-finding budget alongside the 10 MB input and finding-count limits. Reports enforce a 16 MB serialized JSON budget before persistence/export. Exceeding a limit produces an explicit request to narrow or split the scope.

Anonymous API traffic uses separate per-peer (60/minute) and aggregate (600/minute) windows. Authenticated traffic retains per-principal (120/minute) and separate aggregate (600/minute) windows. Forwarding headers are not trusted to create client identities. Request bodies are limited to 64 KB and five seconds. These controls are not DDoS protection.

`GET /cases/{id}` now accepts `limit` (default 10, maximum 25) and `offset` (default 0). Report pagination is applied in the database. Clients must request subsequent pages. Case-wide graph/search operations still require appropriately bounded case sizes.

**WARC export**

Document artifacts record a hash URN, capture timestamp and schema version. Export verifies scope, digest and size, validates dates/locators, and applies 998-artifact / 200 MB budgets. It writes a temporary file and atomically publishes the complete archive without overwriting an existing destination. Failed validation or writing leaves no final partial archive.

Legacy documents use a hash URN and, when necessary, report creation time with an explicit limitation. Encrypted inputs are decrypted for the requested plaintext export. WARC resource records preserve bytes, not full browser sessions or independently certified evidence.

**Research workflow**

There are 32 source modules and 16 import contracts. Quick selects no-key sources; broad includes configured compatible providers. Guided mode excludes executable runners, and page collection still requires explicit scope. Report coverage records the source plan, exclusions, queries and shared request budget. HTML notes expose unavailable and incomplete sources.

Deep domain research follows one level of discovered subdomains: up to three in the desktop, five in the CLI. DNS, RDAP and certificate-index follow-ups share the original HTTP budget. Personal identifiers are not recursively expanded. Completed runs are saved in the case, and cancellation prevents further pivots.

**Verification limits**

Regression tests cover the four reproduced failures, relationship order, repeated marked/unmarked observations, legacy metadata, output budgets, anonymous quota isolation, pagination, encrypted/legacy document exports, and interrupted archive writes. New fixtures cover source/import scope, malformed responses, uncertainty, domain pivots and shared budgets.

Actual PostgreSQL, identity-provider, OpenCTI and authenticated-provider deployment acceptance still requires configured services. See the validation record for completed release checks. This is not independent certification, universal coverage or production deployment approval.
