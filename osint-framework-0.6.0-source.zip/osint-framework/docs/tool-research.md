# Open-source OSINT integration research

Reviewed: 2026-09-12. This research uses upstream repositories and project documentation. Repository defaults and documentation can move independently of released packages; pin a release or commit and retain a sample export before enabling any runner. Commands below describe upstream interfaces and were not executed during this review. Integration recommendations are engineering judgments, not claims that these tools or all their sources work in this framework today.

## Integration decisions

**Implementation update for v0.4:** the [current contracts](free-and-team-v04.md#community-tool-imports) add Recon-ng hosts/contacts CSV, Photon internal/subdomain JSON, and WhatsMyName unchecked candidate URL planning. They extend the [v0.3 imports, live Scrapy and STIX exchange](integrations-v03.md). Subfinder retains the bounded optional runner. Exact supported contracts take precedence over broader future-boundary recommendations below; full upstream runtimes and arbitrary export versions remain unsupported.

Prefer stable data interchange before embedding another application's runtime. Keep original exports as evidence and normalize a deliberately small set of supported fields. A tool name in a catalog means it was researched; it does not mean every module, source, or export version has been implemented or tested.

Use three distinct activity labels:

- **Offline import:** consumes an existing file without network requests.
- **Third-party passive query:** asks a public index or provider about the subject. The provider can observe the query.
- **Direct public retrieval:** requests a subject website or public profile. This is network activity against that service, even if a tool markets it as OSINT or passive.

The framework should not treat username equality, shared IP addresses, or one tool's positive status as proof of a shared identity. Preserve the observed fact, source, collection time, uncertainty, and supporting URL separately from the inferred relationship.

## Verified tools and recommended boundaries

| Project | Upstream license identified | First integration boundary | Collection behavior |
| --- | --- | --- | --- |
| [Sherlock](https://github.com/sherlock-project/sherlock) | MIT | CSV import | Direct public profile checks |
| [Maigret](https://github.com/soxoj/maigret) | MIT | JSON / NDJSON import | Direct checks, parsing, optional recursion and enrichment |
| [WhatsMyName](https://github.com/WebBreacher/WhatsMyName) | CC BY-SA 4.0, dataset | Registry import with provenance | Dataset itself makes no requests; consumers implement checks |
| [SpiderFoot](https://github.com/smicallef/spiderfoot) | MIT | Implemented selected JSON web-export events | Mixed; module selection determines activity |
| [Recon-ng](https://github.com/lanmaster53/recon-ng) | GPL-3.0, repository declaration | Header-bearing CSV export import | Mixed; marketplace modules determine activity |
| [Subfinder](https://github.com/projectdiscovery/subfinder) | MIT | JSONL import; bounded optional passive runner | Third-party passive sources; optional active DNS mode |
| [OWASP Amass](https://github.com/owasp-amass/amass) | Apache-2.0; some components have separate licenses | Implemented v5 `oam_subs` names text import | Mixed passive and active discovery |
| [theHarvester](https://github.com/laramies/theHarvester) | GPL-2.0-only, package metadata | Implemented v5 completed-result JSONL subset | Passive discovery plus separately selected DNS and direct actions |
| [Photon](https://github.com/s0md3v/Photon) | GPL-3.0, repository declaration | JSON export import | Direct website crawling |

License identifiers describe the reviewed upstream declarations. Preserve third-party notices and review the actual pinned component and dataset licenses before redistributing them; an external-process design is not itself a license conclusion.

### Sherlock

The upstream CLI supports CSV, XLSX, and text reports, site selection, and per-request timeouts. `--json` specifies a **site definition input**, not a JSON result export. Its CSV writer uses `username`, `name`, `url_main`, `url_user`, `exists`, `http_status`, and `response_time_s`. Preserve non-positive statuses instead of collapsing errors into absence. [README / CLI](https://github.com/sherlock-project/sherlock), [CSV writer](https://github.com/sherlock-project/sherlock/blob/master/sherlock_project/sherlock.py).

An upstream example adapted for a limited review is `sherlock example_user --site GitHub --csv --timeout 10`. This still contacts the selected service and can contact upstream data/update endpoints. Recommend CSV import first. A future runner must constrain sites, usernames, total duration, and output size and reject arbitrary extra flags. URL patterns and detection rules change; retain their version with each run. License: [MIT](https://github.com/sherlock-project/sherlock/blob/master/LICENSE).

### Maigret

The project supports `--json simple`, `--json ndjson`, and CSV exports, and also documents Python library use. It can parse additional identifiers and recurse into discovered usernames. Therefore import explicit positive/unknown statuses and their original URLs without automatically launching follow-up searches. [Repository and report examples](https://github.com/soxoj/maigret).

The CLI documents `--no-recursion`, `--max-connections`, `--timeout`, `--no-autoupdate`, `--db`, and site filtering. A custom database error may fall back to the bundled database, so a future runner must verify the loaded site set; merely passing `--db` is not sufficient enforcement. Also, a `--top-sites` count may be extended by mirrors. Keep optional AI, bypass, cookies, Tor/I2P, and discovered-identifier expansion outside this adapter. [Current CLI documentation](https://maigret.readthedocs.io/en/latest/command-line-options.html).

Recommend offline simple JSON/NDJSON imports with explicit format fixtures first, keeping extracted attributes as unverified observations. License: [MIT](https://github.com/soxoj/maigret/blob/main/LICENSE).

### WhatsMyName

WhatsMyName is now a community-maintained JSON dataset; it removed bundled checker scripts in 2023. The registry describes how consumers should detect existing and missing accounts. Its public-profile inclusion criteria exclude login/paywall-only profiles. [Project README](https://github.com/WebBreacher/WhatsMyName/blob/main/README.md).

Import only a pinned local `wmn-data.json`, record its digest and upstream reference, and validate against the schema. Relevant fields include `name`, `uri_check`, `uri_pretty`, `e_code`, `e_string`, `m_code`, `m_string`, `known`, `cat`, `valid`, `protection`, `post_body`, and `headers`. Recommend enabling only reviewed HTTPS GET entries, skipping disabled/protected entries, and treating positive status/body checks as leads. Headers, POST instructions, redirects, and URLs from the dataset remain untrusted input. Do not execute arbitrary dataset-supplied requests. [Schema](https://github.com/WebBreacher/WhatsMyName/blob/main/wmn-data-schema.json), [contribution format](https://github.com/WebBreacher/WhatsMyName/blob/main/CONTRIBUTING.md).

The dataset uses [CC BY-SA 4.0](https://github.com/WebBreacher/WhatsMyName/blob/main/LICENSE.md); retain attribution and handle redistributed adaptations accordingly.

### SpiderFoot

SpiderFoot is a Python framework with a SQLite backend, numerous collection modules, and CSV/JSON/GEXF export. It includes both public-data providers and modules that perform DNS brute force, zone-transfer attempts, scanning, or other direct interactions. Recommend importing selected scan events, with module name, source event, event type, timestamp, and original data retained. [Upstream README and module catalog](https://github.com/smicallef/spiderfoot).

The CLI accepts `-s TARGET`, `-u passive`, `-m MODULES`, `-o json`, and `-max-threads`. Crucially, omitting modules, event types, and a use case enables **all modules**. Do not create a runner whose missing setting can trigger that fallback. A future process adapter should use an audited module allowlist and a finite runtime, rather than accept free-form CLI arguments. [CLI source](https://github.com/smicallef/spiderfoot/blob/master/sf.py).

License: [MIT](https://github.com/smicallef/spiderfoot/blob/master/LICENSE). The broad module count is not a promise that all providers remain available or require no credentials.

### Recon-ng

Recon-ng provides a modular web reconnaissance environment. Import an existing workspace export before considering orchestration: module APIs, provider credentials, marketplace availability, and report schemas vary. The repository declares [GPL-3.0](https://github.com/lanmaster53/recon-ng), with the license text in [LICENSE](https://github.com/lanmaster53/recon-ng/blob/master/LICENSE).

Its marketplace `reporting/csv` module exports a selected workspace table. The module has `table`, `filename`, and `headers` settings, with `headers` defaulting to false. Require headers for the framework's import contract, declare the table/entity mapping, and preserve unknown columns instead of guessing their meaning. [CSV reporting module](https://github.com/lanmaster53/recon-ng-marketplace/blob/master/modules/reporting/csv.py).

Recommend import-only support initially. A future runner must separately review each module and its license, source behavior, input scope, credentials, and output contract. Do not assume that a framework-level label makes every installed module passive.

### Subfinder

Subfinder is purpose-built for passive subdomain discovery from online sources. JSONL export uses `-oJ`; `-cs` retains contributing sources. It provides source selection (`-s`), global/provider request limits (`-rl`, `-rls`), timeouts, maximum enumeration time, and update-check suppression (`-duc`). `-active`/`-nW` enables active resolution and `-oI` requires that mode. [Repository CLI reference](https://github.com/projectdiscovery/subfinder).

Recommended candidate for the first bounded external runner, after pinning and local compatibility testing:

```text
subfinder -d example.com -s crtsh -oJ -cs -rl 1 -timeout 10 -max-time 1 -duc -o subfinder.jsonl
```

This is an upstream command example, not a claim that a runner has been installed. The framework should supply the reviewed provider config explicitly, limit the process's wall time/output independently, and reject active mode. Import `host` as a discovered domain and preserve provider attribution. Deduplicate evidence shared across tools so the same underlying certificate record does not become multiple independent confirmations. License: [MIT](https://github.com/projectdiscovery/subfinder/blob/dev/LICENSE.md).

### OWASP Amass

Amass combines open-source gathering with active reconnaissance. Current official documentation uses the v5 module path, an asset database, and the Open Asset Model. A universal adapter based on old `enum -json` examples would be an unsupported compatibility claim. [Repository](https://github.com/owasp-amass/amass), [current documentation](https://owasp-amass.github.io/docs/).

The v0.3 adapter uses the verified v5 `oam_subs -names -nocolor` names-only output. It does not interpret the asset database or legacy JSON. Provider attribution and collection timestamps are unavailable in that text format and remain unknown. This review did not establish a portable current JSON export command or a sufficiently bounded passive runner. Upstream execution remains separate from this framework.

License: [Apache-2.0](https://github.com/owasp-amass/amass/blob/main/LICENSE); the repository notes separately licensed subcomponents. Amass is a strong graph model reference, but that does not make its current storage format a drop-in match for this framework.

### theHarvester

The current project describes domain/organization collection from public sources and supports JSONL, SQLite, JSON, and XML. Its README distinguishes passive sources (P0), DNS actions (P1), and direct HTTP/TLS/other actions (P2). Current package metadata requires Python 3.14 and declares GPL-2.0-only, reinforcing the benefit of a separate runtime. [README](https://github.com/laramies/theHarvester), [package metadata](https://github.com/laramies/theHarvester/blob/master/pyproject.toml).

An upstream passive example is `uv run theHarvester -d example.com -b crtsh,certspotter`. Recommend explicit providers and finite limits, preserving partial-source stop reasons. Avoid source bundles and active flags in a first integration. The current docs expose multiple evolving output contracts, so validate a chosen JSON/JSONL fixture rather than assuming every historical export has the same fields. [Operator workflows](https://github.com/laramies/theHarvester/blob/master/docs/wiki/Operator-Workflows.md).

Initially accept only supported offline export versions. Do not infer a person's identity from an email string or a hostname from an unrelated URL field.

### Photon

Photon directly crawls websites and extracts URLs, files, scripts, endpoints, and other content. Its README identifies JSON export; the usage wiki documents `--export=json`, `-l` crawl depth, `-t` threads, `-d` request delay, and `--timeout`. The wiki was last edited in 2019, so current source/CLI verification is required before any runner. [Repository](https://github.com/s0md3v/Photon), [usage reference](https://github.com/s0md3v/Photon/wiki/Usage).

Recommend offline JSON import of permitted URL/domain/email fields, with original category preserved. Do not automatically import discovered secret-key material, follow out-of-scope links, or turn archived URLs into live crawl seeds. A future runner needs enforceable host scope, redirect checks, page/body limits, robots decisions, and a global deadline beyond upstream depth and thread settings. The project's `--ninja` option still makes target requests and is not a passive mode.

License: [GPL-3.0](https://github.com/s0md3v/Photon/blob/master/LICENSE.md).

## Adapter acceptance requirements

Version 0.4 implements scoped Recon-ng CSV and Photon JSON imports plus WhatsMyName candidate URL planning. The latter does not check account existence. See the [exact v0.4 contracts and upstream serializer references](free-and-team-v04.md#community-tool-imports); earlier backlog labels in this research record describe the previous release.

Before a researched integration is labelled supported:

1. Capture an upstream version or commit, license reference, command help, and a realistic scrubbed export fixture.
2. Test positive, missing, ambiguous, malformed, empty, and partially completed results. Unknown schema must fail visibly.
3. Store original-file digest, original source, collection time if known, import time, external tool version, parser version, and retained raw fields. Do not substitute import time for unknown collection time.
4. Restrict runner arguments to typed fields. Use process argument arrays without a shell; never accept command strings from reports or registries.
5. Enforce process deadline, output/file-size caps, provider allowlists, and scope externally. A subprocess's own timeout does not constrain every module or network request it may perform.
6. Report blocked, rate-limited, stale, unsupported, and partial sources explicitly. None means “no account” or “no asset.”
7. Keep dataset/tool update review separate from collection. A silent upstream registry expansion must not enlarge an already approved run.

No credible implementation can guarantee coverage of every website: login requirements, closed APIs, changing markup, robots directives, rate limits, provider keys, and disappearing services change the reachable set. A measurable source registry, explicit failure states, pinned adapters, and evidence quality provide a stronger foundation than an unqualified “all sites” claim.
