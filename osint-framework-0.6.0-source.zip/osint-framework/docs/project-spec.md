# Revised project specification and delivery boundary

Revision: 2026-09-13. The original request is expanded from API orchestration to include a controlled public-page scraper, GitHub-tool interoperability, free-source coverage, and optional local team operations.

Version 0.4 retains the desktop for all seven identifier types, saved cases, document evidence, scoped Scrapy collection and STIX exchange. It adds eight source adapters, three community import subsets, local jobs/schedules, evidence comparisons, new-workspace encryption and an optional team API. This remains a local Python application; no hosted service or online personal-data database is created. [Operational guide and boundaries](free-and-team-v04.md).

## Objective

Provide a local open-source framework that collects public or authorized evidence for a single username, email, phone, domain, IP, URL, or name query; normalizes it; builds an explainable relationship graph; and exports reproducible evidence reports. Coverage grows through source adapters and explicit import contracts rather than a claim to scrape every website.

## Delivered architecture

```text
src/osint_framework/
  core/schema.py       Typed identifiers, claims, confidence, context, reports
  core/engine.py       Concurrent orchestration, deadlines, source outcomes
  core/http.py         Bounded HTTPS, source pacing, safe failures, public DNS pinning
  core/audit.py        Consent record and hash-chained local event log
  core/ratelimit.py    Persistent request pacing and provider cooldowns
  core/correlator.py   Exact identifier graph, evidence deduplication
  core/cases.py        Saved cases, immutable report versions, notes/reviews, hash checks
  core/credentials.py Task-local keys and explicit OS keychain access
  modules/native.py   Twelve source adapters
  modules/webpage.py  Explicit-scope public HTML collector
  modules/phone_evidence.py  Phone matches and nearby email evidence
  phone_workflow.py   Shared phone collection and result summary
  desktop.py         Desktop launcher and optional focused phone window
  workbench.py       Universal investigation UI and native graph
  workflow.py        Shared desktop/CLI service, case saves, page snapshots
  documents.py       Scoped document mentions, preserved originals, provenance
  document_extract.py Bounded separate PDF/DOCX/text/image extraction process
  modules/scrapy_pages.py Scrapy extraction through the shared scoped HTTP client
  integrations/      Twelve offline contracts, STIX export, bounded Subfinder runner
  modules/free_sources.py Eight additional no-key/free-account adapters
  core/vault.py      New-workspace authenticated encryption
  jobs.py            Persistent local queue and finite schedules
  team.py            Optional loopback API, roles and case access
  analysis.py        Deterministic comparisons and evidence paths
  catalog.py         Capability/setup checks and last saved source outcomes
  registry.py        Explicit trusted-plugin loading
  report.py          Offline HTML, JSON, GraphML
  cli.py             Source listing, collection, imports, demo, audit verification
```

## Requirements implemented

- Purpose and per-query authorization; first-launch policy confirmation and local audit.
- Documented provider references and credential environment variables.
- Request pacing, cooldown persistence, source deadlines, response/result limits.
- Bounded direct scraping only for explicitly scoped public HTTPS pages with a reviewed permission reference and permitted robots rules.
- No hidden browser, authentication bypass, CAPTCHA evasion, private profile access, or raw breach data.
- File provenance and conservative import confidence; unsupported formats fail explicitly.
- Exact typed-identifier correlation. No face matching, implicit person merging, bulk-person enumeration, or automatic pivoting.
- Local interactive report with evidence filters; full machine-readable report and graph exports.
- Plugin entry points, synthetic fixtures, CI workflow, contribution policy, and credential-pattern check.
- Persistent case notes/reviews, evidence history, change hashes, and selected-identifier follow-up input.
- Shared HTTP request budgets, source cancellation, and preservation of completed source results.
- Optional local page snapshots and document originals with SHA-256 verification.
- Masked task-local credentials and explicit native keychain save/load.
- Setup diagnostics, saved source statuses, and user-triggered retries from saved run inputs.

## Coverage tiers

1. **Implemented native adapters:** GitHub, Bluesky, Google DNS, crt.sh, RDAP, offline phone numbering metadata, Twilio basic lookup, HIBP, Hunter, VirusTotal, Shodan, Brave.
2. **Implemented interoperability:** Sherlock CSV, Maigret simple JSON, Subfinder JSONL, Scrapy public-page-v1 feed, canonical JSON/JSONL, SpiderFoot selected web-export events, Amass v5 names-only text, theHarvester v5 completed-result JSONL, and a STIX 2.1 subset. Subfinder also has a bounded optional runner; Scrapy has an independent scoped live collector; STIX export produces files suitable for OpenCTI connector import. See [integration contracts](integrations-v03.md).
3. **Additional v0.4 coverage:** InternetDB, RIPE, Wayback, Wikidata, Wikipedia, Hacker News, email DNS and urlscan; Recon-ng hosts/contacts CSV, Photon internal/subdomain JSON, and WhatsMyName candidate URL planning. These are explicit subsets. Additional upstream execution and export versions require their own compatibility tests.

## Differences from the original source list

The framework supports bounded permitted webpage collection in addition to APIs. It does not automatically execute every tool from a directory or import every site registry. Tool licenses and public URLs do not settle source access permission. Phone metadata is not reverse ownership lookup. The local phone module describes numbering-plan allocation, not current location or subscriber identity.

Bing Web Search is removed as a proposed live integration because Microsoft retired it on August 11, 2025. Google Custom Search is not a new-user default because Google closed new subscriptions and directs existing customers to transition by January 1, 2027. Brave is the implemented search-provider adapter. Provider terms and availability must be checked again when deploying.

## Remaining work for a production deployment

Live acceptance tests with operator-supplied keys and approved targets; upstream binary version pinning; packaging on additional operating systems; deployment-specific retention and backups; independent security review; additional versioned adapters; remote TLS/SSO/MFA and distributed workers remain deployment work. Local finite schedules, optional encryption for new workspaces, and a role-based loopback team API are implemented. No public server or GitHub/PyPI publication is part of this local delivery. The current reports are local files.
