# Scrapy public-page feed integration

The supplied [Start.me directory](https://start.me/p/b59RMv/osint) links to [Scrapy](https://github.com/scrapy/scrapy). This framework now accepts Scrapy's [JSON and JSON Lines feed containers](https://docs.scrapy.org/en/latest/topics/feed-exports.html) through one explicit item contract. Scrapy is an optional external collector; it is not installed, automatically launched, or bundled in this project.

Export these fields from an existing authorized spider:

```json
{"url":"https://example.org/contact","text":"Contact +1 202-555-0123 or help@example.org.","title":"Contact","observed_at":"2026-09-12T00:00:00+00:00"}
```

`url` and `text` are required. `title` and timezone-aware `observed_at` are optional. `text` should contain the public page's extracted text, maximum 100000 characters. If a `phone` field is present it must exactly equal the normalized queried number in E.164. Existing spiders can write these items with `-O public-pages.jsonl`. There is no assumed default schema for arbitrary Scrapy spiders.

Import the exported file for one phone query:

```powershell
.\osint.ps1 import-results .\examples\scrapy-public-pages.jsonl --tool scrapy --query +12025550123 --type phone --purpose "Synthetic feed demonstration" --authorized
```

The importer makes no network requests, ignores text without a complete matching number, and retains only matching page observations and nearby email leads. Confidence is tentative. Original timestamps are preserved when supplied; otherwise the timestamp is explicitly labeled import receipt time. Source URLs, file SHA-256, the declared format, and excerpts are retained. Unknown item schemas fail instead of silently guessing field names.

Importing a file does not establish that it was collected with permission, that its contents are authentic, or that an email belongs to a subscriber. Source-level verification remains necessary. The fixture above is synthetic.
