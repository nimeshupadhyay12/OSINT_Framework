# Version 0.4: free sources, jobs, encryption and the team API

This release has 25 source modules and 12 offline import contracts. Seven new modules work without an API key; urlscan uses a free-account key. The desktop, CLI and optional local API share case storage and the collection engine. Free access still has provider limits and terms. Coverage is source-specific; no service can find every email associated with an arbitrary phone number.

## Start using it

1. Run **Launch OSINT.cmd** in the project folder. On a fresh computer, install Python 3.11+ and run **Setup OSINT.cmd** first.
2. Create a case, paste a phone number, email, username, domain, IP, URL or name, and check the selected type.
3. Choose **Select compatible sources without API keys**. Supply exact hosts and a permission reference if you want webpage collection included.
4. Enter your purpose, confirm authorization, and run the investigation.
5. Inspect source statuses and original evidence. Use **Analyze evidence** to compare saved runs; use notes and accepted/rejected reviews to record your conclusions.
6. For repeated work, set total runs and hours between runs in **Jobs and schedules**, then choose **Queue current form**. **Process one due job** executes one job. Run the CLI worker below for continuous processing.

The normal desktop launcher opens `.osint-state` and writes to `reports`. To use another workspace, run `osint desktop --state PATH --out PATH`. An encrypted workspace prompts for its passphrase at launch. No API server or continuous worker starts automatically.

## New source coverage

| Module | Input | What it returns | Access and limits |
|---|---|---|---|
| `internetdb` | Public IPv4 | Existing port observations, hostnames and CVE labels | No key; Shodan states free noncommercial use. CVE labels are not verified vulnerabilities. |
| `ripe` | Public IP | Containing routing prefix and origin ASNs | No key; RIPEstat is a public noncommercial service; check commercial arrangements. |
| `wayback` | Domain or URL | One closest archived snapshot locator and capture time | No key; availability lookup only. Rate limits and missing captures are normal outcomes. |
| `wikidata` | Name | Up to ten labeled knowledge-entity candidates | No key; text matching does not establish identity. |
| `wikipedia` | Name or domain | Up to ten English Wikipedia article candidates | No key; this is encyclopedia search. |
| `hackernews` | Username | Exact public Hacker News profile metadata | No key; no submitted-item traversal. |
| `email_dns` | Email | Domain MX, SPF and DMARC observations | No key; sends only the domain to Google DNS. It does not verify mailbox existence. |
| `urlscan` | Domain or public IP | Up to twenty existing public scan records | `URLSCAN_API_KEY` from a free account; bounded search, with no scan submission. |

CLI examples, after `osint init`:

```powershell
osint run example.org --type domain --free-only --purpose "Authorized public organization review" --authorized
osint run 1.1.1.1 --type ip --modules internetdb,ripe --purpose "Public infrastructure review" --authorized
osint run "Wikimedia Foundation" --type name --modules wikidata,wikipedia --purpose "Public organization research" --authorized
osint run hello@example.org --type email --modules email_dns --purpose "Synthetic domain mail setup review" --authorized
```

`--free-only` selects compatible sources without keys and excludes unscoped page collectors and external executables. With explicit `--modules`, it rejects account-required modules. A free-account source such as urlscan is selected separately. Existing keyed integrations remain available; this release does not supply API keys or replace paid datasets with an equivalent free database. Setup diagnostics indicate dependencies and credentials, not provider uptime or account entitlement.

The point-in-time live check on **2026-09-13** succeeded for InternetDB (4 findings), RIPE (2), Wikidata (10), Wikipedia (10), and email DNS (4). Wayback returned a rate limit and was recorded as `rate_limited`. Hacker News and urlscan passed synthetic adapter tests; they were not live-tested. No paid provider or personal phone target was queried.

Provider references checked for this release: [InternetDB announcement](https://blog.shodan.io/introducing-the-internetdb-api/), [RIPE network-info](https://stat.ripe.net/docs/data-api/api-endpoints/network-info), [RIPEstat access](https://stat.ripe.net/docs/getting-started/what-is-ripestat), [Wayback availability](https://archive.org/help/wayback_api.php), [Wikidata access](https://www.wikidata.org/wiki/Wikidata:Data_access), [MediaWiki search](https://www.mediawiki.org/wiki/API:Search), [Hacker News API](https://github.com/HackerNews/API), [Google DNS JSON API](https://developers.google.com/speed/public-dns/docs/doh/json), [urlscan search](https://urlscan.io/docs/search/) and [urlscan free plan](https://urlscan.io/pricing/). Check current terms before relying on a service for ongoing use.

## Community tool imports

| Import | Supported file | Boundary |
|---|---|---|
| `recon_ng` | Recon-ng reporting/csv hosts or contacts with `headers=true` | Scoped host, reported IP and email fields. Arbitrary tables are unsupported. |
| `photon` | Photon `exported.json` named datasets | Imports `internal` URLs and `subdomains` within scope. Other datasets, including extracted keys, are omitted. |
| `whatsmyname` | Local `wmn-data.json` registry | Generates unchecked candidate profile URLs. It makes no account-existence request. Disabled/protected/custom-request entries are skipped. |

```powershell
osint import-results examples/recon-ng-hosts.csv --tool recon_ng --query example.org --type domain --purpose "Synthetic import review" --authorized
osint import-results examples/photon-export.json --tool photon --query example.org --type domain --purpose "Synthetic import review" --authorized
osint import-results examples/whatsmyname-registry.json --tool whatsmyname --query demo_user --type username --purpose "Synthetic registry planning" --authorized
```

All three preserve import hashes and receipt timestamps. The result limit applies to registry planning too; use a reviewed subset or raise `--max-findings` up to 2000. Examples are invented fixtures, not copied site databases. References: [Recon-ng CSV serializer](https://github.com/lanmaster53/recon-ng-marketplace/blob/master/modules/reporting/csv.py), [Photon JSON serializer](https://github.com/s0md3v/Photon/blob/master/plugins/exporter.py), [WhatsMyName schema](https://github.com/WebBreacher/WhatsMyName/blob/main/wmn-data-schema.json). Their full upstream runtimes are not bundled.

## Saved jobs and finite schedules

```powershell
$caseId = osint cases create "Synthetic scheduled review"
osint jobs enqueue $caseId +12025550123 --type phone --sources phone_local --purpose "Synthetic scheduled review" --authorized --repeat 3 --interval-hours 24
osint jobs list
osint jobs worker --continuous
# In another terminal, using the ID returned by enqueue:
osint jobs cancel JOB_ID
```

Use the same `--state` for enqueue, API, desktop and workers. `--once` processes at most one due job. A worker must remain running for scheduled jobs to execute. After a successful or partial run, the next run is due after the configured interval; the schedule stops after its finite count. Failures stop the chain. A stopped worker's expired lease becomes `stale` when another worker claims work. Inspect saved evidence before creating a replacement job; requests are never automatically replayed after a crash.

Limits: 100 runs per schedule, minimum one hour between runs, 1000 pending/running jobs, and the existing per-run request/source limits. Several worker processes can share local SQLite storage and pacing. This is a queue on one machine, not a distributed cluster. Cancellation stops unfinished sources and retains completed results. Queue records contain source names and inputs; worker credentials come from its process environment, not desktop session fields.

## Encrypted workspace

Install the `security` extra if it is not already present. Create a **new empty** state directory:

```powershell
osint vault init --state .osint-private
osint desktop --state .osint-private --out private-reports
```

`vault init` prompts twice for a passphrase of at least 12 characters. The desktop prompts to unlock it. For CLI, API and worker processes, supply the passphrase without placing it in shell history:

```powershell
$env:OSINT_VAULT_PASSPHRASE = Read-Host "Workspace passphrase" -MaskInput
osint init --accept-policy --state .osint-private
osint jobs worker --state .osint-private --out private-reports --continuous
# Clear this process environment value after stopping the worker:
Remove-Item Env:OSINT_VAULT_PASSPHRASE
```

`-MaskInput` requires PowerShell 7. On older PowerShell, use the desktop unlock prompt or a secure process-environment manager. `.env.example` is a template and is not automatically loaded.

Encryption uses scrypt key derivation and AES-256-GCM authenticated encryption. Case titles, report payloads, notes, review reasons, job inputs, audit payloads, preserved documents/pages and automatic report files are encrypted. Structural IDs, timestamps, status fields, hashes, source lists, role names and schema remain visible. Automatic report output is `report.json.enc`. Original files supplied by the operator remain where they were.

**Explicit report/STIX export produces plaintext.** To decrypt a saved automatic report into reviewable files:

```powershell
osint vault export-report private-reports/RUN_ID/report.json.enc exported-review --state .osint-private
```

Protect both the passphrase and `vault.json`; the application cannot recover them. Back up the complete workspace and evidence directory while workers are stopped. Existing plaintext workspaces are not automatically migrated or securely erased. This feature protects stored evidence, not an unlocked process, exported files, filesystem metadata or an administrator who controls the machine.

## Optional team API

Install the `team` extra, accept the policy, and create a token from a trusted local terminal:

```powershell
osint init --accept-policy
osint team user-add lead --role admin
osint team user-add analyst01 --role analyst
osint team user-add reader01 --role viewer
osint team serve --sources phone_local,dns,rdap,internetdb,ripe,email_dns,wayback,wikidata,wikipedia
# A second terminal, with the same state directory:
osint jobs worker --continuous
```

Each user-add command displays a token once; only its SHA-256 hash is stored. Supply it as `Authorization: Bearer TOKEN`. Administrators can access every case and grant access. Analysts create cases, collect and review within their granted cases. Viewers can read granted cases only. Use `osint team grant NAME CASE_ID`, `ungrant NAME CASE_ID`, `user-revoke NAME`, and `user-rotate NAME` to manage access. Rotation invalidates the old token and reactivates that user. A revoked user or one who loses case access cannot start their queued collection. `local` is reserved for desktop/CLI jobs.

The server binds only to `127.0.0.1:8765`. `/health` is public; `/openapi.json` and all data routes require a token. Browser Origin requests and untrusted Host headers are rejected. Request bodies are capped at 64 KB. Server source allowlists are enforced; the default is built-in sources without keys. There are no file-upload or arbitrary-command endpoints. Jobs run in a separate worker, not inside the HTTP process.

Minimal client example using a token placed in `OSINT_TEAM_TOKEN` by your environment manager:

```python
import os
import httpx

with httpx.Client(base_url="http://127.0.0.1:8765", trust_env=False,
                  headers={"Authorization": "Bearer " + os.environ["OSINT_TEAM_TOKEN"]}) as api:
    case = api.post("/cases", json={"title": "Synthetic API example"})
    case.raise_for_status()
    case_id = case.json()["id"]
    job = api.post(f"/cases/{case_id}/jobs", json={
        "context": {"input_type": "phone", "query": "+12025550123",
                    "purpose": "Synthetic API example", "authorized": True},
        "sources": ["phone_local"], "repeat": 1,
    })
    job.raise_for_status()
    print(job.json()["id"])
```

Read job status at `/jobs/ID`; cancel with `POST /jobs/ID/cancel`. Case routes provide reports/history, notes, reviews, jobs, `/analysis`, and `/path?start=ENTITY_ID&end=ENTITY_ID`. The authenticated OpenAPI schema describes request bodies. Remote hosting, TLS termination, SSO, MFA and organizational deployment review remain separate work; this release is a local team pilot. A local filesystem owner can access or change state independently of API roles.

## Evidence comparison

`osint analyze-case CASE_ID` returns a timeline, origin grouping, multiple observed values, and the latest two saved runs per exact query. Absence comparisons require a common source with successful, untruncated output and matching scope/budgets in both runs. “Not returned” does not prove deletion. Origins and repeated evidence do not establish independent corroboration.

`osint analyze-case CASE_ID --start ENTITY_ID --end ENTITY_ID` finds an undirected path through non-rejected evidence while retaining each original claim's direction and evidence IDs. Entity IDs are in JSON graph exports. Paths explain recorded relationships; they do not prove shared personal identity. There is no automatic person merging or calibrated identity probability.

## Remaining coverage limits

This is a working, extensible OSINT framework, with bounded collectors and explicit interoperability. It does not cover every website, proprietary dataset, private account, jurisdiction, language, tool version or identifier relationship. Free providers cannot guarantee reverse phone ownership or subscriber email discovery. WhatsMyName support is candidate planning. OCR needs an external Tesseract installation; scanned PDF OCR is unsupported. Setup still requires Python. Paid/keyed adapters, external binaries, cross-platform builds and a production team deployment require their own acceptance checks. See [validation](validation.md) for what actually ran.
