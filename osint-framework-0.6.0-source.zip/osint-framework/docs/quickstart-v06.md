# Using version 0.6

Open **Launch OSINT.cmd** in the project folder. Close an older application window and launch again to load the update. Existing cases remain in their workspace.

1. Paste a phone number, email, username, domain, IP, URL or name. Verify the detected type. Use an international phone number, or select a country for a national number.
2. Enter a purpose of at least eight characters, such as `Authorized company domain review`.
3. Select **Guided broad research — all ready sources**. This chooses compatible sources whose local requirements are configured. A configured key does not guarantee provider access or remaining quota.
4. For a domain, optionally select **Deep domain research — up to 3 subdomain pivots**. It follows discovered subdomains with DNS, RDAP and certificate-index lookups. All queries share the displayed HTTP request budget.
5. Confirm authorization and click **Run investigation**. A case is created if none is selected. Use **Stop current run** to cancel remaining collection.
6. Review the case evidence, source URLs, historical dates and graph. The final report lists unavailable sources and incomplete collection. Verify relevance before accepting a finding.
7. Add provider keys through **Sources and credentials**, then run again. Broad mode includes configured sources automatically. Manual collection also offers **Select all compatible ready sources** and the existing no-key button.

Names can refer to multiple people or organizations. Phone numbers do not inherently reveal an owner's email. Broad research does not automatically investigate every nearby person, account or email; choose subsequent personal-identifier queries manually after reviewing evidence.

Page collection additionally requires exact hosts and a permission reference; phone pages require explicit URLs. Guided research does not invent these fields. Historical URL discovery reads an index without visiting each URL. Deep domain research adds public database lookups, not vulnerability scans.

**PowerShell**

From the project folder, preview source selection without contacting providers:

```powershell
.\.venv\Scripts\osint.exe research-plan example.org
```

Run a scoped investigation:

```powershell
.\.venv\Scripts\osint.exe init --accept-policy
.\.venv\Scripts\osint.exe research example.org --purpose "Authorized domain review" --authorized --max-pivots 3 --max-requests 80
```

Add `--profile quick` for no-key sources or `--case CASE_ID` for an existing case. CLI pivots default to zero and are limited to five. Use `research --help` for options. The existing `run` command provides explicit source and page-scope selection.

**Import more results**

Choose **Import a tool export**, select its tool and file, and supply a matching query:

| Tool | Accepted format | Result |
| --- | --- | --- |
| gau | Plain URL lines, not JSON mode | Historical URLs within the domain or exact URL |
| waybackurls | Plain URL lines | Historical URLs within the domain or exact URL |
| Uncover | JSONL from `-j`, with source/ip/port/host/url fields | Provider-reported infrastructure within domain or exact IP scope |

Imports do not install or execute the tools. Existing Sherlock, Maigret, SpiderFoot, Amass, theHarvester, Recon-ng, Photon, WhatsMyName, Subfinder, Scrapy, MISP, OpenCTI and canonical import contracts remain available. The Sources tab distinguishes collectors, imports and local utilities.

**Exports and team clients**

WARC now supports ordinary, encrypted and legacy document artifacts. Explicit WARC/bundle exports contain plaintext. Legacy documents without a capture timestamp use report creation time with that limitation recorded. Existing archives are never overwritten.

Team clients must paginate `GET /cases/{id}?limit=10&offset=0`; maximum page size is 25 reports. Anonymous requests now have a separate quota. Optional remote deployment still requires its own acceptance testing.
