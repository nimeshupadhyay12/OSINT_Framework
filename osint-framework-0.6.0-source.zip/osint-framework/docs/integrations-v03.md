# Version 0.3 integrations and workbench guide

Validated locally on 2026-09-12. This release adds five integration boundaries: SpiderFoot, Amass, and theHarvester offline imports; live scoped Scrapy extraction; and OpenCTI-compatible STIX 2.1 file exchange. Existing Sherlock, Maigret, Subfinder, canonical, and Scrapy-feed imports remain available. Installing the framework does not install or execute the upstream scanners.

## Install and check readiness

On Windows, use `Setup OSINT.cmd`, then `Launch OSINT.cmd`. Manual installation from the project folder:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install ".[desktop,crawler,exchange,documents]"
.\.venv\Scripts\osint.exe doctor
.\.venv\Scripts\osint.exe desktop
```

`doctor` checks local packages, executable presence, configured key names, and last saved case-source outcomes. It makes no provider requests. “Ready” describes local setup; it does not establish subscription access, source uptime, or OCR language availability. Its JSON output is available with `--json`.

The desktop's **Sources and credentials** tab accepts each supported provider key for the current session. **Save to OS keychain** and **Load OS keychain** require explicit clicks and an approved native backend. Reports, case payloads, and audit records do not store these keys. Python cannot guarantee erasure of strings from process memory.

## SpiderFoot

Select tool import mode and `spiderfoot`, choose a JSON file, and enter the same target/type used for that scan. The contract is the JSON object array produced by the web UI's `scanexportjsonmulti` serializer, not arbitrary CLI JSON or CSV.

Required fields are `scan_target`, `data`, `event_type`, `module`, and `false_positive` (0/1 or Boolean). Supported events are DOMAIN_NAME, INTERNET_NAME, EMAILADDR, IP_ADDRESS, IPV6_ADDRESS, PHONE_NUMBER, HUMAN_NAME, LINKED_URL_INTERNAL, and LINKED_URL_EXTERNAL. Flagged false positives and unsupported event types are omitted. Domain/email/URL objects are constrained to the queried domain when the query is a domain. Other retained observations remain explicitly tool-reported claims.

`source_data`, module, event type, scan name, and raw `last_seen` are retained. The serializer's `last_seen` lacks a timezone; the importer does not guess UTC or treat receipt time as source observation time. Findings retain the input file digest and tentative confidence.

[Upstream serializer](https://github.com/smicallef/spiderfoot/blob/master/sfwebui.py). Local synthetic fixture: `examples/spiderfoot.json`.

## OWASP Amass

The adapter accepts **names-only text** from the v5 `oam_subs` tool. One FQDN per line; exact domain/subdomain scope; duplicates are removed. A name file has no provider attribution or collection timestamp, so those are explicitly unknown. Legacy `enum -json`, database files, banners, colored terminal output, and arbitrary asset JSON are not supported.

For an existing configured Amass database, the reviewed upstream export interface is:

```text
oam_subs -d example.org -names -nocolor
```

Save only the resulting FQDN lines as UTF-8 text. This documentation review did not execute an Amass binary. The importer is tested against a synthetic file shaped to this contract.

[Verified CLI source at commit 79299dce](https://github.com/owasp-amass/amass/blob/79299dce87b0085db0f2f4ef3e9c52cccb49f514/internal/subs/cli.go). Fixture: `examples/amass-names.txt`.

## theHarvester

The supported v5 development contract is the **completed-result JSONL** serializer: one `type: summary` record followed by result records. This deliberately does not claim support for all released/historical XML or JSON exports.

The summary must match the queried domain and include `evidence_status` (`complete`, `partial`, or `failed`), `result_count`, and a timezone-aware `completed_at`. Count must match the subsequent record count. Imported record types are `hostname`, `email`, `ip`, and `url`, using `value`, `sources`, and optional `actions`. Other types are skipped and counted; their presence is not a claim of complete import coverage. Domain/email/URL values must remain within query-domain scope. An IP is retained as an upstream claim, without asserting ownership.

The adapter preserves run ID, completion time, source executions, source/action names, and partial/failed status in provenance. Completion time describes the run, not each underlying observation. Import status `ok` means parsing returned observations, not that the upstream scan completed successfully.

[Verified serializer at commit 78a78f08](https://github.com/laramies/theHarvester/blob/78a78f08d4a0d6d9bf6058effa8ddafb9e2d070b/theHarvester/lib/completed_result.py). Fixture: `examples/theharvester.jsonl`.

## Run the three imports

These examples use synthetic files and make no network requests. Run `osint init` first to read and accept the policy.

```powershell
osint import-results examples/spiderfoot.json --tool spiderfoot --query example.org --type domain --purpose "Synthetic export review" --authorized
osint import-results examples/amass-names.txt --tool amass --query example.org --type domain --purpose "Synthetic export review" --authorized
osint import-results examples/theharvester.jsonl --tool theharvester --query example.org --type domain --purpose "Synthetic export review" --authorized
```

Imports are capped at 10 MB and scoped to one query. The default cap is 500 findings, maximum 2,000. Invalid supported fields and overflow fail visibly. Original import files are identified by SHA-256; retain your original export separately if you need the complete file. Only document mode automatically preserves its full input file.

## Scrapy live page collector

`scrapy_pages` uses a real Scrapy Spider and HTML/CSS selectors. Downloads pass through the framework's existing HTTP client, host-scope validation, robots parser, and persistent pacing. The Scrapy downloader and arbitrary spider plugins are not launched. This avoids a second unrestricted request path while using Scrapy's extraction API.

```powershell
osint run https://example.org/ --type url --modules scrapy_pages --allow-host example.org --terms-url https://www.iana.org/help/example-domains --max-pages 1 --max-requests 3 --preserve-pages --purpose "Public example domain review" --authorized
```

The collector extracts page observations, published mailto addresses, and same-origin links; it follows only a bounded set of same-origin pages. Defaults: three pages and 50 shared HTTP requests. Maximums: 20 pages and 200 requests. Robots and redirect requests consume the HTTP budget. No JavaScript rendering, session cookies, authentication, CAPTCHA bypass, redirects, or query-string crawling. The older `scrapy` import remains a separate phone-oriented public-page feed contract described in [scrapy-feed.md](scrapy-feed.md).

[Scrapy selectors](https://docs.scrapy.org/en/latest/topics/selectors.html). Preserved page bytes have inert `.txt` filenames, original URLs, capture timestamps, and SHA-256 checksums. They are evidence snapshots, not replayable websites.

## OpenCTI / STIX 2.1

Exchange uses local JSON files. Export creates standard cyber-observables where representable, evidence Notes carrying `x_osint_finding`, a tool Identity, and a Grouping. Phone/name claims stay in Notes rather than being recast as unsupported standard observables. A Note records a claim and source; it does not infer that two identifiers belong to the same person.

```powershell
# Replace the report path with a saved run; requires the exchange extra.
osint export-stix reports/RUN-ID/report.json --out reports/opencti.stix.json
osint import-results reports/opencti.stix.json --tool opencti --query example.org --type domain --purpose "Authorized STIX review" --authorized
```

Import supports STIX 2.1 Bundles containing `domain-name`, `ipv4-addr`, `ipv6-addr`, `email-addr`, `url`, or `user-account`. It keeps exact query observables, explicit outgoing relationships to supported observables, and framework evidence Notes for the exact query. It does not expand all connected entities or import every OpenCTI object type. Imported timestamps, confidence, labels, original objects, and markings remain provenance; new findings are tentative.

Export validates with the `stix2` library. Imported marking references and supplied definitions are retained, applying the union of restrictions to the exported bundle; missing referenced definitions stop export. Review handling restrictions before sharing any file. Files can then be submitted through a configured OpenCTI STIX import connector. No server authentication, upload, connector deployment, or live OpenCTI acceptance test is included. See [OpenCTI connector documentation](https://docs.opencti.io/latest/deployment/connectors/).

## Documents, case history, and review

Choose local document mode, select a file, and enter the identifier to find. TXT, Markdown, HTML, text-bearing PDF (up to 50 pages), DOCX paragraphs/tables, and PNG/JPEG/TIFF images are supported. Image OCR requires Tesseract on PATH and language packs such as `eng` or `hin`; use `eng+hin` for both. Scanned PDFs do not automatically undergo OCR. Source files are capped at 10 MB, expanded DOCX at 50 MB, images at 20 million pixels, and extraction text at 200,000 characters. Exceeding these extraction budgets rejects the document. Findings still have the configured result cap; an empty result is not proof of absence.

Cases keep the original run reports with digests, append-only notes/reviews through the application API, and evidence first/last sightings. Hash changes indicate content or import-file changes, not a proven factual change. Repeated observations from the same underlying source do not provide independent confirmation. Analyst acceptance does not upgrade claim confidence. Local database and evidence files are not encrypted or protected against an administrator recomputing their digests.

Use `osint cases verify CASE-ID` to check report and artifact hashes. The source readiness tab reads the latest saved source outcomes; it does not monitor providers in the background. To retry, load a saved run, review the restored source selection/scope, and explicitly run it again. Automated recurring monitoring, AI summaries, multi-user hosting, and additional registry/runner integrations remain future extensions.
