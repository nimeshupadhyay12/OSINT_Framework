# Repository evaluation for version 0.6

Upstream repositories and documentation were checked on 14 September 2026. This is a capability and integration-contract review, not a full security audit of those projects. Advertised site counts and popularity do not establish accuracy or provider availability.

| Primary source | Useful capability | Decision and implementation status |
| --- | --- | --- |
| [gau](https://github.com/lc/gau) | Historical/public-index URL discovery | Added scoped plain-URL import, deduplication and historical-lead labels. JSON mode is outside this contract. |
| [waybackurls](https://github.com/tomnomnom/waybackurls) | Wayback domain URL discovery | Added scoped plain-URL import. A native CDX collector provides bounded archive discovery without installing the executable. |
| [Internet Archive CDX](https://github.com/internetarchive/wayback/tree/master/wayback-cdx-server) | Historical URLs, capture times and content types | Added native no-key collection, capped at 200 rows. Validates columns and scope; does not download archived content. |
| [Uncover](https://github.com/projectdiscovery/uncover) | Multiple infrastructure search providers | Added JSONL import based on the upstream [Result schema](https://github.com/projectdiscovery/uncover/blob/main/sources/result.go). External tool keys remain separate; no automatic runner or port probing. |
| [Subfinder](https://github.com/projectdiscovery/subfinder) | Passive subdomain discovery | Retain JSONL import and explicitly selected, hash-approved runner. Guided mode excludes executable runners. |
| [SpiderFoot](https://github.com/smicallef/spiderfoot) | Event-driven source enrichment | Retain supported JSON import. Adopt transparent planning and coverage reporting; do not implicitly enable all upstream modules. |
| [IntelOwl](https://github.com/intelowlproject/IntelOwl) | Observable enrichment, playbooks and analyzers | Adopt reusable quick/broad research profiles. A live IntelOwl connector is not implemented; its deployment and analyzer behavior need separate acceptance tests. |
| [Sherlock](https://github.com/sherlock-project/sherlock) | Public username searches | Retain positive-row CSV import. Same-name accounts are tentative leads. No new automatic runner. |
| [Maigret](https://github.com/soxoj/maigret) | Username research and structured results | Retain supported JSON import, exact username scope and similar-account exclusion. No automatic recursive person expansion. |
| [WhatsMyName](https://github.com/WebBreacher/WhatsMyName) | Community username site definitions | Retain local registry-to-candidate URLs. Candidates are not confirmed accounts; registry request templates are not executed. |
| [GitHub search API](https://docs.github.com/en/rest/search/search#search-repositories) | Public repository mentions | Added native repository search, up to 30 results, retaining incomplete-result/count signals. Search relevance does not prove affiliation. |

The new adapters implement documented data contracts; they do not vendor or redistribute the upstream tools or claim their complete feature sets. Review current licenses, dependencies and source before installing external executables or plugins. Framework MIT licensing does not relicense provider data or third-party tools.

Different sources answer different questions: current DNS/RDAP, certificate history, archive URLs, repository mentions and threat observations. Repeated upstream observations are not independent corroboration. Historical records can be stale; failed requests must not become claims that nothing exists.

No project in this comparison covers the entire internet. Private accounts, unindexed pages and restricted databases remain unavailable through ordinary public OSINT. The framework reports source selection, exclusions, failures and budgets rather than an unsupported completeness percentage.
