Describe the input, source, expected evidence, and resulting behavior.

- [ ] I read ETHICS.md.
- [ ] I included official source/terms references, key requirements, rate limits, and legal_basis.
- [ ] I identified the supported upstream version/export schema.
- [ ] Tests cover scope, uncertainty, malformed data, and safe failures.
- [ ] No credentials, real personal fixtures, or access-control workarounds are included.
